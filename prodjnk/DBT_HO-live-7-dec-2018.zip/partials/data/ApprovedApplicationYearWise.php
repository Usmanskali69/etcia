<?php

	session_start();
	
	include("../../../db_connect.php");
	$hoId=$_SESSION['hoId'];
	$hoId=substr($hoId, -7);
	$studentQuery	=	"select 
   approvalDate,DBTApplicationSubmittedDate,studentUniqueId,disclaimer,name,fatherName,casteCategory,bankName,bankBranchName,branchCode,bankifscCode,bankAccountNumber,UIDNo,DBTApplicationStatus,admissionThroughCCP,collegeUniqueId,streamAllottedIn,courseUniqueId,instituteAddress,instituteState,otherStudentStreamAppliedFor,OtherStudentCourseName
FROM
    students 
   
where
    
       DBTApplicationFormSubmitted = 'Y'
        and approvalFlag = 'Y' and finalApprovedFlag='N' and yearOfCounselling='".$hoId."' and isScholarshipCompleted is null";
	
	
	$result = mysqli_query($con, $studentQuery) or die("Could not execute query");
	$studentData=array();
	
	while($row = mysqli_fetch_array($result)){
		$row_array['Approval_Date'] = $row['approvalDate'];
		$row_array['Submission_Date'] = $row['DBTApplicationSubmittedDate'];
		$row_array['AdmissionThroughCCP'] = $row['admissionThroughCCP'];
		$row_array['Candidate_Id'] = $row['studentUniqueId'];
		$row_array['Beneficiary_Code'] = $row['disclaimer'];
		//$row_array['Candidate_Rank'] = $row['studentRank'];
		$row_array['Candidate_Name'] = $row['name'];
		$approval_auditQuery	=	"	SELECT actualPaymentTill,paymentType 
										FROM approval_audit 
										WHERE studentUniqueId='".$row['studentUniqueId']."'
										AND DBTApplicationStatus='Approved'
										ORDER BY approvalAuditId DESC LIMIT 1";
	
	
		$approval_auditresult = mysqli_query($con, $approval_auditQuery) or die("Could not execute query");
		$approval_audit_row=mysqli_fetch_array($approval_auditresult);
		//$row_array['Payment_Till']= $approval_audit_row['actualPaymentTill']."-".$approval_audit_row['paymentType'];
		$row_array['Father_Name'] = $row['fatherName'];
		//$row_array['DOB'] = $row['birthDate'];
		$row_array['Caste_Category'] = $row['casteCategory'];
		//$row_array['EmailId'] = $row['primaryEmailId'];
		//$row_array['Tution_Applied'] = $row['tutionFees'];
		//$row_array['Hostel_Applied'] = $row['hostelFees'];
		//$row_array['Book_Stationary_Applied'] = $row['bookNStationaryCharges'];
		//$row_array['Other_Charges_Applied'] = $row['otherCharges'];
		$otherQuery	=	"select 
  otherStudentCollegeName
FROM
    students 
   
where
    
       studentUniqueId='".$row['studentUniqueId']."'";
	
	
	$otherresult = mysqli_query($con, $otherQuery) or die("Could not execute query");
	$other_row=mysqli_fetch_array($otherresult);
		//$row_array['Tution_Approved'] = $row['approvedTutionFees'];
		//$row_array['Hostel_Approved'] = $row['approvedHostelFees'];
		//$row_array['Book_Stationary_Approved'] = $row['approvedBookNStationaryCharges'];
		//$row_array['Other_Charges_Approved'] = $row['approvedOtherCharges'];
		//$row_array['Total'] = $row['approvedTotal'];
		$row_array['Bank_Name'] = $row['bankName'];
		$row_array['Branch_Name'] = $row['bankBranchName'];
		$row_array['Branch_Code'] = $row['branchCode'];
		$row_array['Bank_IFSC_Code'] = $row['bankifscCode'];
		$row_array['Bank_AC_No'] = $row['bankAccountNumber'];
		$row_array['UID_No'] = $row['UIDNo'];
		
		$row_array['Candidate_Status'] = $row['DBTApplicationStatus'];
		if($row['admissionThroughCCP']=='Yes')
		{
		if($row['collegeUniqueId']!='' && $row['collegeUniqueId']!=null){
		if($row['streamAllottedIn']=='Engineering and Technology')
		{
		$row['streamAllottedIn']='Engineering';
		}
		$row_array['Candidate_Category'] = $row['streamAllottedIn'];
		$collegeQuery	=	"select 
   name,address,state
FROM
    colleges 
   
where
    
       collegeUniqueId='".$row['collegeUniqueId']."'";
	
	
	$collegeresult = mysqli_query($con, $collegeQuery) or die("Could not execute query");
	$college_row=mysqli_fetch_array($collegeresult);
	$courseQuery	=	"select 
   courseName
FROM
    courses 
   
where
    
       courseUniqueId='".$row['courseUniqueId']."'";
	
	
	$courseresult = mysqli_query($con, $courseQuery) or die("Could not execute query");
	$course_row=mysqli_fetch_array($courseresult);
		$row_array['College_Name'] = $college_row['name'];
		$row_array['College_Address'] = $college_row['address'];
		$row_array['College_State'] = $college_row['state'];
		$row_array['Course_Name'] = $course_row['courseName'];
		
	}else
		{
		if($row['otherStudentStreamAppliedFor']=='Engineering and Technology')
		{
		$row['otherStudentStreamAppliedFor']='Engineering';
		}
		
		$row_array['Candidate_Category'] = $row['otherStudentStreamAppliedFor'];
		$row_array['College_Name'] = $other_row['otherStudentCollegeName'];
		$row_array['College_Address'] = $row['instituteAddress'];
		$row_array['College_State'] = $row['instituteState'];
		$row_array['Course_Name'] = $row['OtherStudentCourseName'];
		}
		}
		if($row['admissionThroughCCP']=='No')
		{
		$row_array['Candidate_Category'] = $row['otherStudentStreamAppliedFor'];
		$row_array['College_Name'] = $other_row['otherStudentCollegeName'];
		$row_array['College_Address'] = $row['instituteAddress'];
		$row_array['College_State'] = $row['instituteState'];
		$row_array['Course_Name'] = $row['OtherStudentCourseName'];
		}
		array_push($studentData,$row_array);
	}
	
	echo json_encode($studentData);
?>