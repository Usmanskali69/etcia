$(document).ready(function(event) {


	$('form').on('focus', 'input[type=number]', function(e) {
        $(this).on('mousewheel.disableScroll', function(e) {
            e.preventDefault()
        })
    })
    $('form').on('blur', 'input[type=number]', function(e) {
        $(this).off('mousewheel.disableScroll')
    })	
	$(document).on('hidden.bs.modal', function(e) {
        console.log('cleared');
        console.log('cleared');
        var target = $(e.target);
        target.removeData('bs.modal')
            .find(".modal-content").html('');
    });
	$("#approvedHostelFees").change(function() {

        var hostelfee = $("#approvedHostelFees").val();
        var bookNStationary = $("#approvedBookNStationaryCharges").val();
        var otherCharges = $("#approvedOtherCharges").val();
		if(hostelfee=='' || hostelfee==null)
		{
			hostelfee=0;
		}
		if(bookNStationary=='' || bookNStationary==null)
		{
			bookNStationary=0;
		}
		if(otherCharges=='' || otherCharges==null)
		{
			otherCharges=0;
		}
		console.log(hostelfee+'abc');
        var total = parseFloat(hostelfee) + parseFloat(bookNStationary) + parseFloat(otherCharges);
        $("#approvedTotalB").val(total).trigger("change");
		if(total>100000)
		{
			$("#totalBError").addClass("has-error");
            $("#totalBErrorMsg").html("Total(B) should be less than or equal to Rs.1,00,000").css("color", "#a94442");
		}
		else
		{
			$("#totalBError").removeClass("has-error");
			$("#totalBErrorMsg").html('');
		}

    });
	
	$("#approvedBookNStationaryCharges").change(function() {

        var hostelfee = $("#approvedHostelFees").val();
        var bookNStationary = $("#approvedBookNStationaryCharges").val();
        var otherCharges = $("#approvedOtherCharges").val();
		if(hostelfee=='' || hostelfee==null)
		{
			hostelfee=0;
		}
		if(bookNStationary=='' || bookNStationary==null)
		{
			bookNStationary=0;
		}
		if(otherCharges=='' || otherCharges==null)
		{
			otherCharges=0;
		}
		console.log(hostelfee+'abc');
        var total = parseFloat(hostelfee) + parseFloat(bookNStationary) + parseFloat(otherCharges);
        $("#approvedTotalB").val(total).trigger("change");
		if(total>100000)
		{
			$("#totalBError").addClass("has-error");
            $("#totalBErrorMsg").html("Total(B) should be less than or equal to Rs.1,00,000").css("color", "#a94442");
		}
		else
		{
			$("#totalBError").removeClass("has-error");
			$("#totalBErrorMsg").html('');
		}
    });
	
	$("#approvedOtherCharges").change(function() {

        var hostelfee = $("#approvedHostelFees").val();
        var bookNStationary = $("#approvedBookNStationaryCharges").val();
        var otherCharges = $("#approvedOtherCharges").val();
		if(hostelfee=='' || hostelfee==null)
		{
			hostelfee=0;
		}
		if(bookNStationary=='' || bookNStationary==null)
		{
			bookNStationary=0;
		}
		if(otherCharges=='' || otherCharges==null)
		{
			otherCharges=0;
		}
		
        var total = parseFloat(hostelfee) + parseFloat(bookNStationary) + parseFloat(otherCharges);
        $("#approvedTotalB").val(total).trigger("change");
		if(total>100000)
		{
			$("#totalBError").addClass("has-error");
            $("#totalBErrorMsg").html("Total(B) should be less than or equal to Rs.1,00,000").css("color", "#a94442");
		}
		else
		{
			$("#totalBError").removeClass("has-error");
			$("#totalBErrorMsg").html('');
		}
    });
	
	$("#approvedTutionFees").change(function() {

        tutionFees();
    });
	
	$("#approvedTotalA").change(function() {

        var approvedTotalA = $("#approvedTotalA").val();
        var approvedTotalB = $("#approvedTotalB").val();
       
		if(approvedTotalA=='' || approvedTotalA==null)
		{
			approvedTotalA=0;
		}
		if(approvedTotalB=='' || approvedTotalB==null)
		{
			approvedTotalB=0;
		}
		
		console.log(approvedTotalA+'abc');
        var total = parseFloat(approvedTotalA) + parseFloat(approvedTotalB);
        $("#approvedTotal").val(total);

    });
	
	$("#approvedTotalB").change(function() {

        var approvedTotalA = $("#approvedTotalA").val();
        var approvedTotalB = $("#approvedTotalB").val();
       
		if(approvedTotalA=='' || approvedTotalA==null)
		{
			approvedTotalA=0;
		}
		if(approvedTotalB=='' || approvedTotalB==null)
		{
			approvedTotalB=0;
		}
		
		console.log(approvedTotalA+'abc');
        var total = parseFloat(approvedTotalA) + parseFloat(approvedTotalB);
        $("#approvedTotal").val(total);
		
		
    });
	
	
	$('#Approve').click(function(e){
	e.preventDefault();
	var approvedTotalB=$('#approvedTotalB').val();
	if(approvedTotalB=='' || approvedTotalB==null)
	{
		approvedTotalB=0;
	}
	console.log($("#approveOrReject").valid() && tutionFees()==true && approvedTotalB>=100000);
	if($("#approveOrReject").valid() && tutionFees()==true && approvedTotalB<=100000)
	{
	$.ajax({
			type: 'GET', // define the type of HTTP verb we want to use (POST for our form)
			url: 'partials/update/updateStudentDBTDetails.php', // the url where we want to POST
			data: $("#approveOrReject").serialize(), // our data object
			//encode: true
			beforeSend: function() {
							$("#approvedTutionFees").prop("disabled", true);
							$("#approvedHostelFees").prop("disabled", true);
							$("#approvedBookNStationaryCharges").prop("disabled", true);
							$("#approvedOtherCharges").prop("disabled", true);
							$("#approvedTotalA").prop("disabled", true);
							$("#approvedTotalB").prop("disabled", true);
							$("#approvalOrRejectionComment").prop("disabled", true);
							$("#Approve").prop("disabled", true);
							$("#Reject").prop("disabled", true);
							$("#Save").prop("disabled", true);// disable button
							$("#Approve").text('Approving ...');
							
		},
		success:function(data) {
		
			var reply = data.replace(/\s+/, ""); 
			// log data to the console so we can see
			console.log(data);
			if (reply == 'success'){
				$("#Approve").text('Approve');
				// enable button
				$("#approveOrRejectMessage").html("<b><font color='Green'>Application Approved Successfully</font></b>");
			// here we will handle errors and validation messages
			}
			if(reply == 'failure')
			{
				$("#Approve").text('Approve');
				$("#Approve").prop("disabled", false);
				$("#Reject").prop("disabled", false);	
				$("#Save").prop("disabled", false);// enable button
				$("#approveOrRejectMessage").html("<b><font color='Red'>Fail to Approve</font></b>");
			}
			if(reply == 'Approved')
			{
				$("#Approve").text('Approve');
				// enable button
				$("#approveOrRejectMessage").html("<b><font color='Red'>This Application is already been Approved.</font></b>");
			}
			if(reply == 'Submitted')
			{
				$("#Approve").text('Approve');
				// enable button
				$("#approveOrRejectMessage").html("<b><font color='Red'>This Application is already been Approved.</font></b>");
			}
			if(reply == 'Rejected')
			{
				$("#Approve").text('Approve');
				// enable button
				$("#approveOrRejectMessage").html("<b><font color='Red'>This Application is already been Rejected.</font></b>");
			}
			if(reply == 'New')
			{
				$("#Approve").text('Approve');
				// enable button
				$("#approveOrRejectMessage").html("<b><font color='Red'>This Application cannot be approved as it has been reopened by the candidate.</font></b>");
			}
		}
		
		});
		}
		
	});
	
	
	
	$('#speciallyAllowedApprove').click(function(e){
	e.preventDefault();
	$.ajax({
			type: 'GET', // define the type of HTTP verb we want to use (POST for our form)
			url: 'partials/update/speciallyAllowedApproveDetails.php', // the url where we want to POST
			data: $("#speciallyApproveOrReject").serialize(), // our data object
			//encode: true
			beforeSend: function() {
				$("#speciallyAllowedApprove").text('Approving ...');
				$("#speciallyAllowedReject").prop("disabled", true);							
			},
			success:function(data) {	
				var reply = data.replace(/\s+/, ""); 
				// log data to the console so we can see
				console.log(data);
				if (reply == 'success'){
					$("#speciallyAllowedApprove").text('Approve');
					// enable button
					$("#speciallyAllowedApproveOrRejectMessage").html("<b><font color='Green' size='4px'>Application Approved Successfully</font></b>");
				// here we will handle errors and validation messages
				}
				else if(reply == 'processed')
				{
					$("#speciallyAllowedApprove").text('Approve');
					$("#speciallyAllowedApproveOrRejectMessage").html("<b><font color='Blue' size='4px'>Application Already Processed</font></b>");
				}
				else {
					$("#speciallyAllowedApprove").text('Approve');
					$("#speciallyAllowedApproveOrRejectMessage").html("<b><font color='Red' size='4px'>Failed TO Approve</font></b>");
				}

			}
		
		});
		
	});
	
	$('#speciallyAllowedReject').click(function(e){
	e.preventDefault();
	$.ajax({
			type: 'GET', // define the type of HTTP verb we want to use (POST for our form)
			url: 'partials/update/speciallyAllowedRejectedDetails.php', // the url where we want to POST
			data: $("#speciallyApproveOrReject").serialize(), // our data object
			//encode: true
			beforeSend: function() {
				$("#speciallyAllowedReject").text('Rejecting ...');
				$("#speciallyAllowedApprove").prop("disabled", true);							
			},
			success:function(data) {	
				var reply = data.replace(/\s+/, ""); 
				// log data to the console so we can see
				console.log(data);
				if (reply == 'success'){
					$("#speciallyAllowedReject").text('Reject');
					// enable button
					$("#speciallyAllowedApproveOrRejectMessage").html("<b><font color='Green' size='4px'>Application Rejected Successfully</font></b>");
				// here we will handle errors and validation messages
				}
				else if(reply == 'processed')
				{
					$("#speciallyAllowedReject").text('Reject');
					$("#speciallyAllowedApproveOrRejectMessage").html("<b><font color='Blue' size='4px'>Application Already Processed</font></b>");
				}
				else {
					$("#speciallyAllowedReject").text('Reject');
					$("#speciallyAllowedApproveOrRejectMessage").html("<b><font color='Red' size='4px'>Failed To Reject</font></b>");
				}

			}
		
		});
		
	});
	$('#finalApprove').click(function(e){
		var type='finalApprove';
	e.preventDefault();
	var approvedTotalB=$('#approvedTotalB').val();
	if(approvedTotalB=='' || approvedTotalB==null)
		{
			approvedTotalB=0;
		}
		console.log($("#finalApproveOrReject").valid() && tutionFees()==true && approvedTotalB>=100000);
	if($("#finalApproveOrReject").valid() && tutionFees()==true && approvedTotalB<=100000)
	{
	$.ajax({
				type: 'GET', // define the type of HTTP verb we want to use (POST for our form)
				url: 'partials/update/updateFinalDBTDetails.php?type='+type, // the url where we want to POST
				data: $("#finalApproveOrReject").serialize(), // our data object
				//encode: true
				beforeSend: function() {
								$("#paymentType").prop("disabled", true);
								$("#courseDuration").prop("disabled", true);
								$("#approvedTutionFees").prop("disabled", true);
								$("#approvedHostelFees").prop("disabled", true);
								$("#approvedBookNStationaryCharges").prop("disabled", true);
								$("#approvedOtherCharges").prop("disabled", true);
								$("#approvedTotalA").prop("disabled", true);
								$("#approvedTotalB").prop("disabled", true);
								$("#approvalOrRejectionComment").prop("disabled", true);
								$("#finalApprove").prop("disabled", true);
								$("#finalReject").prop("disabled", true);	
								$("#finalSave").prop("disabled", true);	// disable button
								$("#finalApprove").text('Approving ...');
								
			},
			success:function(data) {
			
				var reply = data.replace(/\s+/, ""); 
				// log data to the console so we can see
				console.log(data);
				if (reply == 'success'){
					$("#finalApprove").text('Approve');
					// enable button
					$("#approveOrRejectMessage").html("<b><font color='Green'>Application Approved Successfully</font></b>");
				// here we will handle errors and validation messages
				}
				if(reply == 'failure')
				{
					$("#finalApprove").text('Approve');
					$("#finalApprove").prop("disabled", false);
					$("#finalReject").prop("disabled", false);	
					$("#finalSave").prop("disabled", false);// enable button
					$("#approveOrRejectMessage").html("<b><font color='Red'>Fail to Approve</font></b>");
				}
				if(reply == 'Approved')
				{
					$("#finalApprove").text('Approve');
					// enable button
					$("#approveOrRejectMessage").html("<b><font color='Red'>This Application is already been Approved.</font></b>");
				}
				if(reply == 'Rejected')
				{
					$("#finalApprove").text('Approve');
					// enable button
					$("#approveOrRejectMessage").html("<b><font color='Red'>This Application is already been Rejected.</font></b>");
				}
				if(reply == 'New')
				{
					$("#finalApprove").text('Approve');
					// enable button
					$("#approveOrRejectMessage").html("<b><font color='Red'>This Application cannot be approved as it has been reopened by the candidate.</font></b>");
				}
			}
			
			});
		}
		
	});
	
	$('#finalReject').click(function(e){
	e.preventDefault();
	var comment=$('#approvalOrRejectionComment').val();
	console.log('abbbbc');
	if(comment!='')
	{
	$("#commentError").removeClass("has-error");
            $("#commentErrorMsg").html("");
	$.ajax({
				type: 'GET', // define the type of HTTP verb we want to use (POST for our form)
				url: 'partials/update/updateStudentRejectDBTDetails.php', // the url where we want to POST
				data: $("#finalApproveOrReject").serialize(), // our data object
				//encode: true
				beforeSend: function() {
								$("#approvedTutionFees").prop("disabled", true);
								$("#approvedHostelFees").prop("disabled", true);
								$("#approvedBookNStationaryCharges").prop("disabled", true);
								$("#approvedOtherCharges").prop("disabled", true);
								$("#approvedTotalA").prop("disabled", true);
								$("#approvedTotalB").prop("disabled", true);
								$("#approvalOrRejectionComment").prop("disabled", true);
								$("#finalApprove").prop("disabled", true);
								$("#finalSave").prop("disabled", true);
								 // disable button
								$("#finalReject").text('Rejecting...');
								$("#finalReject").prop("disabled", true);
								
			},
			success:function(data) {
			
				var reply = data.replace(/\s+/, ""); 
				// log data to the console so we can see
				console.log(data);
				if (reply == 'success'){
					$("#finalReject").text('Reject');
					 // enable button
					$("#approveOrRejectMessage").html("<b><font color='Green'>Application Rejected Successfully</font></b>");
				// here we will handle errors and validation messages
				}
				if(reply == 'failure')
				{
					$("#finalReject").text('Reject');
					$("#finalSave").prop("disabled", false);
					$("#finalReject").prop("disabled", false);
					$("#finalApprove").prop("disabled", false);// enable button
					$("#approveOrRejectMessage").html("<b><font color='Red'>Fail to Approve</font></b>");
				}
				if(reply == 'Approved')
				{
					$("#finalReject").text('Reject');
					// enable button
					$("#approveOrRejectMessage").html("<b><font color='Red'>This Application is already been Approved</font></b>");
				}
				if(reply == 'Rejected')
				{
					$("#finalReject").text('Reject');
					// enable button
					$("#approveOrRejectMessage").html("<b><font color='Red'>This Application is already been Rejected</font></b>");
				}
			}
			
			});
		
		}
		else
		{
			$("#commentError").addClass("has-error");
            $("#commentErrorMsg").html("This is required field").css("color", "#a94442");
		}
	});
	
	$('#Reject').click(function(e){
	e.preventDefault();
	var comment=$('#approvalOrRejectionComment').val();
	console.log()
	if(comment!='')
	{
	$("#commentError").removeClass("has-error");
            $("#commentErrorMsg").html("");
	$.ajax({
				type: 'GET', // define the type of HTTP verb we want to use (POST for our form)
				url: 'partials/update/updateStudentRejectDBTDetails.php', // the url where we want to POST
				data: $("#approveOrReject").serialize(), // our data object
				//encode: true
				beforeSend: function() {
								$("#approvedTutionFees").prop("disabled", true);
								$("#approvedHostelFees").prop("disabled", true);
								$("#approvedBookNStationaryCharges").prop("disabled", true);
								$("#approvedOtherCharges").prop("disabled", true);
								$("#approvedTotalA").prop("disabled", true);
								$("#approvedTotalB").prop("disabled", true);
								$("#approvalOrRejectionComment").prop("disabled", true);
								$("#Approve").prop("disabled", true);
								$("#Save").prop("disabled", true);
								 // disable button
								$("#Reject").text('Rejecting...');
								$("#Reject").prop("disabled", true);
								
			},
			success:function(data) {
			
				var reply = data.replace(/\s+/, ""); 
				// log data to the console so we can see
				console.log(data);
				if (reply == 'success'){
					$("#Reject").text('Reject');
					 // enable button
					$("#approveOrRejectMessage").html("<b><font color='Green'>Application Rejected Successfully</font></b>");
				// here we will handle errors and validation messages
				}
				if(reply == 'failure')
				{
					$("#Reject").text('Reject');
					$("#Reject").prop("disabled", false);
					$("#Save").prop("disabled", false);
					$("#Approve").prop("disabled", false);// enable button
					$("#approveOrRejectMessage").html("<b><font color='Red'>Fail to Approve</font></b>");
				}
				if(reply == 'Approved')
				{
					$("#Reject").text('Reject');
					// enable button
					$("#approveOrRejectMessage").html("<b><font color='Red'>This Application is already been Approved</font></b>");
				}
				if(reply == 'Rejected')
				{
					$("#Reject").text('Reject');
					// enable button
					$("#approveOrRejectMessage").html("<b><font color='Red'>This Application is already been Rejected</font></b>");
				}
			}
			
			});
		
		}
		else
		{
			$("#commentError").addClass("has-error");
            $("#commentErrorMsg").html("This is required field").css("color", "#a94442");
		}
	});
	$('#finalSave').click(function(e){
	e.preventDefault();
	var approvedTotalB=$('#approvedTotalB').val();
	if(approvedTotalB=='' || approvedTotalB==null)
		{
			approvedTotalB=0;
		}
		console.log($("#finalApproveOrReject").valid() && tutionFees()==true && approvedTotalB>=100000);
	if($("#finalApproveOrReject").valid() && tutionFees()==true && approvedTotalB<=100000)
	{
	$.ajax({
				type: 'GET', // define the type of HTTP verb we want to use (POST for our form)
				url: 'partials/update/saveFinalDBTDetails.php', // the url where we want to POST
				data: $("#finalApproveOrReject").serialize(), // our data object
				//encode: true
				beforeSend: function() {
								$("#paymentType").prop("disabled", true);
								$("#courseDuration").prop("disabled", true);
								$("#approvedTutionFees").prop("disabled", true);
								$("#approvedHostelFees").prop("disabled", true);
								$("#approvedBookNStationaryCharges").prop("disabled", true);
								$("#approvedOtherCharges").prop("disabled", true);
								$("#approvedTotalA").prop("disabled", true);
								$("#approvedTotalB").prop("disabled", true);
								$("#approvalOrRejectionComment").prop("disabled", true);
								$("#finalApprove").prop("disabled", true);
								$("#finalReject").prop("disabled", true);
								$("#finalSave").prop("disabled", true);
								$("#finalSave").text('Saving ...');
								
			},
			success:function(data) {
			
				var reply = data.replace(/\s+/, ""); 
				// log data to the console so we can see
				console.log(data);
				$("#paymentType").prop("disabled", false);
								$("#approvedTutionFees").prop("disabled", false);
								$("#approvedHostelFees").prop("disabled", false);
								$("#approvedBookNStationaryCharges").prop("disabled", false);
								$("#approvedOtherCharges").prop("disabled", false);
								$("#approvedTotalA").prop("disabled", false);
								$("#approvedTotalB").prop("disabled", false);
								$("#approvalOrRejectionComment").prop("disabled", false);
								$("#finalApprove").prop("disabled", false);
								$("#finalReject").prop("disabled", false);
								$("#finalSave").prop("disabled", false);
								$("#finalSave").text('Save');
				if (reply == 'success'){
					
					// enable button
					$("#approveOrRejectMessage").html("<b><font color='Green'>Application Saved Successfully</font></b>");
				// here we will handle errors and validation messages
				}
				if(reply == 'failure')
				{
										
					$("#approveOrRejectMessage").html("<b><font color='Red'>Fail to Save</font></b>");
				}
				if(reply == 'Approved')
				{
					
					// enable button
					$("#approveOrRejectMessage").html("<b><font color='Red'>This Application is already been Approved.</font></b>");
				}
				if(reply == 'Rejected')
				{
					
					// enable button
					$("#approveOrRejectMessage").html("<b><font color='Red'>This Application is already been Rejected.</font></b>");
				}
				if(reply == 'New')
				{
					
					// enable button
					$("#approveOrRejectMessage").html("<b><font color='Red'>This Application cannot be approved as it has been reopened by the candidate.</font></b>");
				}
			}
			
			});
		}
		
	});
	
	$('#Save').click(function(e){
	e.preventDefault();
	var approvedTotalB=$('#approvedTotalB').val();
	if(approvedTotalB=='' || approvedTotalB==null)
		{
			approvedTotalB=0;
		}
		console.log($("#approveOrReject").valid() && tutionFees()==true && approvedTotalB>=100000);
	if($("#approveOrReject").valid() && tutionFees()==true && approvedTotalB<=100000)
	{
	$.ajax({
				type: 'GET', // define the type of HTTP verb we want to use (POST for our form)
				url: 'partials/update/saveFinalDBTDetails.php', // the url where we want to POST
				data: $("#approveOrReject").serialize(), // our data object
				//encode: true
				beforeSend: function() {
								$("#paymentType").prop("disabled", true);
								$("#courseDuration").prop("disabled", true);
								$("#approvedTutionFees").prop("disabled", true);
								$("#approvedHostelFees").prop("disabled", true);
								$("#approvedBookNStationaryCharges").prop("disabled", true);
								$("#approvedOtherCharges").prop("disabled", true);
								$("#approvedTotalA").prop("disabled", true);
								$("#approvedTotalB").prop("disabled", true);
								$("#approvalOrRejectionComment").prop("disabled", true);
								$("#Approve").prop("disabled", true);
								$("#Reject").prop("disabled", true);
								$("#Save").prop("disabled", true);
								$("#Save").text('Saving ...');
								
			},
			success:function(data) {
			
				var reply = data.replace(/\s+/, ""); 
				// log data to the console so we can see
				console.log(data);
				$("#paymentType").prop("disabled", false);
								$("#approvedTutionFees").prop("disabled", false);
								$("#approvedHostelFees").prop("disabled", false);
								$("#approvedBookNStationaryCharges").prop("disabled", false);
								$("#approvedOtherCharges").prop("disabled", false);
								$("#approvedTotalA").prop("disabled", false);
								$("#approvedTotalB").prop("disabled", false);
								$("#approvalOrRejectionComment").prop("disabled", false);
								$("#Approve").prop("disabled", false);
								$("#Reject").prop("disabled", false);
								$("#Save").prop("disabled", false);
								$("#Save").text('Save');
				if (reply == 'success'){
					
					// enable button
					$("#approveOrRejectMessage").html("<b><font color='Green'>Application Saved Successfully</font></b>");
				// here we will handle errors and validation messages
				}
				if(reply == 'failure')
				{
										
					$("#approveOrRejectMessage").html("<b><font color='Red'>Fail to Save</font></b>");
				}
				if(reply == 'Approved')
				{
					
					// enable button
					$("#approveOrRejectMessage").html("<b><font color='Red'>This Application is already been Approved.</font></b>");
				}
				if(reply == 'Rejected')
				{
					
					// enable button
					$("#approveOrRejectMessage").html("<b><font color='Red'>This Application is already been Rejected.</font></b>");
				}
				if(reply == 'New')
				{
					
					// enable button
					$("#approveOrRejectMessage").html("<b><font color='Red'>This Application cannot be approved as it has been reopened by the candidate.</font></b>");
				}
			}
			
			});
		}
		
	});
});

function tutionFees()
{
var approvedTutionFees = $("#approvedTutionFees").val();
        var collegeCategory='';
		var result='';
		var amount=0;
		var total=0;
		if(approvedTutionFees=='' || approvedTutionFees==null)
		{
			approvedTutionFees=0;
		}
		
		console.log(approvedTutionFees);
		if(approvedTutionFees!='')
		{
		 total = parseFloat(approvedTutionFees);
		}
		else
		{
			total=0;
		}
       
		
		var admissionThroughCCP=$("#admissionThroughCCP").val();
		var yearOfCounselling=$("#yearOfCounselling").val();
		if(admissionThroughCCP=='Yes')
		{
		if(yearOfCounselling=='2015-16')
		{
		collegeCategory=$("#category").val();
		}
		else
		{
		collegeCategory=$("#stream").val();
		}
		}
		if(admissionThroughCCP=='No')
		{
			collegeCategory=$("#stream").val();
		}
		console.log(collegeCategory);
		if(collegeCategory=='Engineering and Technology')
		{
			collegeCategory='Engineering';
		}
		/*if(collegeCategory=='General' || collegeCategory=='GENERAL')
		{
			if(total<=30000)
			{
				result='done';
			}
			else
			{	amount=30000;
				result='error';
			}
		}*/
		if(collegeCategory=='Engineering' || collegeCategory=='ENGINEERING' || collegeCategory=='General' || collegeCategory=='GENERAL')
		{
			if(total<=125000)
			{
				result='done';
			}
			else
			{	amount=125000;
				result='error';
			}
		}
		if(collegeCategory=='Medical' || collegeCategory=='MEDICAL')
		{
			if(total<=300000)
			{
				result='done';
			}
			else
			{	amount=300000;
				result='error';
			}
		}
		$("#approvedTotalA").val(total).trigger("change");
		if(result=='done')
		{
		
		$("#tutionFeesError").removeClass("has-error");
		$("#tutionFeesErrorMsg").html('');
		return true;
        
		}
		else
		{
			$("#tutionFeesError").addClass("has-error");
            $("#tutionFeesErrorMsg").html("For "+collegeCategory+" Degree Courses ,Tution Fee should be less than or equal to Rs."+amount+"/-").css("color", "#a94442");
		}
}
//Provision for Approve and complete Scholarship/ Complete Scholarship/

$('#ApproveAndCompleteScholarship').click(function(e)
	{
		/*$("#ApproveAndCompleteScholarship").click(function(e){
			var idClicked = e.target.id;
			console.log(idClicked+'aaaa');
		});*/
		var type='ApproveAndCompleteScholarship';
		var comments=$("#Comments").val();
		var declaration=$("#declaration").val();
		e.preventDefault();
		var approvedTotalB=$('#approvedTotalB').val();
		if(approvedTotalB=='' || approvedTotalB==null)
			{
				approvedTotalB=0;
			}
			//console.log($("#finalApproveOrReject").valid() && tutionFees()==true && approvedTotalB>=100000);
			console.log('lasklakslas');
		if($("#finalApproveOrReject").valid() && validateComments()==true && tutionFees()==true && $("#declaration").prop('checked') == true && approvedTotalB<=100000)
		{	
			$.ajax({
					type: 'GET', // define the type of HTTP verb we want to use (POST for our form)
					url: 'partials/update/updateFinalDBTDetails.php?type='+type+'&comments='+comments+'&declaration='+declaration, // the url where we want to POST
					data: $("#finalApproveOrReject").serialize(), // our data object
					//encode: true
					beforeSend: function() {
									$("#paymentType").prop("disabled", true);
									$("#courseDuration").prop("disabled", true);
									$("#approvedTutionFees").prop("disabled", true);
									$("#approvedHostelFees").prop("disabled", true);
									$("#approvedBookNStationaryCharges").prop("disabled", true);
									$("#approvedOtherCharges").prop("disabled", true);
									$("#approvedTotalA").prop("disabled", true);
									$("#approvedTotalB").prop("disabled", true);
									$("#approvalOrRejectionComment").prop("disabled", true);
									$("#ApproveAndCompleteScholarship").prop("disabled", true);
									$("#finalReject").prop("disabled", true);	
									$("#finalSave").prop("disabled", true);	// disable button
									$("#ApproveAndCompleteScholarship").text('Approving ...');
									
				},
				success:function(data) {
				
					var reply = data.replace(/\s+/, ""); 
					// log data to the console so we can see
					console.log(data);
					if (reply == 'success'){
						$("#ApproveAndCompleteScholarship").text('Submit');
						// enable button
						$("#finalReject").prop("disabled", true);	
						$("#finalSave").prop("disabled", true);	
						$("#finalApprove").prop("disabled", true);	
						$("#ApproveAndCompleteMessage").html("<b><font color='Green'><i>Application Approved Successfully</font></i></b>");
						 setTimeout(function()
							{
								$("#ApproveAndCompleteMessage").html("");
								   window.location.href = "index.php?q=approvedYearWise";
							},4000);
					// here we will handle errors and validation messages
					}
					if(reply == 'failure')
					{
						$("#ApproveAndCompleteScholarship").text('Submit');
						$("#ApproveAndCompleteScholarship").prop("disabled", false);
						$("#finalReject").prop("disabled", false);	
						$("#finalSave").prop("disabled", false);// enable button
						$("#ApproveAndCompleteMessage").html("<b><font color='Red'><i>Fail to Approve</font></i></b>");
					}
					if(reply == 'Approved')
					{
						$("#ApproveAndCompleteScholarship").text('Submit');
						// enable button
						$("#ApproveAndCompleteMessage").html("<b><font color='Red'><i>This Application is already been Approved.</font></i></b>");
					}
					if(reply == 'Rejected')
					{
						$("#ApproveAndCompleteScholarship").text('Submit');
						// enable button
						$("#ApproveAndCompleteMessage").html("<b><font color='Red'><i>This Application is already been Rejected.</font></i></b>");
					}
					if(reply == 'New')
					{
						$("#ApproveAndCompleteScholarship").text('Submit');
						// enable button
						$("#ApproveAndCompleteMessage").html("<b><font color='Red'><i>This Application cannot be approved as it has been reopened by the candidate.</font></i></b>");
					}
				}
				
				});
			}
			else if(validateComments()==false){
				$("#ApproveAndCompleteMessage").html("<b><font color='Red'><i>Please Enter the Reason</i></font></b>");
					 setTimeout(function()
							{
								$("#ApproveAndCompleteMessage").html("");
							},4000);		
			}
			else if($("#declaration").prop('checked') == false){
				$("#ApproveAndCompleteMessage").html("<b><font color='Red'><i>Tick the CheckBox and Submit</i></font></b>");
					 setTimeout(function()
							{
								$("#ApproveAndCompleteMessage").html("");
							},4000);		
			}
			else{
				$("#ApproveAndCompleteMessage").html("<b><font color='Red'><i>Please fill all required details.</i></font></b>");
					 setTimeout(function()
							{
								$("#ApproveAndCompleteMessage").html("");
							},4000);		
			}
		
	});
	function validateComments()
	{
		if($("#Comments").val()=='' || $("#Comments").val()==null)
		{
			$('#ApproveAndCompleteMessage').html('<font color="red"><i>Please Enter the Reason</i></font>');
			return false;
		}else{
			return true;
		}
	}
	
$('#CompleteScholarship').click(function(e)
	{
		/*$("#ApproveAndCompleteScholarship").click(function(e){
			var idClicked = e.target.id;
			console.log(idClicked+'aaaa');
		});*/
		var comments=$("#Comments").val();
		var declaration=$("#declaration").val();
		var candidateId=$("#candidateID").val();
		e.preventDefault();
		if(validateComments()==true &&  $("#declaration").prop('checked') == true )
		{	
			$.ajax({
					type: 'GET', // define the type of HTTP verb we want to use (POST for our form)
					url: 'partials/update/updateCompleteScholarshipDetails.php', // the url where we want to POST
					data: {comments:comments, declaration:declaration, candidateId:candidateId},		 // our data object
					//encode: true
					beforeSend: function() {
									$("#CompleteScholarship").text('Completing ...');
									
				},
				success:function(data) {
					var reply = data.replace(/\s+/, ""); 
					// log data to the console so we can see
					console.log(data);
					if (reply == 'success'){
						// enable button
						$("#CompleteMessage").html("<b><font color='Green'><i>Application Completed Successfully</font></i></b>");
						 setTimeout(function()
							{
								$("#CompleteMessage").html("");
								   window.location.href = "index.php?q=finalApprovedYearWise";
							},4000);
					// here we will handle errors and validation messages
					}
					if(reply == 'failure')
					{
						$("#CompleteScholarship").prop("disabled", false);
						$("#CompleteMessage").html("<b><font color='Red'><i>Fail to Approve</font></i></b>");
					}
					if(reply == 'Approved')
					{
						$("#CompleteMessage").html("<b><font color='Red'><i>This Application is already been Approved.</font></i></b>");
					}
					if(reply == 'Rejected')
					{
						$("#CompleteMessage").html("<b><font color='Red'><i>This Application is already been Rejected.</font></i></b>");
					}
					if(reply == 'New')
					{
						$("#CompleteMessage").html("<b><font color='Red'><i>This Application cannot be approved as it has been reopened by the candidate.</font></i></b>");
					}
					if(reply == 'completed')
					{
						$("#CompleteMessage").html("<b><font color='Red'><i>Scholarship is already completed for this application</font></i></b>");
					}else{
						
						$("#CompleteMessage").html("<b><font color='Red'><i>"+reply+"</font></i></b>");
					}
					$("#CompleteScholarship").text('Completed');
						// enable button
					
				}
				
				});
			}
			else if(validateComments()==false){
				$("#CompleteMessage").html("<b><font color='Red'><i>Please Enter the Reason</i></font></b>");
					 setTimeout(function()
							{
								$("#CompleteMessage").html("");
							},4000);		
			}
			else if($("#declaration").prop('checked') == false){
				$("#CompleteMessage").html("<b><font color='Red'><i>Tick the CheckBox and Submit</i></font></b>");
					 setTimeout(function()
							{
								$("#CompleteMessage").html("");
							},4000);		
			}
			else{
				$("#CompleteMessage").html("<b><font color='Red'><i>Please fill all required details.</i></font></b>");
					 setTimeout(function()
							{
								$("#CompleteMessage").html("");
							},4000);		
			}
		
	});