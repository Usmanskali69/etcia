<?php
	require_once(realpath("./session/session_verify.php"));
?>
<!DOCTYPE html>
<html lang="en">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="SUVOJIT AOWN">

		<title>J&K Scholarships HO</title>

		<!-- Bootstrap Core CSS -->
		<link href="../css/bootstrap.min.css" rel="stylesheet">

		<!-- Bootstrap Table CSS -->
		<link href="../css/bootstrap-table.min.css" rel="stylesheet" >
		
		<!-- Custom Fonts -->
		<link href="../font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		
		<link href="../css/style.css" rel="stylesheet" type="text/css">
		
		
	</head>

	<body>
		<div id="header" class="navbar navbar-default navbar-fixed-top">
			<div class="navbar-header">
				<button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target=".navbar-collapse">
					<i class="fa fa-bars"></i>
				</button>
				<a class="navbar-brand" href="index.php">
					<i class="fa fa-graduation-cap fa-lg"></i> J&K Scholarships
				</a>
			</div>
			<nav class="collapse navbar-collapse">
				
				<ul class="nav navbar-nav pull-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
									<i class="fa fa-user fa-lg"></i> <?php echo $_SESSION['hoId']; ?><b class="caret"></b></a>
						<ul class="dropdown-menu pull-right">
									
									<li><a href="session/auth.php?do=logout"><i class="fa fa-power-off"></i> Logout</a></li>
						</ul>
					</li>
				</ul>

			</nav>
		</div>
		
		<nav>
				
		<div id="wrapper">
				<div id="sidebar-wrapper" class="col-lg-2">
					<div id="sidebar">
						<ul class="nav list-group">
						<?php if($_SESSION['hoId']=='JKCELL'){?>
							<li>
								<a class="list-group-item" href="?q=submittedCCP"><i class="glyphicon glyphicon-check"></i>Submitted DBT Application Through Central Counselling Process</a>
							</li>
							<li>
								<a class="list-group-item" href="?q=submittedNonCCP"><i class="glyphicon glyphicon-check"></i>Submitted DBT Application Through Other Counselling</a>
							</li>
							<li>
								<a class="list-group-item" href="?q=submittedCCPPA"><i class="glyphicon glyphicon-check"></i>Submitted Application of Previous Year Students</a>
							</li>
							<li>
								<a class="list-group-item" href="?q=approved"><i class="glyphicon glyphicon-ok"></i>Approved Application</a>
							</li>
							<li>
								<a class="list-group-item" href="?q=finalApproved"><i class="glyphicon glyphicon-ok"></i>DBT Approved Application</a>
							</li>
							<li>
								<a class="list-group-item" href="?q=rejected"><i class="glyphicon glyphicon-remove"></i>Rejected Application</a>
							</li>
							<li>
								<a class="list-group-item" href="?q=allYearApproved"><i class="glyphicon glyphicon-check"></i>All DBT Approved Applications</a>
							</li>
							<?php }?>
							<?php if($_SESSION['hoId']=='JKCELL2012-13' || $_SESSION['hoId']=='JKCELL2013-14' || $_SESSION['hoId']=='JKCELL2014-15' || $_SESSION['hoId']=='JKCELL2015-16'){?>
							<li>
								<a class="list-group-item" href="?q=submittedCCPYearWise"><i class="glyphicon glyphicon-check"></i>Submitted DBT Application Through CCP</a>
							</li>
							<li>
								<a class="list-group-item" href="?q=submittedNonCCPYearWise"><i class="glyphicon glyphicon-check"></i>Submitted DBT Application Through Other Counselling</a>
							</li>
							<li>
								<a class="list-group-item" href="?q=approvedYearWise"><i class="glyphicon glyphicon-ok"></i>Approved Application</a>
							</li>
							<li>
								<a class="list-group-item" href="?q=finalApprovedYearWise"><i class="glyphicon glyphicon-ok"></i>DBT Approved Application</a>
							</li>
							<li>
								<a class="list-group-item" href="?q=rejectedYearWise"><i class="glyphicon glyphicon-remove"></i>Rejected Application</a>
							</li>
							<li>
								<a class="list-group-item" href="?q=allYearApprovedYearWise"><i class="glyphicon glyphicon-check"></i>All Year Approved Applications</a>
							</li>
							<?php }
							if($_SESSION['hoId']=='JKFINANCE1' || $_SESSION['hoId']=='JKFINANCE2' || $_SESSION['hoId']=='JKGOV')
							{?>
							<li>
								<a class="list-group-item" href="?q=approved"><i class="glyphicon glyphicon-ok"></i>Approved Application</a>
							</li>
							<?php } ?>
						</ul>
					</div>
				</div>
				
				<div id="main-wrapper" class="col-lg-10 col-sm-12">
					<div id="main">
					  
						<div>
							<?php
						
								$q=$_GET['q'];
								if($q == "submittedCCP")
								{
									include('partials\SubmittedApplicationList.php');
								}else if($q == "submittedNonCCP")
								{
									include('partials\SubmittedApplicationNonCCPList.php');
								}else if($q == "submittedCCPPA")
								{
									include('partials\SubmittedApplicationPreviouslyAllottedList.php');
								}else if($q == "approved"){
									include('partials\approvedApplicationList.php');
								}else if($q == "finalApproved"){
									include('partials\finalApprovedApplicationList.php');
								}else if($q == "rejected"){
									include('partials\rejectedApplicationList.php');
								}else if($q == "submittedCCPYearWise")
								{
									include('partials\SubmittedApplicationListYearWise.php');
								}else if($q == "submittedNonCCPYearWise")
								{
									include('partials\SubmittedApplicationNonCCPListYearWise.php');
								}else if($q == "approvedYearWise"){
									include('partials\approvedApplicationYearWiseList.php');
								}else if($q == "finalApprovedYearWise"){
									include('partials\finalApprovedApplicationYearWiseList.php');
								}else if($q == "rejectedYearWise"){
									include('partials\rejectedApplicationYearWiseList.php');
								}
								else if($q == 'allYearApproved'){
									include('partials\AllYearDBTApprovedDetailsList.php');
								}
								else if($q == 'allYearApprovedYearWise'){
									include('partials\AllYearDBTApprovedDetailsListYearWise.php');
								}
								else{
									if($_SESSION['hoId']=='JKCELL'){
									include('partials\SubmittedApplicationList.php');
									}
									else if($_SESSION['hoId']=='JKFINANCE1' || $_SESSION['hoId']=='JKFINANCE2' || $_SESSION['hoId']=='JKGOV')
									{
										include('partials\approvedApplicationList.php');
									}
									else
									{
										include('partials\SubmittedApplicationListYearWise.php');
									}
								}
							
							?>
						</div>
					  
					</div>
				</div>
		</div>
		
		
		</nav>
		
		
		
		<div class="footer">
			&copy;  HO Panel by AICTE. All rights Reserved.
		</div>
				
		<script type="text/javascript" src="../js/jquery.js"></script>
		<script type="text/javascript" src="../js/jquery.validate.min.js"></script>
		<script type="text/javascript" src="../js/bootstrap.min.js"></script>
		<script type="text/javascript" src="../js/bootstrap-table.js"></script>
		<script type="text/javascript" src="../js//bootstrap-table-export.js"></script>
		<script type="text/javascript" src="../js/tableExport.js"></script>
		<script type="text/javascript" src="js/custom.js"></script>
		<script type="text/javascript" src="js/custom1.js"></script>
		
		<script>
			function operateFormatterVerified(value, row, index) {
				return [
					
					'<a class="edit ml10" href="javascript:void(0)" title="Edit">',
						'<i class="glyphicon glyphicon-edit"></i>',
					'</a>&nbsp;'
				].join('');
			}
			function operateFormatterVerified1(value, row, index) {
				return [
					
					'<a class="editApprove ml10" href="javascript:void(0)" title="Edit">',
						'<i class="glyphicon glyphicon-edit"></i>',
					'</a>&nbsp;'
				].join('');
			}
			
			function operateFormatterVerified2(value, row, index) {
				return [
					
					'<a class="editFinalApprove ml10" href="javascript:void(0)" title="Edit">',
						'<i class="glyphicon glyphicon-edit"></i>',
					'</a>&nbsp;'
				].join('');
			}
			function operateFormatterVerifiedAllYear(value, row, index) {
				return [
					
					'<a class="editFinalApproveAllYear ml10" href="javascript:void(0)" title="Edit">',
						'<i class="glyphicon glyphicon-edit"></i>',
					'</a>&nbsp;'
				].join('');
			}
			window.operateEvents = {
				
				'click .edit': function (e, value, row, index) {
					window.location = "approvalPage.php?candidateID="+row.Candidate_Id+"&edit=NotApproved";
				},
				'click .editApprove': function (e, value, row, index) {
					window.location = "approvalPage.php?candidateID="+row.Candidate_Id+"&edit=Approved";
				},
				'click .editFinalApprove': function (e, value, row, index) {
					window.location = "approvalPage.php?candidateID="+row.Candidate_Id+"&edit=FinalApproved";
				},
				'click .editFinalApproveAllYear': function (e, value, row, index) {
					window.location = "approvalPage.php?candidateID="+row.Candidate_Id+"&edit=FinalApprovedAllYear";
				},
			};
			
			
	
			
		</script>
	</body>
</html>