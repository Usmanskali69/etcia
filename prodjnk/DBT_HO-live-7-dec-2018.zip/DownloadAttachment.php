<?php
	session_start();
	include('db_connect.php');
	
	if(isset($_GET['studentUniqueId'])){
		$studentUniqueId=strip_tags(mysqli_real_escape_string($con,$_GET['studentUniqueId']));
	}else{
		$studentUniqueId=$_SESSION['studentUniqueId'];
	}
	
	if(isset($_REQUEST['attachmentName']))
	{
		$attachType = strip_tags(mysqli_real_escape_string($con,$_REQUEST['attachmentName']));
		
		//$query="SELECT * FROM students WHERE studentUniqueId='".$studentUniqueId."'";
		//$result = mysqli_query($con,$query);
		
		$query="SELECT * FROM students WHERE studentUniqueId=?";
		$stmt1 =mysqli_prepare($con, $query);
				mysqli_stmt_bind_param($stmt1, 'i', $studentUniqueId);
				mysqli_stmt_execute($stmt1);
				$result = mysqli_stmt_get_result($stmt1);
		$user_row = mysqli_fetch_array($result, MYSQLI_ASSOC);
		
		if($attachType == "joiningReport"){
			$dir = '../img/uploads/joiningReport/';
			$joiningReport_dir =pathinfo('../'.$user_row['joiningReport'],PATHINFO_DIRNAME);
			$joiningReport_filename =pathinfo('../'.$user_row['joiningReport'],PATHINFO_BASENAME);
			//print_r($joiningReport);
			
			if(is_dir($joiningReport_dir)){
				//echo 'hai';
				if($dh = opendir($joiningReport_dir)){
					while($file = readdir($dh)){
						$fileFound[] = $file;
						//print_r($fileFound);
					}
					if(in_array($joiningReport_filename,$fileFound)){
						$key = array_search($joiningReport_filename,$fileFound,true);
						$existFile = $fileFound[$key];
						$path_parts = pathinfo($existFile);
						$ext = strtolower($path_parts["extension"]);
						//$extension = pathinfo($joiningReport,PATHINFO_EXTENSION);
						
						header('Content-Description: File Attach Download');
						header('Content-Type: application/jpeg');
						header('Content-Type: application/download');
						header('Content-Disposition: attachment; filename="'.$fileFound[$key].'"');
						header('Expires: 0');
						header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
						header('Content-Length: '.filesize('../'.$dir.$fileFound[$key]));
						ob_clean();
						flush();
						readfile($dir.$fileFound[$key]);
						exit;	
					}
					
				}
			}
		}
		if($attachType == "joiningtutionhostelReceipt"){
			$dir = '../img/uploads/joiningtutionhostelReceipt/';
			$joiningtutionhostelReceipt_dir =pathinfo('../'.$user_row['joiningtutionhostelReceipt'],PATHINFO_DIRNAME);
			$joiningtutionhostelReceipt_filename =pathinfo('../'.$user_row['joiningtutionhostelReceipt'],PATHINFO_BASENAME);
			//print_r($joiningReport);
			
			if(is_dir($joiningtutionhostelReceipt_dir)){
				//echo 'hai';
				if($dh = opendir($joiningtutionhostelReceipt_dir)){
					while($file = readdir($dh)){
						$fileFound[] = $file;
						//print_r($fileFound);
					}
					if(in_array($joiningtutionhostelReceipt_filename,$fileFound)){
						$key = array_search($joiningtutionhostelReceipt_filename,$fileFound,true);
						$existFile = $fileFound[$key];
						$path_parts = pathinfo($existFile);
						$ext = strtolower($path_parts["extension"]);
						//$extension = pathinfo($joiningReport,PATHINFO_EXTENSION);
						
						header('Content-Description: File Attach Download');
						header('Content-Type: application/jpeg');
						header('Content-Type: application/download');
						header('Content-Disposition: attachment; filename="'.$fileFound[$key].'"');
						header('Expires: 0');
						header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
						header('Content-Length: '.filesize('../'.$dir.$fileFound[$key]));
						ob_clean();
						flush();
						readfile($dir.$fileFound[$key]);
						exit;	
					}
					
				}
			}
		}
		
		if($attachType == "hscmarksheetfile"){
			$dir = '../img/uploads/hscMarksheet/';
			$hscmarksheetfile_dir =pathinfo('../'.$user_row['hscmarksheetfile'],PATHINFO_DIRNAME);
			$hscmarksheetfile_filename =pathinfo('../'.$user_row['hscmarksheetfile'],PATHINFO_BASENAME);
			//print_r($joiningReport);
			
			if(is_dir($hscmarksheetfile_dir)){
				//echo 'hai';
				if($dh = opendir($hscmarksheetfile_dir)){
					while($file = readdir($dh)){
						$fileFound[] = $file;
						//print_r($fileFound);
					}
					if(in_array($hscmarksheetfile_filename,$fileFound)){
						$key = array_search($hscmarksheetfile_filename,$fileFound,true);
						$existFile = $fileFound[$key];
						$path_parts = pathinfo($existFile);
						$ext = strtolower($path_parts["extension"]);
						//$extension = pathinfo($joiningReport,PATHINFO_EXTENSION);
						
						header('Content-Description: File Attach Download');
						header('Content-Type: application/jpeg');
						header('Content-Type: application/download');
						header('Content-Disposition: attachment; filename="'.$fileFound[$key].'"');
						header('Expires: 0');
						header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
						header('Content-Length: '.filesize('../'.$dir.$fileFound[$key]));
						ob_clean();
						flush();
						readfile($dir.$fileFound[$key]);
						exit;	
					}
					
				}
			}
		}
		
		if($attachType == "sscmarksheetfile"){
			$dir = '../img/uploads/sscMarksheet/';
			$sscmarksheetfile_dir =pathinfo('../'.$user_row['sscmarksheetfile'],PATHINFO_DIRNAME);
			$sscmarksheetfile_filename =pathinfo('../'.$user_row['sscmarksheetfile'],PATHINFO_BASENAME);
			//print_r($joiningReport);
			
			if(is_dir($sscmarksheetfile_dir)){
				//echo 'hai';
				if($dh = opendir($sscmarksheetfile_dir)){
					while($file = readdir($dh)){
						$fileFound[] = $file;
						//print_r($fileFound);
					}
					if(in_array($sscmarksheetfile_filename,$fileFound)){
						$key = array_search($sscmarksheetfile_filename,$fileFound,true);
						$existFile = $fileFound[$key];
						$path_parts = pathinfo($existFile);
						$ext = strtolower($path_parts["extension"]);
						//$extension = pathinfo($joiningReport,PATHINFO_EXTENSION);
						
						header('Content-Description: File Attach Download');
						header('Content-Type: application/jpeg');
						header('Content-Type: application/download');
						header('Content-Disposition: attachment; filename="'.$fileFound[$key].'"');
						header('Expires: 0');
						header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
						header('Content-Length: '.filesize('../'.$dir.$fileFound[$key]));
						ob_clean();
						flush();
						readfile($dir.$fileFound[$key]);
						exit;	
					}
					
				}
			}
		}
		
		if($attachType == "feeReceipt"){
			$dir = '../img/uploads/feeReceipt/';
			$feeReceipt_dir =pathinfo('../'.$user_row['feeReceipt'],PATHINFO_DIRNAME);
			$feeReceipt_filename =pathinfo('../'.$user_row['feeReceipt'],PATHINFO_BASENAME);
			//print_r($feeReceipt);
			
			if(is_dir($feeReceipt_dir)){
				//echo 'hai';
				if($dh = opendir($feeReceipt_dir)){
					while($file = readdir($dh)){
						$fileFound[] = $file;
						//print_r($fileFound);
					}
					if(in_array($feeReceipt_filename,$fileFound)){
						$key = array_search($feeReceipt_filename,$fileFound,true);
						/* $existFile = $fileFound[$key];
						$path_parts = pathinfo($existFile);
						$ext = strtolower($path_parts["extension"]); */
						//$extension = pathinfo($joiningReport,PATHINFO_EXTENSION);
						
						header('Content-Description: File Attach Download');
						header('Content-Type: application/jpeg');
						header('Content-Type: application/download');
						header('Content-Disposition: attachment; filename="'.$fileFound[$key].'"');
						header('Expires: 0');
						header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
						header('Content-Length: '.filesize('../'.$dir.$fileFound[$key]));
						ob_clean();
						flush();
						readfile($dir.$fileFound[$key]);
						exit;	
					}
					
				}
			}
		}
		
		if($attachType == "collegehostelReceipt"){
			$dir = '../img/uploads/collegehostelReceipt/';
			$collegehostelReceipt_dir =pathinfo('../'.$user_row['collegehostelReceipt'],PATHINFO_DIRNAME);
			$collegehostelReceipt_filename =pathinfo('../'.$user_row['collegehostelReceipt'],PATHINFO_BASENAME);
			//print_r($collegehostelReceipt);
			
			if(is_dir($collegehostelReceipt_dir)){
				//echo 'hai';
				if($dh = opendir($collegehostelReceipt_dir)){
					while($file = readdir($dh)){
						$fileFound[] = $file;
						//print_r($fileFound);
					}
					if(in_array($collegehostelReceipt_filename,$fileFound)){
						$key = array_search($collegehostelReceipt_filename,$fileFound,true);
						/* $existFile = $fileFound[$key];
						$path_parts = pathinfo($existFile);
						$ext = strtolower($path_parts["extension"]); */
						//$extension = pathinfo($joiningReport,PATHINFO_EXTENSION);
						
						header('Content-Description: File Attach Download');
						header('Content-Type: application/jpeg');
						header('Content-Type: application/download');
						header('Content-Disposition: attachment; filename="'.$fileFound[$key].'"');
						header('Expires: 0');
						header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
						header('Content-Length: '.filesize('../'.$dir.$fileFound[$key]));
						ob_clean();
						flush();
						readfile($dir.$fileFound[$key]);
						exit;	
					}
					
				}
			}
		}
		
		if($attachType == "bankPassBook"){
			$dir = '../img/uploads/bankPassBook/';
			$bankPassBook_dir =pathinfo('../'.$user_row['bankPassBook'],PATHINFO_DIRNAME);
			$bankPassBook_filename =pathinfo('../'.$user_row['bankPassBook'],PATHINFO_BASENAME);
			//print_r($bankPassBook);
			
			if(is_dir($bankPassBook_dir)){
				//echo 'hai';
				if($dh = opendir($bankPassBook_dir)){
					while($file = readdir($dh)){
						$fileFound[] = $file;
						//print_r($fileFound);
					}
					if(in_array($bankPassBook_filename,$fileFound)){
						$key = array_search($bankPassBook_filename,$fileFound,true);
						/* $existFile = $fileFound[$key];
						$path_parts = pathinfo($existFile);
						$ext = strtolower($path_parts["extension"]); */
						//$extension = pathinfo($joiningReport,PATHINFO_EXTENSION);
						
						header('Content-Description: File Attach Download');
						header('Content-Type: application/jpeg');
						header('Content-Type: application/download');
						header('Content-Disposition: attachment; filename="'.$fileFound[$key].'"');
						header('Expires: 0');
						header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
						header('Content-Length: '.filesize('../'.$dir.$fileFound[$key]));
						ob_clean();
						flush();
						readfile($dir.$fileFound[$key]);
						exit;	
					}
					
				}
			}
		}
		
		if($attachType == "aadharCard"){
			$dir = '../img/uploads/aadharCard/';
			$aadharCard_dir =pathinfo('../'.$user_row['aadharCard'],PATHINFO_DIRNAME);
			$aadharCard_filename =pathinfo('../'.$user_row['aadharCard'],PATHINFO_BASENAME);
			//print_r($aadharCard);
			
			if(is_dir($aadharCard_dir)){
				//echo 'hai';
				if($dh = opendir($aadharCard_dir)){
					while($file = readdir($dh)){
						$fileFound[] = $file;
						//print_r($fileFound);
					}
					if(in_array($aadharCard_filename,$fileFound)){
						$key = array_search($aadharCard_filename,$fileFound,true);
						/* $existFile = $fileFound[$key];
						$path_parts = pathinfo($existFile);
						$ext = strtolower($path_parts["extension"]); */
						//$extension = pathinfo($joiningReport,PATHINFO_EXTENSION);
						
						header('Content-Description: File Attach Download');
						header('Content-Type: application/jpeg');
						header('Content-Type: application/download');
						header('Content-Disposition: attachment; filename="'.$fileFound[$key].'"');
						header('Expires: 0');
						header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
						header('Content-Length: '.filesize('../'.$dir.$fileFound[$key]));
						ob_clean();
						flush();
						readfile($dir.$fileFound[$key]);
						exit;	
					}
					
				}
			}
		}
		
		if($attachType == "bookReceipt"){
			$dir = '../img/uploads/bookReceipt/';
			$bookReceipt_dir =pathinfo('../'.$user_row['bookReceipt'],PATHINFO_DIRNAME);
			$bookReceipt_filename =pathinfo('../'.$user_row['bookReceipt'],PATHINFO_BASENAME);
			//print_r($aadharCard);
			
			if(is_dir($bookReceipt_dir)){
				//echo 'hai';
				if($dh = opendir($bookReceipt_dir)){
					while($file = readdir($dh)){
						$fileFound[] = $file;
						//print_r($fileFound);
					}
					if(in_array($bookReceipt_filename,$fileFound)){
						$key = array_search($bookReceipt_filename,$fileFound,true);
						/* $existFile = $fileFound[$key];
						$path_parts = pathinfo($existFile);
						$ext = strtolower($path_parts["extension"]); */
						//$extension = pathinfo($joiningReport,PATHINFO_EXTENSION);
						
						header('Content-Description: File Attach Download');
						header('Content-Type: application/jpeg');
						header('Content-Type: application/download');
						header('Content-Disposition: attachment; filename="'.$fileFound[$key].'"');
						header('Expires: 0');
						header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
						header('Content-Length: '.filesize('../'.$dir.$fileFound[$key]));
						ob_clean();
						flush();
						readfile($dir.$fileFound[$key]);
						exit;	
					}
					
				}
			}
		}
		
		if($attachType == "rentReceipt"){
			$dir = '../img/uploads/rentReceipt/';
			$rentReceipt_dir =pathinfo('../'.$user_row['rentReceipt'],PATHINFO_DIRNAME);
			$rentReceipt_filename =pathinfo('../'.$user_row['rentReceipt'],PATHINFO_BASENAME);
			//print_r($rentReceipt);
			
			if(is_dir($rentReceipt_dir)){
				//echo 'hai';
				if($dh = opendir($rentReceipt_dir)){
					while($file = readdir($dh)){
						$fileFound[] = $file;
						//print_r($fileFound);
					}
					if(in_array($rentReceipt_filename,$fileFound)){
						$key = array_search($rentReceipt_filename,$fileFound,true);
						/* $existFile = $fileFound[$key];
						$path_parts = pathinfo($existFile);
						$ext = strtolower($path_parts["extension"]); */
						//$extension = pathinfo($joiningReport,PATHINFO_EXTENSION);
						
						header('Content-Description: File Attach Download');
						header('Content-Type: application/jpeg');
						header('Content-Type: application/download');
						header('Content-Disposition: attachment; filename="'.$fileFound[$key].'"');
						header('Expires: 0');
						header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
						header('Content-Length: '.filesize('../'.$dir.$fileFound[$key]));
						ob_clean();
						flush();
						readfile($dir.$fileFound[$key]);
						exit;	
					}
					
				}
			}
		}
		
		if($attachType == "otherIncidentalCharges"){
			$dir = '../img/uploads/otherIncidentalCharges/';
			$otherIncidentalCharges_dir =pathinfo('../'.$user_row['otherIncidentalCharges'],PATHINFO_DIRNAME);
			$otherIncidentalCharges_filename =pathinfo('../'.$user_row['otherIncidentalCharges'],PATHINFO_BASENAME);
			//print_r($rentReceipt);
			
			if(is_dir($otherIncidentalCharges_dir)){
				//echo 'hai';
				if($dh = opendir($otherIncidentalCharges_dir)){
					while($file = readdir($dh)){
						$fileFound[] = $file;
						//print_r($fileFound);
					}
					if(in_array($otherIncidentalCharges_filename,$fileFound)){
						$key = array_search($otherIncidentalCharges_filename,$fileFound,true);
						/* $existFile = $fileFound[$key];
						$path_parts = pathinfo($existFile);
						$ext = strtolower($path_parts["extension"]); */
						//$extension = pathinfo($joiningReport,PATHINFO_EXTENSION);
						
						header('Content-Description: File Attach Download');
						header('Content-Type: application/jpeg');
						header('Content-Type: application/download');
						header('Content-Disposition: attachment; filename="'.$fileFound[$key].'"');
						header('Expires: 0');
						header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
						header('Content-Length: '.filesize('../'.$dir.$fileFound[$key]));
						ob_clean();
						flush();
						readfile($dir.$fileFound[$key]);
						exit;	
					}
					
				}
			}
		}
		
		if($attachType == "joiningtutionhostelReceipt"){
			$dir = '../img/uploads/joiningtutionhostelReceipt/';
			$joiningtutionhostelReceipt_dir =pathinfo('../'.$user_row['joiningtutionhostelReceipt'],PATHINFO_DIRNAME);
			$joiningtutionhostelReceipt_filename =pathinfo('../'.$user_row['joiningtutionhostelReceipt'],PATHINFO_BASENAME);
			//print_r($rentReceipt);
			
			if(is_dir($joiningtutionhostelReceipt_dir)){
				//echo 'hai';
				if($dh = opendir($joiningtutionhostelReceipt_dir)){
					while($file = readdir($dh)){
						$fileFound[] = $file;
						//print_r($fileFound);
					}
					if(in_array($joiningtutionhostelReceipt_filename,$fileFound)){
						$key = array_search($joiningtutionhostelReceipt_filename,$fileFound,true);
						/* $existFile = $fileFound[$key];
						$path_parts = pathinfo($existFile);
						$ext = strtolower($path_parts["extension"]); */
						//$extension = pathinfo($joiningReport,PATHINFO_EXTENSION);
						
						header('Content-Description: File Attach Download');
						header('Content-Type: application/jpeg');
						header('Content-Type: application/download');
						header('Content-Disposition: attachment; filename="'.$fileFound[$key].'"');
						header('Expires: 0');
						header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
						header('Content-Length: '.filesize('../'.$dir.$fileFound[$key]));
						ob_clean();
						flush();
						readfile($dir.$fileFound[$key]);
						exit;	
					}
					
				}
			}
		}
		
		if($attachType == "hscmarksheet"){
			$dir = '../img/uploads/hscmarksheet/';
			$hscmarksheet_dir =pathinfo('../'.$user_row['hscmarksheet'],PATHINFO_DIRNAME);
			$hscmarksheet_filename =pathinfo('../'.$user_row['hscmarksheet'],PATHINFO_BASENAME);
			//print_r($rentReceipt);
			
			if(is_dir($hscmarksheet_dir)){
				//echo 'hai';
				if($dh = opendir($hscmarksheet_dir)){
					while($file = readdir($dh)){
						$fileFound[] = $file;
						//print_r($fileFound);
					}
					if(in_array($hscmarksheet_filename,$fileFound)){
						$key = array_search($hscmarksheet_filename,$fileFound,true);
						/* $existFile = $fileFound[$key];
						$path_parts = pathinfo($existFile);
						$ext = strtolower($path_parts["extension"]); */
						//$extension = pathinfo($joiningReport,PATHINFO_EXTENSION);
						
						header('Content-Description: File Attach Download');
						header('Content-Type: application/jpeg');
						header('Content-Type: application/download');
						header('Content-Disposition: attachment; filename="'.$fileFound[$key].'"');
						header('Expires: 0');
						header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
						header('Content-Length: '.filesize('../'.$dir.$fileFound[$key]));
						ob_clean();
						flush();
						readfile($dir.$fileFound[$key]);
						exit;	
					}
					
				}
			}
		}
		
		if($attachType == "sscmarksheet"){
			$dir = '../img/uploads/sscmarksheet/';
			$sscmarksheet_dir =pathinfo('../'.$user_row['sscmarksheet'],PATHINFO_DIRNAME);
			$sscmarksheet_filename =pathinfo('../'.$user_row['sscmarksheet'],PATHINFO_BASENAME);
			//print_r($rentReceipt);
			
			if(is_dir($sscmarksheet_dir)){
				//echo 'hai';
				if($dh = opendir($sscmarksheet_dir)){
					while($file = readdir($dh)){
						$fileFound[] = $file;
						//print_r($fileFound);
					}
					if(in_array($sscmarksheet_filename,$fileFound)){
						$key = array_search($sscmarksheet_filename,$fileFound,true);
						/* $existFile = $fileFound[$key];
						$path_parts = pathinfo($existFile);
						$ext = strtolower($path_parts["extension"]); */
						//$extension = pathinfo($joiningReport,PATHINFO_EXTENSION);
						
						header('Content-Description: File Attach Download');
						header('Content-Type: application/jpeg');
						header('Content-Type: application/download');
						header('Content-Disposition: attachment; filename="'.$fileFound[$key].'"');
						header('Expires: 0');
						header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
						header('Content-Length: '.filesize('../'.$dir.$fileFound[$key]));
						ob_clean();
						flush();
						readfile($dir.$fileFound[$key]);
						exit;	
					}
					
				}
			}
		}
	}