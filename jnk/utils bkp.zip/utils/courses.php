<?php
include('../db_connect.php');
$coursesId  = $_GET['courseid'];

echo '<div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Courses List</h4>
      </div>
      
        <div class="modal-body">';
$instsql    = "SELECT name, state, district, typeOfInstitute FROM colleges where collegeUniqueId = '$coursesId'";
$instresult = $con->query($instsql);
if ($instresult->num_rows > 0) {
    echo "<table>";
    while ($row = $instresult->fetch_assoc()) {
        echo "<tr><td><b>Institute Name</b></td><td><b> : </b></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $row['name'] . "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Institute Type</b></td><td><b> : </b></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $row['typeOfInstitute'] . "</td></tr>";
        echo "<tr><td><b>State</b></td><td><b>:</b></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $row['state'] . "</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>District</b></td><td><b>:</b></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $row['district'] . "</td></tr>";
        
        
    }
    echo "</table>";
    echo "<hr>";
}
$sql        = "SELECT courseUniqueId,
 courseName, category, university FROM courses where collegeUniqueId = '$coursesId' and Seats > 0";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    echo "<table class='table table-bordered'>";
    echo "<tr><th>Course ID</th><th>Course Name</th><th>Stream</th><th>Affilating University</th></tr>";
    // output data of each row
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["courseUniqueId"] . "</td><td>" . $row["courseName"] . "</td><td>" . $row["category"] . "</td><td>" . $row["university"] . "</td></tr>";
    }
    echo "</table>";
    
} else {
    echo "<font color='Red'>All Courses are filled</font>";
}
echo '</div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
      </div>';
$con->close();
?> 
