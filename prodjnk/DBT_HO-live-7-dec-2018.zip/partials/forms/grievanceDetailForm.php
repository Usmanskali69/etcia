<?php
	require_once(realpath("./session/session_verify.php"));
	$collegeNameQuery="select * from jnkcounciling.colleges where collegeUniqueId='".$grievance_row['grievanceCreatedById']."'";
	$collegeNameResult=mysqli_query($con,$collegeNameQuery);
	$collegeNameRow=mysqli_fetch_assoc($collegeNameResult);	
	mysqli_close ($con);
?>

	<fieldset>
		<div class="panel-body">
			<div class="col-sm-12" role="complementary">
<h3> Details of the Grievance (<?php echo $grievance_row['grievancesCreatedBy'];?>)</h3>
			<?php 
			if($grievance_row['grievanceCreatedById'] != 'Not yet registered' && $grievance_row['grievancesCreatedBy'] == 'Student') {
				?>
				<div class="panel panel-default">
					<div class="panel-body table-responsive">
					
					<table class="table table-bordered table-condensed f11">
						<tr>
							<td colspan="4" align="left" class="danger"><b>Personal Details of Applicant:</b></td>
						</tr>
						
						<tr>
							<td width="20%"  align="left"><b>Candidate Id :</b></td>
							<td width="55%"  align="left"><?php  echo $user_row['studentUniqueId'];?></td>
								
							<td valign="top" width="15%"  rowspan="6">
									<img src="../jk_media/<?php echo $user_row['photo'];?>" width="150" height="180" style="background: 10px solid black" >
							</td>
						</tr>
						<tr>
							<td align="left"><b>Name of the candidate:</b></td>
							<td align="left"> <?php echo $user_row['name'];?></td>
						</tr>
						<tr>
						
							<td align="left"><b>Gender:</b></td>
							<td align="left"><?php echo $user_row['gender'];?></td>
						</tr>
						<tr>
							<td align="left" ><b>Year of Counselling:</b></td>
							<td align="left" colspan="3" ><font color="red"><b><?php echo $user_row['yearOfCounselling'];?></b></font></td>
						</tr>
						<?php if($user_row['modeOfAdmission']!='') { ?>
						<tr>
							<td align="left"><b>Mode of Admission:</b></td>
							<td align="left" colspan="3" ><?php echo $user_row['modeOfAdmission'];?></td>
						</tr>
						<?php } ?>
						<tr>
							<td align="left"><b>Application Status:</b></td>
							<td align="left" colspan="3" ><?php echo $user_row['applicationStatus'];?></td>
						</tr>
						<tr>
							<td align="left"><b>DBT Application Status:</b></td>
							<td align="left" colspan="3" ><?php echo $user_row['DBTApplicationStatus'];?></td>
						</tr>
						<?php if($user_row['modeOfAdmission']=='Through Centralised counselling') { ?>
						<tr>
							<td align="left"><b>College Id:</b></td>
							<td align="left" colspan="3" ><?php echo ($user_row['collegeUniqueId']);?></td>
						</tr>
						<tr>
							<td align="left"><b>College Name:</b></td>
							<td align="left" colspan="3" ><?php echo $college_row['name'];?></td>
						</tr>
			            <?php } ?>
						<?php if($user_row['modeOfAdmission']=='On Your Own') { ?>
						<tr>
							<td align="left"><b>College Id:</b></td>
							<td align="left" colspan="3" ><?php echo ($user_row['otherStudentCollegeId']);?></td>
						</tr>
			            <?php } ?>
						
						
					</table>
					</div>
				</div>	
			<?php 
			}
			?>	
					
				
				
				<div class="panel panel-default">
					<div class="panel-body table-responsive">
					<table class="table table-bordered table-condensed f11">
						<tr>
							<td colspan="2" align="left" class="danger"><b>Grievance Details:</b></td>
						</tr>
						
						<tr>
							<td width="20%" align="left"><b>Grievance Id:</b></td>
							<td width="30%" align="left"><?php echo $grievance_row['grievanceId'];?></td>
						</tr>
						
						<?php if($grievance_row['grievanceCreatedById'] == 'Not yet registered') {?>
						<tr>
							<td width="20%" align="left"><b>Grievance Raised by:</b></td>
							<td width="30%" align="left"><?php echo $grievance_row['grievanceName'];?></td>
						</tr>
						<tr>
							<td width="20%" align="left"><b>Email Id:</b></td>
							<td width="30%" align="left"><?php echo $grievance_row['grievanceEmailId'];?></td>
						</tr>
						<tr>
							<td width="20%" align="left"><b>Mobile Number:</b></td>
							<td width="30%" align="left"><?php echo $grievance_row['grievanceMobileNumber'];?></td>
						</tr>
						<tr>
							<td width="20%" align="left"><b>Address:</b></td>
							<td width="30%" align="left"><?php echo $grievance_row['grievanceAddress'];?></td>
						</tr>
						<tr>
							<td width="20%" align="left"><b>State:</b></td>
							<td width="30%" align="left"><?php echo $grievance_row['grievanceState'];?></td>
						</tr>
						<tr>
							<td width="20%" align="left"><b>District:</b></td>
							<td width="30%" align="left"><?php echo $grievance_row['grievanceDistrict'];?></td>
						</tr>						
						<?php if($grievance_row['grievancesCreatedBy'] == 'Student') { ?>
						<tr>
							<td width="20%" align="left" ><b>Year of Counselling:</b></td>
							<td width="30%" align="left" ><font color="red"><b><?php echo $grievance_row['yearOfCounselling'];?></b></font></td>
						</tr>
						<tr>
							<td width="20%" align="left"><b>Name of the School:</b></td>
							<td width="30%" align="left"><?php echo $student_row['XIISchoolName'];?></td>
						</tr>
						<tr>
							<td width="20%" align="left"><b>12th Roll No:</b></td>
							<td width="30%" align="left"><?php echo $student_row['XIIRollNo'];?></td>
						</tr>
						<tr>
							<td width="20%" align="left"><b>Exam Type:</b></td>
							<td width="30%" align="left"><?php echo $student_row['XIIBoardName'];?></td>
						</tr>
						<tr>
							<td width="20%" align="left"><b>12th Year of Passing:</b></td>
							<td width="30%" align="left"><?php echo $student_row['XIIYearOfPassing'];?></td>
						</tr>
						<?php } ?>
						<?php }if(( preg_match('/^JK/', $grievance_row['grievanceCreatedById']) == 1) || ( preg_match('/^EGOVERNANCE/', $grievance_row['grievanceCreatedById']) == 1)) {
						 ?>
						<tr>
							<td width="20%" align="left"><b>Grievance Created By:</b></td>
							<td width="30%" align="left"><?php echo $grievance_row['grievanceCreatedById'];?></td>
						</tr>
						<?php } ?>
						<tr>
							<td width="20%" align="left"><b>Grievance Created By:</b></td>
							<td width="30%" align="left"><?php echo $grievance_row['grievanceCreatedById'].'-'.$collegeNameRow['name'];?></td>
						</tr>
						<tr>
							<td width="20%" align="left"><b>Stream:</b></td>
							<td width="30%" align="left"><?php if($collegeNameRow['actualCollegeCategory']!='') {echo $collegeNameRow['actualCollegeCategory'];} else {echo $collegeNameRow['category'];}?></td>
						</tr>
						<tr>
							<td width="20%" align="left"><b>Grievance Status:</b></td>
							<td width="30%" align="left"><?php echo $grievance_row['grievanceStatus'];?></td>
						</tr>
						<tr>
							<td width="20%" align="left"><b>Issue Related To:</b></td>
							<td width="30%" align="left"><?php echo $grievance_row['yearOfCounselling'];?></td>
						</tr>
						<tr>
							<td width="20%" align="left"><b>Created By:</b></td>
							<td width="30%" align="left"><?php echo $grievance_row['grievanceName'];?></td>
						</tr>
						<?php /*if(( preg_match('/^[1-9][0-9]/', $grievance_row['grievanceCreatedById']) != 0) ) {*/
						 ?>
						<tr>
							<td width="20%" align="left"><b>Grievance Nature:</b></td>
							<td width="30%" align="left"><font color="red"><b><?php echo $grievance_row['grievanceNature'];?></b></font></td>
							</tr>
							<?php /*} */?>
							<tr>
							<td width="20%" align="left"><b>Grievance Subject:</b></td>
							<td width="30%" align="left"><?php echo $grievance_row['grievanceSubject'];?></td>
						</tr>
						<tr>
							<td width="20%" align="left"><b>Description:</b></td>
							<td width="20%" align="left"><font color="red"><b><?php echo $grievance_row['grievanceDescription'];?></b></font></td>
							
						</tr>
						<tr>
							<td width="20%" align="left"><b>Grievance Assigned To:</b></td>
							<td width="20%" align="left"><?php echo $grievance_row['grievanceAssignedTo'];?></td>
							
						</tr>	
						<tr>
							<td width="20%" align="left"><b>Created on:</b></td>
							<td width="20%" align="left"><?php echo $grievance_row['grievanceCreatedOn'];?></td>
							
						</tr>	
					</table>
					</div>	
				</div>
				<div class="panel panel-default">
					<div class="panel-body table-responsive">
					<table class="table table-bordered table-condensed f11">
						<tr>
							<td colspan="4" align="left" class="danger"><b>Attachments:</b></td>
						</tr>
						
						<?php if($grievance_row['grievanceCreatedById']!='Not yet registered' && $attachments_num>0)
						{
						while($attachments_row = mysqli_fetch_assoc($attachmentsResult))
						{
						$imageFileType = pathinfo($attachments_row["attachmentPath"],PATHINFO_EXTENSION);
							if($imageFileType =='doc' || $imageFileType == 'docx'){
							$href='../'.$attachments_row["attachmentPath"];
							$modal='';
							}else{
							$href="griModalDBT.php?grievanceCreatedById=".$grievance_row['grievanceCreatedById']."&attachmentId=".$attachments_row["attachmentId"];
							$modal='data-toggle="modal" data-target="#attachmentModal"';
							}
						?>
							<tr>
												<!--<td width="80%" align="left"><?php echo $attachments_row['attachmentComments']; ?></td>
												<td width="20%" align="center"><?php if($user_row['bookReceipt']!='' && $user_row['bookReceipt']!=null)
							{
								echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
							}
							else
							{
								echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
							}?></td>-->
							<td width="80%" align="left"><?php echo $attachments_row['attachmentType']; ?></td>
												<td width="15%" align="center">
													<a href="<?php echo $href; ?>" <?php echo $modal; ?>>
													<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
													</span></h4>
													</a>
												</td>
												<!-- Attachment Modal (One modal for all attachments)-->
												<div class="modal fade bs-example-modal-lg" id="attachmentModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" >
												  <div class="modal-dialog modal-lg" role="document">
													<div class="modal-content">
													  
													</div>
												  </div>
												</div>
											</tr>	
						<?php
						}}else if($grievance_row['grievanceAttachment']!='' && $grievance_row['grievanceCreatedById']=='Not yet registered'){
							$imageFileType = pathinfo($grievance_row["grievanceAttachment"],PATHINFO_EXTENSION);
							if($imageFileType =='doc' || $imageFileType == 'docx'){
							$href='../'.$grievance_row["grievanceAttachment"];
							$modal='';
							}else{
							$href="griModalDBT.php?grievanceAttachment=".$grievance_row['grievanceAttachment']."&attachmentId=".$grievance_row["grievanceId"];
							$modal='data-toggle="modal" data-target="#attachmentModal"';
							}
						?>
						<tr>
							<td width="80%" align="left">Attachment:</td>
												<td width="15%" align="center">
													<a href="<?php echo $href; ?>" <?php echo $modal; ?>>
													<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
													</span></h4>
													</a>
												</td>
												<!-- Attachment Modal (One modal for all attachments)-->
												<div class="modal fade bs-example-modal-lg" id="attachmentModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" >
												  <div class="modal-dialog modal-lg" role="document">
													<div class="modal-content">
													  
													</div>
												  </div>
												</div>
						</tr>
						<?php 
						}else
						{
						?>	
						<tr>
							<td colspan="4" align="left"><i>No attachments found.</i></td>
						</tr>
						<?php 
						}
						?>
                       						
					</table>
					</div>	
				</div>
				<div class="panel panel-default">
					<div class="panel-body table-responsive">
					<table class="table table-bordered table-condensed f11">
						<tr>
							<td colspan="5" align="left" class="danger"><b>Comments:</b></td>
						</tr>
						<?php
						$i=1;
						if($comments_num>0)
						{
						?>
						<tr>	
							<td width="7%" align="left"><b>Sr. No.</b></td>
							<td width="48%" align="left"><b>Comments</b></td>	
							<td  width="15%" align="left"><b>Commented By</b></td>							
							<td  width="15%" align="left"><b>Commented On</b></td>							
							<td  width="15%" align="left"><b>Grievance Status</b></td>							
						</tr>
						
						<?php while($comments_row = mysqli_fetch_assoc($commentsResult))
						{
						?>
						<tr>	
							<td width="7%"  align="left"><?php echo $i.'.';$i++; ?></td>
							<td width="48%"  align="left"><?php echo $comments_row['comments']; ?></td>	
							<td width="15%"  align="left"><?php echo $comments_row['commentedBy']; ?></td>
							<td width="15%"  align="left"><?php echo date("d-m-Y", strtotime($comments_row['commentedOn'])); ?></td>
							<td width="15%"  align="left"><?php echo $comments_row['grievanceStatusChangedTo']; ?></td>
													
						</tr>
						<?php
						}//End of comments_row if
						?>
						<?php 
						}//End of comments_num if
						else
						{
						?>
						<tr>
							<td colspan="4" align="left"><i>No comments found.</i></td>
						</tr>
						<?php
						}
						?>					
					</table>
					</div>	
				</div>
				
				
					<div class="panel panel-default">
					<div class="panel-body table-responsive">
					<table class="table table-bordered table-condensed f11">
						<tr>
							<td colspan="4" align="left" class="danger"><b>Assign Grievance To:</b></td>						
						</tr>
						</table>
					</div>	
					<div class="panel-body">
						<form id="grievanceAssignForm" role="form" class="form-horizontal">
						<div class="form-group">
							<label for="grievanceComments" class="col-md-3 control-label">Comments:</label>
							<div class="col-lg-7 col-md-7">
								<textarea class="form-control" rows="2" name="grievanceComments" id="grievanceComments" placeholder="Add Comments" required="true"<?php if($comments_row['comments']!=''){ echo 'disabled';}?>></textarea>
							</div>
						</div>
						

						
						<div class="form-group required">
							<label for="grievanceAssignedTo" id="grievanceaa" class="col-md-3 control-label">Grievance assigned to:</label>
							<div class="col-lg-7 col-md-7">
								<select class="form-control" name="grievanceAssignedTo" id="grievanceAssignedTo"  aria-required="true" aria-invalid="false" >			
									<option value="">--Assign Grievance to--</option>
									<!--<option value="E-Governance"<?php if($grievance_row['grievanceAssignedTo']=='E-Governance'){ echo 'selected';}?> >E-Governance</option>-->
									<?php 
									include('../db_connect.php');
									$HoRifdsQuery = "SELECT rifdId FROM jnkcounciling.rifd WHERE type in ('Student','Institute'); ";
									$HoRifdsResult = mysqli_query($con, $HoRifdsQuery);
									if(strcmp($loginName,"EGOVERNANCE") != 0 && strcmp($loginName,"LNT") != 0 ){							
									$HoLoginsQuery = "SELECT hoId FROM jnkcounciling.dbtho WHERE hoId NOT IN('LNT','JKCELL2015-16'); ";
									$HoLoginsResult = mysqli_query($con, $HoLoginsQuery);	
									}
									else{
									$HoLoginsQuery = "SELECT hoId FROM jnkcounciling.dbtho WHERE hoId NOT IN('JKCELL2015-16'); ";
									$HoLoginsResult = mysqli_query($con, $HoLoginsQuery);									
									}
									while ($HoLogins_row = mysqli_fetch_assoc($HoLoginsResult))
									{									 
									?>
									<option value="<?php echo $HoLogins_row['hoId']; ?>" <?php if(strcmp($grievance_row['grievanceAssignedTo'], $HoLogins_row['hoId']) == 0){ echo 'selected';} ?>> <?php echo $HoLogins_row['hoId']; ?> </option>
									<?php 								
									}
									?>
									<?php
									while ($HoRifds_row = mysqli_fetch_assoc($HoRifdsResult))
									{									 
									?>
									<option value="<?php echo $HoRifds_row['rifdId']; ?>" <?php if(strcmp($grievance_row['grievanceAssignedTo'], $HoRifds_row['rifdId']) == 0){ echo 'selected';} ?>> <?php echo $HoRifds_row['rifdId']; ?> </option>
									<?php 								
									}
									?>
								</select>
							</div>
						</div>
						<?php if(strcmp($loginName,"LNT") == 0)
						{
						?>
						<script> document.getElementById("grievanceAssignedTo").style.display = 'none';
						document.getElementById("grievanceaa").style.display = 'none';
						</script>
						<?php
						}
						?>
						
						
						<div class="form-group required">
							<label for="grievanceStatus" class="col-md-3 control-label">Grievance Status:  </label>
							<div class="col-lg-7 col-md-7">
								<select class="form-control" name="grievanceStatus" id="grievanceStatus"  aria-required="true" aria-invalid="false" required="true">	
									<option value="In Progress"<?php if($grievance_row['grievanceStatus']=='In Progress'){ echo 'selected';}?> >In Progress</option>
									<option value="Closed" <?php if($grievance_row['grievanceStatus']=='Closed'){ echo 'selected';}?>> Closed </option>													
								</select>
							</div>
						</div>	</br>
						<?php if($grievance_row['grievanceStatus']=='In Progress' && strcmp($loginName,"LNT") !=0 && (substr($grievance_row['grievanceCreatedById'],0,3) != 'JKC' && substr($grievance_row['grievanceCreatedById'],0,3) != 'EGO' && $grievance_row['grievanceCreatedById'] != 'LNT' && $grievance_row['grievanceCreatedById'] != 'Not yet registered') )
						{
						?>
						
						<div class="col-lg-12 col-md-12  form-group required">
				       <input type="checkbox" name="reOpen" value="Yes" id="reOpen" > Allow the Student to reopen this Grievance</input>
			            </div>
						<?php
						}
						?>
						
						
					</div>
</div>	
<?php

if($_SESSION['hoId'] == "EGOVERNANCE")
{
	if($grievance_row['grievanceStatus']=='In Progress')
	{
	if($grievance_row['grievanceAssignedTo']=='EGOVERNANCE')
	{
	$studentYear=$grievance_row['grievanceAssignedTo'];
	}
	else if($grievance_row['grievancesCreatedBy']=='Institute')
	{
	$studentYear=$grievance_row['grievancesCreatedBy'];
	}
	else
	{
	$studentYear=$grievance_row['yearOfCounselling'];
	}	
	$href="index.php?q=section2InProgressGrievances&q1=$studentYear";
}
else
{
	$href="index.php?q=grievances&q1=closed";
}
}
else{
if($grievance_row['grievanceStatus']=='In Progress')
	{
	$href="index.php?q=grievances";
}
else
{
	$href="index.php?q=grievances&q1=closed";
}	
}
?>
 <input type="hidden" name="yearOfCounselling" value="<?php echo $grievance_row['yearOfCounselling'];?>" id="yearOfCounselling" > </input>
<a href="<?php echo $href; ?>" class="btn  btn-success col-lg-2 pull-right" style="margin-left:10px;">Back</a>
<button type="submit" class="btn  btn-success col-lg-2 pull-right" id="submitGrievance" required="true" data-toggle="modal" required="true">Submit</button>	


	<div id="myModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
	<div class="modal-content">
	  <div class="modal-header">
		<button type="button" class="close" data-dismiss="modal">&times;</button>
		<h4 class="modal-title"></h4>
	  </div>
	  <div class="modal-body">
		<p id="grievanceMessage"></p>
	  </div>
	  <div class="modal-footer">
		<a class="btn  btn-success " data-dismiss="modal" onclick="javascript:window.location.href='<?php echo $href;?>';">OK</a>
	  </div>
	</div>

	</div>
	</div>	
		
</form>			
</div>	
			
		</div>
		
	</fieldset>
				
