$(document).ready(function() {
	
	$(document).on('hidden.bs.modal', function(e) {
        var target = $(e.target);
        target.removeData('bs.modal')
            .find(".modal-content").html('');
    });
	$('#search').click(function(e) {
        e.preventDefault();
        console.log('entered');
            $.ajax({
                type: 'POST',
				beforeSend: function(){$('#institute').html("<div style='position: fixed; top: 50%; left: 60%;'><b>Loading...</b></div>");},
                url: 'search_code_aicte.php?state=' + $('#state').val() + '&courseName=' + $('#courseName').val() + '&category=' + $('#category').val() + '&typeOfInstitute=' + $('#typeOfInstitute').val() + '&isWomenInstitute=' + $('#womenInstitute').val(),
                success: function(institute) {

                    $('#institute').html(institute); 
                }


            });

       
    });
	$("#state").change(function() {
		console.log("entered 1");
        var stateSelected = $("#state option:selected").val();
        var categorySelected = $("#category option:selected").val();
        var typeOfInstituteSelected = $("#typeOfInstitute option:selected").val();
		
		
		var postParam = 'state=' + stateSelected + '&category=' + categorySelected + '&typeOfInstitute=' + typeOfInstituteSelected;
       // console.log(postParam);
        $.ajax({
            type: "GET",
            url: "../../../utils/partials/ajax/getCoursesAicte.php",
            data: postParam,
            cache: false,
            success: function(html) {
				//console.log(html+"abc");
                $("#coursesdiv").html(html);
            }
        });
    });
	
	$("#category").change(function() {
	var categorySelected = $("#category option:selected").val();

        if (categorySelected == 'General') {
			$("#typeOfInstitute").val('');
            $("#typeOfInstitute").attr('disabled', true);
        } else {
            $("#typeOfInstitute").attr('disabled', false);
        }
		
        var stateSelected = $("#state option:selected").val();
        var categorySelected = $("#category option:selected").val();
        var typeOfInstituteSelected = $("#typeOfInstitute option:selected").val();
		
		
		var postParam = 'state=' + stateSelected + '&category=' + categorySelected + '&typeOfInstitute=' + typeOfInstituteSelected;
       // console.log(postParam);
        $.ajax({
            type: "GET",
            url: "../../../utils/partials/ajax/getCoursesAicte.php",
            data: postParam,
            cache: false,
            success: function(html) {
				//console.log(html+"abc");
                $("#coursesdiv").html(html);
            }
        });
    });
	
	$("#typeOfInstitute").change(function() {
		
        var stateSelected = $("#state option:selected").val();
        var categorySelected = $("#category option:selected").val();
        var typeOfInstituteSelected = $("#typeOfInstitute option:selected").val();
		
		
		var postParam = 'state=' + stateSelected + '&category=' + categorySelected + '&typeOfInstitute=' + typeOfInstituteSelected;
       // console.log(postParam);
        $.ajax({
            type: "GET",
            url: "../../../utils/partials/ajax/getCoursesAicte.php",
            data: postParam,
            cache: false,
            success: function(html) {
				//console.log(html+"abc");
                $("#coursesdiv").html(html);
            }
        });
    });
});