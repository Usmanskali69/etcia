<?php
include('../db_connect.php');
//include("mpdf60/mpdf.php");

$attachmentId  = $_GET['attachmentId'];
$grievanceAttachment  = $_GET['grievanceAttachment'];
if($grievanceAttachment=='')
{
$query = "SELECT * FROM grievance.attachments where attachmentId='".$attachmentId."'";
}
else
{
$query = "SELECT * FROM grievance.grievances where grievanceId='".$attachmentId."'";	
}
$result = mysqli_query($con,$query);
$user_row = mysqli_fetch_array($result);
if($grievanceAttachment=='')
{
$grievance_attachment = '../jk_media/'.$user_row['attachmentPath'];
}
else
{
$grievance_attachment = '../jk_media/'.$user_row['grievanceAttachment'];	
}
	echo '<div class="modal-header">
       <h4>Grievance attachment </h4>
      </div>';
		if($grievance_attachment!=null && $grievance_attachment!='')
		{	//echo $type;
		
			$imageFileType = pathinfo($grievance_attachment,PATHINFO_EXTENSION);
		 
			if($imageFileType=='pdf' || $imageFileType=='PDF' || $imageFileType=='Pdf')
			{
				echo "<object height='500' data='".$grievance_attachment."' type='application/pdf' width=100%></object>";
				echo "<br>";
			}
			
			else
			{
				echo "<img src=	'".$grievance_attachment."' width=100%>";
				echo "<br>";
			}
		}
		else
		{
			echo "<b><font size='5' color='Red'>File not uploaded</font></b>";
		}
		
echo '</div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="attachmentModalClose"data-dismiss="modal">Close</button>
      </div>
	  ';

?>