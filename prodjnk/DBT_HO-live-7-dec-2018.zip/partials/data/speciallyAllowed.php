<?php
	session_start();
	include("../../../db_connect.php");
	
	$year = $_GET['year'];
	
	$studentQuery =	"SELECT studentUniqueId,name,fatherName,OtherStudentCollegename,instituteState,casteCategory,otherStudentStreamAppliedFor,OtherStudentCourseName FROM students where isAttachmentsSubmitted='Y' and yearOfCounselling='".$year."'";
	
	$result = mysqli_query($con, $studentQuery) or die("Could not execute query");
	
	$studentData=array();
	
	while($row = mysqli_fetch_array($result)){
		$row_array['Candidate_Id'] = $row['studentUniqueId'];
		$row_array['name'] = $row['name'];
		$row_array['fatherName'] = $row['fatherName'];
		$row_array['OtherStudentCollegename'] = $row['OtherStudentCollegename'];
		$row_array['instituteState'] = $row['instituteState'];
		$row_array['casteCategory'] = $row['casteCategory'];
		$row_array['otherStudentStreamAppliedFor'] = $row['otherStudentStreamAppliedFor'];
		$row_array['OtherStudentCourseName'] = $row['OtherStudentCourseName'];
		
		array_push($studentData,$row_array);
	}
	
	echo json_encode($studentData);
	mysqli_close($con);

?>