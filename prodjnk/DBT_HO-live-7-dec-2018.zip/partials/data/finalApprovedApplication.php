<?php

	session_start();
	if(isset($_SESSION['hoId']) && !empty($_SESSION['hoId']))
		{
	include("../../../db_connect.php");
	
	$studentQuery	=	"select 
   finalApprovalDate,DBTApplicationSubmittedDate,admissionThroughCCP,studentUniqueId,studentRank,name,fatherName,birthDate,casteCategory,primaryEmailId,tutionFees,hostelFees,bookNStationaryCharges,otherCharges,approvedTutionFees,approvedHostelFees,approvedBookNStationaryCharges,approvedOtherCharges,approvedTotal,bankName,bankBranchName,branchCode,bankifscCode,bankAccountNumber,UIDNo,DBTApplicationStatus,collegeUniqueId,streamAllottedIn
FROM
    students 
   
where
    
       DBTApplicationFormSubmitted = 'Y'
        and DBTApplicationStatus = 'Approved'
		and finalApprovedFlag='Y'
		and isScholarshipCompleted!='Y'";
	
	
	$result = mysqli_query($con, $studentQuery) or die("Could not execute query");
	$studentData=array();
	
	while($row = mysqli_fetch_array($result)){
		$row_array['Approval_Date'] = $row['finalApprovalDate'];
		$row_array['Submission_Date'] = $row['DBTApplicationSubmittedDate'];
		$row_array['AdmissionThroughCCP'] = $row['admissionThroughCCP'];
		$row_array['Candidate_Id'] = $row['studentUniqueId'];
		$row_array['Candidate_Rank'] = $row['studentRank'];
		$row_array['Candidate_Name'] = $row['name'];
		/*$approval_auditQuery	=	"	SELECT actualPaymentTill,paymentType 
										FROM approval_audit 
										WHERE studentUniqueId='".$row['studentUniqueId']."'
										AND DBTApplicationStatus='Approved'
										ORDER BY approvalAuditId DESC LIMIT 1";
	
	
		$approval_auditresult = mysqli_query($con, $approval_auditQuery) or die("Could not execute query");
		$approval_audit_row=mysqli_fetch_array($approval_auditresult);
		$row_array['Payment_Till']= $approval_audit_row['actualPaymentTill']."-".$approval_audit_row['paymentType'];*/
		$row_array['Father_Name'] = $row['fatherName'];
		$row_array['DOB'] = $row['birthDate'];
		$row_array['Caste_Category'] = $row['casteCategory'];
		$row_array['EmailId'] = $row['primaryEmailId'];
		$row_array['Tution_Applied'] = $row['tutionFees'];
		$row_array['Hostel_Applied'] = $row['hostelFees'];
		$row_array['Book_Stationary_Applied'] = $row['bookNStationaryCharges'];
		$row_array['Other_Charges_Applied'] = $row['otherCharges'];
		// $otherQuery	=	"select otherStudentCollegeName,OtherStudentCourseName,approvedTutionFees,approvedHostelFees,approvedBookNStationaryCharges,approvedOtherCharges,approvedTotal
// FROM students where studentUniqueId='".$row['studentUniqueId']."'";
	
	
	// $otherresult = mysqli_query($con, $otherQuery) or die("Could not execute query");
	// $other_row=mysqli_fetch_array($otherresult);
	
	$otherQuery="select otherStudentCollegeName,OtherStudentCourseName,approvedTutionFees,approvedHostelFees,approvedBookNStationaryCharges,approvedOtherCharges,approvedTotal
FROM students where studentUniqueId=? ";	
 		$stmt3 = mysqli_prepare($con, $otherQuery);
		mysqli_stmt_bind_param($stmt3, 'i',$row['studentUniqueId']);
		mysqli_stmt_execute($stmt3) or die("Query Failed1");
		$otherresult = mysqli_stmt_get_result($stmt3);
		$other_row = mysqli_fetch_array($otherresult, MYSQLI_ASSOC);
		
		$row_array['Tution_Approved'] = $row['approvedTutionFees'];
		$row_array['Hostel_Approved'] = $row['approvedHostelFees'];
		$row_array['Book_Stationary_Approved'] = $row['approvedBookNStationaryCharges'];
		$row_array['Other_Charges_Approved'] = $row['approvedOtherCharges'];
		$row_array['Total'] = $row['approvedTotal'];
		$row_array['Bank_Name'] = $row['bankName'];
		$row_array['Branch_Name'] = $row['bankBranchName'];
		$row_array['Branch_Code'] = $row['branchCode'];
		$row_array['Bank_IFSC_Code'] = $row['bankifscCode'];
		$row_array['Bank_AC_No'] = $row['bankAccountNumber'];
		$row_array['UID_No'] = $row['UIDNo'];
		
		$row_array['Candidate_Status'] = $row['DBTApplicationStatus'];
		if($row['admissionThroughCCP']=='Yes')
		{
		if($row['collegeUniqueId']!='' && $row['collegeUniqueId']!=null){
		if($row['streamAllottedIn']=='Engineering and Technology')
		{
		$row['streamAllottedIn']='Engineering';
		}
		$row_array['Candidate_Category'] = $row['streamAllottedIn'];
		// $collegeQuery	=	"select * FROM colleges where collegeUniqueId='".$row['collegeUniqueId']."'";
	// $collegeresult = mysqli_query($con, $collegeQuery) or die("Could not execute query");
	// $college_row=mysqli_fetch_array($collegeresult);
	
	$collegeQuery="select * FROM colleges where collegeUniqueId=? ";	
 		$stmt4 = mysqli_prepare($con, $collegeQuery);
		mysqli_stmt_bind_param($stmt4, 'i',$row['collegeUniqueId']);
		mysqli_stmt_execute($stmt4) or die("Query Failed1");
		$collegeresult = mysqli_stmt_get_result($stmt4);
		$college_row = mysqli_fetch_array($collegeresult, MYSQLI_ASSOC);
	
	// $courseQuery	=	"select * FROM courses where courseUniqueId='".$row['courseUniqueId']."'";
	// $courseresult = mysqli_query($con, $courseQuery) or die("Could not execute query");
	// $course_row=mysqli_fetch_array($courseresult);
	
	$courseQuery="select * FROM courses where courseUniqueId=? ";	
 		$stmt4 = mysqli_prepare($con, $courseQuery);
		mysqli_stmt_bind_param($stmt4, 'i',$row['courseUniqueId']);
		mysqli_stmt_execute($stmt4) or die("Query Failed1");
		$courseresult = mysqli_stmt_get_result($stmt4);
		$course_row = mysqli_fetch_array($courseresult, MYSQLI_ASSOC);
		
		$row_array['College_Name'] = $college_row['name'];
		$row_array['College_Address'] = $college_row['address'];
		$row_array['College_State'] = $college_row['state'];
		$row_array['Course_Name'] = $course_row['courseName'];
		
	}else
		{
		if($row['otherStudentStreamAppliedFor']=='Engineering and Technology')
		{
		$row['otherStudentStreamAppliedFor']='Engineering';
		}
		
		$row_array['Candidate_Category'] = $row['otherStudentStreamAppliedFor'];
		$row_array['College_Name'] = $other_row['otherStudentCollegeName'];
		$row_array['College_Address'] = $row['instituteAddress'];
		$row_array['College_State'] = $row['instituteState'];
		$row_array['Course_Name'] = $row['OtherStudentCourseName'];
		}
		}
		if($row['admissionThroughCCP']=='No')
		{
		$row_array['Candidate_Category'] = $row['otherStudentStreamAppliedFor'];
		$row_array['College_Name'] = $other_row['otherStudentCollegeName'];
		$row_array['College_Address'] = $row['instituteAddress'];
		$row_array['College_State'] = $row['instituteState'];
		$row_array['Course_Name'] = $row['OtherStudentCourseName'];
		}
		array_push($studentData,$row_array);
	}
	
	echo json_encode($studentData);
	
	}else{
		header('Location: ../../../../jnkqa/DBT_HO/login.php');
	}
?>