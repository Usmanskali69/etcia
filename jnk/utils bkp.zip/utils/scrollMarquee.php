<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="../css/bootstrap.min.css">
		  
		<style>
		ul {

			list-style-type:none;
		}
		li span {
			display:inline-block;
			width:100px;
		}
		</style>
	</head>
	<body>
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-1"></div>
				<div class="col-lg-10" style="margin-top:10px;">
					<div class="row" class="navbar navbar-default navbar-fixed-top">
						<table class="table table-striped table-bordered table-hover table-condensed">
							<tr>
								<th class="col-lg-1" rowspan="2">Sr. no</th>
								<th class="col-lg-1" rowspan="2">Institute Id</th>
								<th class="col-lg-3" rowspan="2">Institute Name</th>
								<th class="col-lg-3" rowspan="2">Course Name</th>
								<th class="col-lg-1" rowspan="2">State</th>
								<th class="col-lg-1" rowspan="2">Stream</th>
								<th class="col-lg-1" rowspan="2">Status</th>
								<!--<th class="col-lg-2" colspan="2">College Seats</th>-->
								
							</tr>
							<!--<tr>
								
								<th class="col-lg-1">Open</th>
								<th class="col-lg-1">Reserved</th>
								
							</tr>-->
						</table>
					</div>
					<div class="row" id="main">
					</div>
				</div>
				<div class="col-lg-1"></div>
			</div>
		</div>
	<script src="../js/jquery.js" type="text/javascript"></script>
	<script src="../js/bootstrap.min.js"></script>				
	<script type="text/javascript">
		$(document).ready(function(){
			$i=0;
			$j=1000;
			if($i==0)
			{
				$('#main').load('partials/ajax/marqueeCode.php'); 
				$i++;
			}
		});
	</script>
	</body>
</html>