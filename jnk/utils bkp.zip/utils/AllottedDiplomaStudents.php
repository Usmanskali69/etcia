<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="../css/bootstrap.min.css">
		  
		<style>
		ul {

			list-style-type:none;
		}
		li span {
			display:inline-block;
			width:100px;
		}
		</style>
		<h3><center>PMSSS J&K 2017-18 Allotted Candidates (Lateral Entry)</center></h3>
	</head>
	<body>
		<div class="container-fluid">
			<div class="row" style="padding:20px;">
				
				<div class="col-lg-12">
					<div class="row" class="navbar navbar-default navbar-fixed-top">
						<table class="table table-striped table-bordered table-hover table-condensed">
							<tr>
								<th width="7.20%" rowspan="2">Rank</th>
								<th width="7.5%" rowspan="2">Candidate Id</th>
								<th width="14.80%" rowspan="2">Candidate Name</th>
								<th width="14.65%" rowspan="2">Institute Name</th>
								<th width="12%" rowspan="2">Course Name</th>
								<th width="7.4%" rowspan="2">Institute State</th>
								<th width="7.75%" rowspan="2">Institute District</th>
								<!--<th class="col-lg-2" colspan="2">College Seats</th>-->
								
							</tr>
							<!--<tr>
								
								<th class="col-lg-1">Open</th>
								<th class="col-lg-1">Reserved</th>
								
							</tr>-->
						</table>
					</div>
					<div class="row" id="main">
					</div>
				</div>
			</div>
		</div>
	<script src="../js/jquery.js" type="text/javascript"></script>
	<script src="../js/bootstrap.min.js"></script>				
	<script type="text/javascript">
		$(document).ready(function(){
			$i=0;
			$j=1000;
			if($i==0)
			{
				$('#main').load('partials/ajax/GetDiplomaAllottedStudents.php'); 
				$i++;
			}
		});
	</script>
	</body>
</html>