<?php
session_start();
	 include( '../../../rifd/Classes/PHPExcel.php');
	include( '../../../Classes/PHPExcel/IOFactory.php');
	$con = mysql_connect("192.168.1.101","root","admin123");
    $db = mysql_select_db("jnkcounciling",$con);
	
	$objReader = PHPExcel_IOFactory::createReader('Excel2007');
    $objPHPExcel = new PHPExcel();
	$objPHPExcel->getActiveSheet()->setTitle('Sheet1');
	$hoId=$_SESSION['hoId'];
	$hoId=substr($hoId, -7);
	
	$sql = "SELECT 
    a.yearOfCounselling,
    b.isXIIMarksheetVerified AS AppliedSem,
    a.disclaimer as CPSMS_Beneficiary_Code,
    a.studentUniqueId as Scheme_Specific_Id,
    a.name as Beneficiary_Name,
    CASE
        WHEN
            (a.attendance = ''
                OR a.attendance IS NULL)
        THEN
            a.name
        ELSE a.attendance
    END AS Beneficiary_Name_as_per_Bank,
    a.fatherName as Father_or_Husband_Name,
    a.bankName as Bank_Name,
    a.UIDNo as Aadhaar_Number,
    a.bankAccountNumber as Account_Number,
    a.bankifscCode as IFSC_Code,
    CASE
        WHEN (a.permanentDistrict = 'LEH') THEN 'LEH (LADAKH)'
        ELSE a.permanentDistrict
    END AS District,
	'' AS purpose,
    b.approvedTotal as Total_Amount,
    b.approvalAuditId AS Payment_Id,
    a.casteCategory as STUDENT_CASTE
FROM
    students a,
    approval_audit b
WHERE
    a.studentUniqueId = b.studentUniqueId
        AND b.DBTApplicationStatus IN ('Approved')
        AND (disclaimer != ''
        OR disclaimer IS NOT NULL)
		
		AND DBTApplicationFormSubmitted = 'Y'
        and approvalFlag = 'Y' and finalApprovedFlag='Y' and yearOfCounselling='".$hoId."' 
        ORDER BY a.studentUniqueId, b.finalApprovalDate DESC";
	$rec = mysql_query($sql) or die (mysql_error());
	$num_fields = mysql_num_fields($rec);
	
	$chars	= array("B1", "C1", "D1","E1","F1","G1","H1","I1","J1","L1","N1","Q1","S1","T1");
	$objPHPExcel->getActiveSheet()->setCellValue('A1', "SR.");
	$objPHPExcel->getActiveSheet()->setCellValue('B1', "CPSMS Beneficiary Code");
	$objPHPExcel->getActiveSheet()->setCellValue('C1', "Scheme Specific Id");
	$objPHPExcel->getActiveSheet()->setCellValue('D1', "Beneficiary Name");
	$objPHPExcel->getActiveSheet()->setCellValue('E1', "Beneficiary Name as per Bank");
	$objPHPExcel->getActiveSheet()->setCellValue('F1', "Father/Husband Name");
	$objPHPExcel->getActiveSheet()->setCellValue('G1', "Bank Name");
	$objPHPExcel->getActiveSheet()->setCellValue('H1', "Aadhaar Number");
	$objPHPExcel->getActiveSheet()->setCellValue('I1', "Account Number");
	$objPHPExcel->getActiveSheet()->setCellValue('J1', "IFSC Code");
	$objPHPExcel->getActiveSheet()->setCellValue('K1', "State");	
	$objPHPExcel->getActiveSheet()->setCellValue('L1', "District");
	$objPHPExcel->getActiveSheet()->setCellValue('M1', "Purpose");	
	$objPHPExcel->getActiveSheet()->setCellValue('N1', "Centre Share Payment Amount");
	$objPHPExcel->getActiveSheet()->setCellValue('O1', "State Share Payment Amount");	
	//$objPHPExcel->getActiveSheet()->setCellValue('N1', "Centre_Share_Payment_Amount");
	$objPHPExcel->getActiveSheet()->setCellValue('P1', "Total Amount");
	$objPHPExcel->getActiveSheet()->setCellValue('Q1', "PID");
	$objPHPExcel->getActiveSheet()->setCellValue('R1', "ATT_YEAR");	
	//$objPHPExcel->getActiveSheet()->setCellValue('S1', "ATT_MONTH");
	$objPHPExcel->getActiveSheet()->setCellValue('S1', "STUDENT CASTE");
	$objPHPExcel->getActiveSheet()->setCellValue('T1', "PAYMENT FROM DATE ");
	//$objPHPExcel->getActiveSheet()->setCellValue('S1', "ATT_YEAR");
	$objPHPExcel->getActiveSheet()->setCellValue('U1', "PAYMENT TO DATE ");
	//$objPHPExcel->getActiveSheet()->setCellValue('V1', " ");
	$oldStudentUniqueId="";
	$rowNum=2;
	$c = 1;
	while($row = mysql_fetch_assoc($rec))
    {
		$y = $row['DBTApplicationYear'];
		$year = substr($y,2,2);
		
		/*if($row['AppliedSem']%2 == 0)
		{
			$purpose = "2nd Instalment(Maint. Grant)";
			$year = $year + 1;
			$paymentFrom = "01-Jan-".$year;   
			$paymentTo = "30-Jun-".$year;   
		}
		else
		{
			$purpose = "1st Instalment(Maint. Grant)";
			$paymentFrom = "01-Jul-".$year;
			$paymentTo = "31-Dec-".$year;
		}*/
		
		if($oldStudentUniqueId != $row['Scheme_Specific_Id']){
			$objPHPExcel->getActiveSheet()->setCellValue('A'.$rowNum, $c);
			$objPHPExcel->getActiveSheet()->setCellValue('B'.$rowNum, $row['CPSMS_Beneficiary_Code']);
			//$objPHPExcel->getActiveSheet()->setCellValue('C'.$rowNum, $row['studentUniqueId']);
			$objPHPExcel->getActiveSheet()->setCellValueExplicit('C'.$rowNum, $row['Scheme_Specific_Id'], PHPExcel_Cell_DataType::TYPE_STRING);
			$objPHPExcel->getActiveSheet()->setCellValue('D'.$rowNum, $row['Beneficiary_Name']);
			$objPHPExcel->getActiveSheet()->setCellValue('E'.$rowNum, $row['Beneficiary_Name_as_per_Bank']);
			$objPHPExcel->getActiveSheet()->setCellValue('F'.$rowNum, $row['Father_or_Husband_Name']);
			$objPHPExcel->getActiveSheet()->setCellValue('G'.$rowNum, $row['Bank_Name']);
			//$objPHPExcel->getActiveSheet()->setCellValue('H'.$rowNum, $row['UIDNo']);
			$objPHPExcel->getActiveSheet()->setCellValueExplicit('H'.$rowNum, $row['Aadhaar_Number'], PHPExcel_Cell_DataType::TYPE_STRING);
			//$objPHPExcel->getActiveSheet()->setCellValue('I'.$rowNum, $row['bankAccountNumber']);
			$objPHPExcel->getActiveSheet()->setCellValueExplicit('I'.$rowNum, $row['Account_Number'], PHPExcel_Cell_DataType::TYPE_STRING);
			$objPHPExcel->getActiveSheet()->setCellValue('J'.$rowNum, $row['IFSC_Code']);
			$objPHPExcel->getActiveSheet()->setCellValue('K'.$rowNum, "Jammu And Kashmir");
			$objPHPExcel->getActiveSheet()->setCellValue('L'.$rowNum, $row['District']);
			$objPHPExcel->getActiveSheet()->setCellValue('M'.$rowNum, $purpose);
			$objPHPExcel->getActiveSheet()->setCellValue('N'.$rowNum, $row['studentAmt']);
			$objPHPExcel->getActiveSheet()->setCellValue('O'.$rowNum, $row['purpose']);
			$objPHPExcel->getActiveSheet()->setCellValue('P'.$rowNum, $row['Total_Amount']);
			$objPHPExcel->getActiveSheet()->setCellValue('Q'.$rowNum, $row['Payment_Id']);
			//$objPHPExcel->getActiveSheet()->setCellValue('R'.$rowNum, "");
			$objPHPExcel->getActiveSheet()->setCellValue('R'.$rowNum, $row['DBTApplicationYear']);
			$objPHPExcel->getActiveSheet()->setCellValue('S'.$rowNum, $row['STUDENT_CASTE']);
			$objPHPExcel->getActiveSheet()->setCellValue('T'.$rowNum, $paymentFrom);
			$objPHPExcel->getActiveSheet()->setCellValue('U'.$rowNum, $paymentTo);
			$rowNum++;
		}
		//fetch previous Scheme_Specific_ID
		$oldStudentUniqueId=$row['Scheme_Specific_Id'];
		
		$c++; 
    }
	header('Content-Type: application/vnd.ms-excel');
	$name="JKS-".date("dmY")."-".$batchNumber;
	header('Content-Disposition: attachment;filename="'.$name.'.xlsx"');
	header('Cache-Control: max-age=0');
	header('Cache-Control: max-age=1');
	header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
	header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
	header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
	header ('Pragma: public'); // HTTP/1.0

	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	$objWriter->save('php://output');	
	exit;
	
?>