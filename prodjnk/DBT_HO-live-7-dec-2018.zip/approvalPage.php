<?php
	require_once(realpath("./session/session_verify.php"));
?>

<!DOCTYPE html>
<html lang="en">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="SUVOJIT AOWN">

		<title>J&K Scholarships HO</title>

		<!-- Bootstrap Core CSS -->
		<link href="../css/bootstrap.min.css" rel="stylesheet">

		<!-- Bootstrap Table CSS -->
		<link href="../css/bootstrap-table.min.css" rel="stylesheet" >
		
		<!-- Custom Fonts -->
		<link href="../font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		
		<link href="../css/style.css" rel="stylesheet" type="text/css">
		
		
	</head>

	<body>
		<div id="header" class="navbar navbar-default navbar-fixed-top">
			<div class="navbar-header">
				<button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target=".navbar-collapse">
					<i class="fa fa-bars"></i>
				</button>
				<a class="navbar-brand" href="index.php">
					<i class="fa fa-graduation-cap fa-lg"></i> J&K Scholarships
				</a>
			</div>
			<nav class="collapse navbar-collapse">
				
				<ul class="nav navbar-nav pull-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
									<i class="fa fa-user fa-lg"></i> <?php echo $_SESSION['hoId']; ?><b class="caret"></b></a>
						<ul class="dropdown-menu pull-right">
									<li><a href="Profile.php"><i class="fa fa-user fa-fw"></i> Profile</a></li>
									<li class="divider"></li>
									<li><a href="session/auth.php?do=logout"><i class="fa fa-power-off"></i> Logout</a></li>
						</ul>
					</li>
				</ul>

			</nav>
		</div>
		<?php
				include("db_connect.php");
	
				// fetching Student ID from session
				$studentUniqueId= htmlspecialchars($_GET['candidateID']);
								
				//$query='SELECT * FROM students WHERE studentUniqueId="'.$studentUniqueId.'"';
				//$result = mysqli_query($con,$query);				
				
				$query='SELECT * FROM students WHERE studentUniqueId=?';
				$stmt1 = mysqli_prepare($con, $query);
				mysqli_stmt_bind_param($stmt1, 'i', $studentUniqueId);
				mysqli_stmt_execute($stmt1);
				$result = mysqli_stmt_get_result($stmt1);
	
				$user_row = mysqli_fetch_array($result, MYSQLI_ASSOC);
				
				//$query1="SELECT otherStudentCollegename,otherStudentCourseName,otherStudentUniversity,otherStudenttypeOfInstitute,streamAppliedFor FROM students WHERE studentUniqueId='".$studentUniqueId."'";
				//echo $query;
				//$result1 = mysqli_query($con,$query1);
				
				$query1="SELECT otherStudentCollegename,otherStudentCourseName,otherStudentUniversity,otherStudenttypeOfInstitute,streamAppliedFor FROM students WHERE studentUniqueId=?";
				$stmt2 = mysqli_prepare($con, $query1);
				mysqli_stmt_bind_param($stmt2, 'i', $studentUniqueId);
				mysqli_stmt_execute($stmt2);
				$result1 = mysqli_stmt_get_result($stmt2);
				
				$user_row1 = mysqli_fetch_array($result1, MYSQLI_ASSOC);

				//$collegequery='SELECT * FROM colleges WHERE collegeUniqueId='.$user_row['collegeUniqueId'];	
				//echo $collegequery;
				//$collegeresult = $result = mysqli_query($con,$collegequery);
				
				$collegequery='SELECT * FROM colleges WHERE collegeUniqueId=?';
				$stmt3 = mysqli_prepare($con, $collegequery);
				mysqli_stmt_bind_param($stmt3, 'i', $user_row['collegeUniqueId']);
				mysqli_stmt_execute($stmt3);
				$collegeresult = mysqli_stmt_get_result($stmt3);
				
				$college_row = mysqli_fetch_array($collegeresult, MYSQLI_ASSOC);	

				//$coursesquery='SELECT * FROM courses WHERE courseUniqueId='.$user_row['courseUniqueId'];	
				//$coursesresult = mysqli_query($con,$coursesquery);
				
				$coursesquery='SELECT * FROM courses WHERE courseUniqueId=?';
				$stmt4 = mysqli_prepare($con, $coursesquery);
				mysqli_stmt_bind_param($stmt4, 'i', $user_row['courseUniqueId']);
				mysqli_stmt_execute($stmt4);
				$coursesresult = mysqli_stmt_get_result($stmt4);
				$course_row = mysqli_fetch_array($coursesresult, MYSQLI_ASSOC);				
				
		?>
			
		<nav>
			<div id="wrapper">
					
					<div id="main-wrapper" class="col-lg-12">
						<div id="main">
							<?php 
							if($user_row['DBTApplicationStatus']=='Submitted' && $_GET['edit']=='NotApproved')
								{
									//print_r('bye');die;
								include('partials/approvalDetails.php');
								}
								if($user_row['DBTApplicationStatus']=='Rejected' && $_GET['edit']=='NotApproved')
								{
									//print_r('hii');die;
								include('partials/approvalDetails.php');
								}
								if($user_row['DBTApplicationStatus']=='Submitted' && $_GET['edit']=='Approved')
								{
									//print_r('hii');die;
								include('partials/finalApprovalDetails.php');
								}
								if($user_row['DBTApplicationStatus']=='Approved' && $_GET['edit']=='FinalApproved')
								{
								include('partials/approvalDetails.php');
								}
								if($_GET['edit']=='FinalApprovedAllYear')
								{
								include('partials/finalApprovedDetailsNonEditable.php');
								}
							?>
						</div>
						
			</div>
		</nav>
		
		<script type="text/javascript" src="../js/jquery.js"></script>
		<script type="text/javascript" src="../js/jquery.validate.min.js"></script>
		<script type="text/javascript" src="../js/bootstrap.min.js"></script>
		<script type="text/javascript" src="../js/bootstrap-table.js"></script>
		<script type="text/javascript" src="js/validation.js"></script>
		<script type="text/javascript" src="js/custom.js"></script>
		
		<?php mysqli_close ($con); ?>
		
	</body>
</html>