<?php

	session_start();
		if(isset($_SESSION['hoId']) && !empty($_SESSION['hoId']))
{
	include("../../../db_connect.php");
	
	$studentQuery	=	"SELECT DBTApplicationSubmittedDate,studentUniqueId,studentRank,name,DBTApplicationStatus,otherStudentStreamAppliedFor FROM students where DBTApplicationFormSubmitted='Y' and DBTApplicationStatus='Submitted' and admissionThroughCCP='No' and approvalFlag='N'";
	
	
	$result = mysqli_query($con, $studentQuery) or die("Could not execute query");
	$studentData=array();
	
	while($row = mysqli_fetch_array($result)){
		$row_array['Submission_Date'] = $row['DBTApplicationSubmittedDate'];
		$row_array['Candidate_Id'] = $row['studentUniqueId'];
		$row_array['Candidate_Rank'] = $row['studentRank'];
		$row_array['Candidate_Name'] = $row['name'];
		$row_array['Candidate_Status'] = $row['DBTApplicationStatus'];
		$row_array['Candidate_Category'] = $row['otherStudentStreamAppliedFor'];
	
	// $otherQuery	=	"select otherStudentCollegeName, OtherStudentCourseName,approvedTutionFees, approvedHostelFees,approvedBookNStationaryCharges, approvedOtherCharges,approvedTotal FROM students where  studentUniqueId='".$row['studentUniqueId']."'";
	
	
		// $otherresult = mysqli_query($con, $otherQuery) or die("Could not execute query");
		// $other_row=mysqli_fetch_array($otherresult);
		
		$otherQuery="select otherStudentCollegeName, OtherStudentCourseName,approvedTutionFees, approvedHostelFees,approvedBookNStationaryCharges, approvedOtherCharges,approvedTotal FROM students where  studentUniqueId=? ";
		$stmt1 = mysqli_prepare($con, $otherQuery);
		mysqli_stmt_bind_param($stmt1, 'i',$row['studentUniqueId']);
		mysqli_stmt_execute($stmt1) or die("Query Failed1");
		$otherresult = mysqli_stmt_get_result($stmt1);
		$other_row = mysqli_fetch_array($otherresult, MYSQLI_ASSOC);
		
		
		$row_array['College_Name'] = $other_row['otherStudentCollegeName'];
		array_push($studentData,$row_array);
	}
	
	echo json_encode($studentData);
	}else{
		header('Location: ../../../../jnkqa/DBT_HO/login.php');
	}
?>