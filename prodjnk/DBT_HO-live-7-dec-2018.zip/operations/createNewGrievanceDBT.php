<?php
	include('../../db_connect.php');
	
	$grievanceId = mysqli_real_escape_string($con,$_POST['grievanceId']);
	$grievanceCreatedById = mysqli_real_escape_string($con,$_POST['grievanceCreatedById']);
	
	$grievanceSubject = mysqli_real_escape_string($con,$_POST['grievanceSubject']);
	//$grievanceNature= mysqli_real_escape_string($con,$_POST['grievanceNature']);
	$grievanceDescription= mysqli_real_escape_string($con,$_POST['grievanceDescription']);
	$grievanceAssignedTo= mysqli_real_escape_string($con,$_POST['grievanceAssignedTo']);
	
	$grievanceQuery=" SELECT grievanceId from grievance.grievances where grievanceId = '".$grievanceId."'";
	$grievanceResult=mysqli_query($con,$grievanceQuery);
	
	
	if(mysqli_num_rows($grievanceResult)==1){
	
		$grievanceUpdateQuery=" UPDATE grievance.grievances SET grievanceSubject = '".$grievanceSubject."' , grievanceDescription = '".$grievanceDescription."' , grievanceAssignedTo = '".$grievanceAssignedTo."' WHERE grievanceId = '".$grievanceId."'";
		//echo $grievanceUpdateQuery;	
		$result=mysqli_query($con,$grievanceUpdateQuery);
		
		if($result){
			echo 'Success';
		}else{
			echo 'Failed';
		}
	
	}else{
		$grievanceInsertQuery=" INSERT INTO grievance.grievances ( grievanceId, grievanceCreatedById, grievanceSubject, grievanceDescription, grievanceAssignedTo, grievanceStatus,grievancesCreatedBy) VALUES('".$grievanceId."','".$grievanceCreatedById."','".$grievanceSubject."','".$grievanceDescription."','".$grievanceAssignedTo."','In Progress','Ho')";
	{	
		
		//echo $grievanceInsertQuery;
		$result=mysqli_query($con,$grievanceInsertQuery);
		
		if($result){
			echo 'Success';
		}else{
			echo 'Failed';
			//echo mysqli_error($con);
		}
	}
}
	/*else{
	$grievanceQuery = " DELETE FROM grievance.grievances WHERE grievanceId = '".$grievanceId."'";
		//echo $grievanceQuery;
		$result=mysqli_query($con,$grievanceQuery);
		
		if($result){
			echo 'Success';
		}else{
			echo 'Failed';
			echo mysqli_error($con);
		}
	}*/
	mysqli_close($con);
?>