<?php
include('../db_connect.php');

$attachmentId  = htmlspecialchars($_GET['attachmentId']);
//$attachmentQuery = "SELECT attachmentPath from grievance.attachments where attachmentId='".$attachmentId."'";
//$attachmentResult = mysqli_query($con,$attachmentQuery);

$attachmentQuery = "SELECT attachmentPath from grievance.attachments where attachmentId=?";
$stmt1 =mysqli_prepare($con, $attachmentQuery);
				mysqli_stmt_bind_param($stmt1, 'i', $attachmentId);
				mysqli_stmt_execute($stmt1);
				$result = mysqli_stmt_get_result($stmt1);
				
if($row=mysqli_fetch_array($attachmentResult, MYSQLI_ASSOC))
{
	$attachmentPath = '../'.$row['attachmentPath'];
}

$query = "DELETE FROM grievance.attachments where attachmentId='".$attachmentId."'";

//Delete attachment from database and the actual file
if( mysqli_query($con,$query) && unlink($attachmentPath))
{
echo ' 
		<div class="modal-body" >
       <h4>Attachment deleted successfully </h4>
      </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="attachmentModalClose" data-dismiss="modal">Close</button>
      </div>
	  ';
}
mysqli_close($con);
?>