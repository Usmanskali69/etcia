<?php
session_start();
include('../../db_connect.php');

$comments =htmlspecialchars($_GET["comments"]);
$declaration =htmlspecialchars($_GET["declaration"]);
$candidateId =htmlspecialchars($_GET["candidateId"]);
$now = new DateTime();
$now = $now->format('Y-m-d H:i:s');

/*$studentQuery="SELECT DBTApplicationStatus, isScholarshipCompleted,approvalFlag from students where studentUniqueId='".$candidateId."'";
//echo $studentQuery;
$studentResult = mysqli_query($con, $studentQuery)or die("Query Failed");
*/

$studentQuery="SELECT DBTApplicationStatus, isScholarshipCompleted,approvalFlag from students where studentUniqueId=?";
$stmt1 =mysqli_prepare($con, $studentQuery);
mysqli_stmt_bind_param($stmt1, 'i', $candidateId);
mysqli_stmt_execute($stmt1);
$studentResult = mysqli_stmt_get_result($stmt1);


$student_row = mysqli_fetch_array($studentResult, MYSQLI_ASSOC);
// if($student_row['approvalFlag']!='Y')
// {
	if($student_row['isScholarshipCompleted']!='Y')
	{
		if($student_row['DBTApplicationStatus']=='Approved' || $student_row['DBTApplicationStatus']=='Submitted' )
		{		
			/*$query="UPDATE students 
					SET isScholarshipCompleted='".$declaration."',
					completedScholarshipComments='".$comments."',
					scholarshipCompletionDate='".$now."'
					WHERE
					studentUniqueId='".$candidateId."'";
					
					$result = mysqli_query($con, $query) or die("Query Failed");*/
					
					
					$query="UPDATE students 
					SET isScholarshipCompleted=?,
					completedScholarshipComments=?,
					scholarshipCompletionDate=?
					WHERE
					studentUniqueId=?";
					$stmt1 =mysqli_prepare($con, $query);
					mysqli_stmt_bind_param($stmt1, 'sssi', $declaration,$comments,$now,$candidateId);
					$result = mysqli_stmt_execute($stmt1);					
					
			//echo $query;
			if($result)
			{
			echo "success";
			}
			else
			{
			echo "failure";
			}
		}  		
		else
		{
		 echo $student_row['DBTApplicationStatus'];
		}
	}else{
		echo 'completed';
	}
/*}else{
	echo 'Cannot Mark Student for Scholarship Completion. As student is already approved.';
}*/
?>