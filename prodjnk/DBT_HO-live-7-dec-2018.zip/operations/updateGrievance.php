<?php 
	session_start();
	include('config.php');
	
	$grievanceId	=	htmlspecialchars(mysqli_real_escape_string($con,$_POST['grievanceId']));	
	$grievanceAssignedTo	=	htmlspecialchars(mysqli_real_escape_string($con,$_POST['grievanceAssignedTo']));	
	$grievanceComments	=	htmlspecialchars(mysqli_real_escape_string($con,$_POST['grievanceComments']));	
	$grievanceStatus	=	htmlspecialchars(mysqli_real_escape_string($con,$_POST['grievanceStatus']));	
	$grievanceEditFlag	=	htmlspecialchars(mysqli_real_escape_string($con,$_POST['reOpen']));
	
	//echo $grievanceComments;
	$hoId=$_SESSION['hoId'];
	if($hoId=='LNT')
	{
	$hoId="TECH SUPPORT";
	}
	
	if($grievanceId !='')
	{
		if($grievanceAssignedTo !='' || $grievanceAssignedTo !=null)
		{
			// $query = "UPDATE grievances SET grievanceAssignedTo = '".$grievanceAssignedTo."', grievanceStatus= '".$grievanceStatus."', grievanceEditFlag= '".$grievanceEditFlag."' WHERE grievanceId = '".$grievanceId."' ";

	$query="UPDATE grievances SET grievanceAssignedTo = ?, grievanceStatus= ?, grievanceEditFlag= ? WHERE grievanceId = ? ";
	$stmt = mysqli_prepare($con, $query);
	mysqli_stmt_bind_param($stmt, 'ssss', $grievanceAssignedTo,$grievanceStatus,$grievanceEditFlag,$grievanceId);
	$result =mysqli_stmt_execute($stmt);			
		}
		else{
			// $query = "UPDATE grievances SET grievanceStatus= '".$grievanceStatus."', grievanceEditFlag= '".$grievanceEditFlag."' WHERE grievanceId = '".$grievanceId."' ";
			
			$query="UPDATE grievances SET grievanceStatus= ?, grievanceEditFlag= ? WHERE grievanceId = ? ";
		$stmt = mysqli_prepare($con, $query);
		mysqli_stmt_bind_param($stmt, 'sss',$grievanceStatus,$grievanceEditFlag,$grievanceId);
		$result =mysqli_stmt_execute($stmt);
		}
		// $result = mysqli_query($con,$query);
		
		// $commentsQuery = "INSERT INTO comments (comments,grievanceId,commentedBy,grievanceStatusChangedTo) VALUES ('".$grievanceComments."','".$grievanceId."','".$hoId."','".$grievanceStatus."')";			
		// $commentsResult = mysqli_query($con,$commentsQuery);
		
		$commentsQuery="INSERT INTO comments (comments,grievanceId,commentedBy,grievanceStatusChangedTo) VALUES (?,?,?,?)";
	
	$stmt = mysqli_prepare($con, $commentsQuery);
	mysqli_stmt_bind_param($stmt, 'ssss', $grievanceComments,$grievanceId,$hoId,$grievanceStatus);
	$commentsResult=mysqli_stmt_execute($stmt);

		if($grievanceStatus=='Closed')
		{
		include('../../mailer.php');
		include('../../sms/sms.php');
		// $mailQuery="SELECT a.grievanceId,a.grievanceName,a.grievanceMobileNumber,a.grievanceEmailId,a.grievanceAssignedTo,b.comments FROM grievance.grievances a, grievance.comments b WHERE a.grievanceId=b.grievanceId and a.grievanceId='".$grievanceId."' order by b.commentId desc limit 1";
		// $mailResult = mysqli_query($con,$mailQuery);
		// $mail_row = mysqli_fetch_array($mailResult);
		
		$mailQuery="SELECT a.grievanceId,a.grievanceName,a.grievanceMobileNumber,a.grievanceEmailId,a.grievanceAssignedTo,b.comments FROM grievance.grievances a, grievance.comments b WHERE a.grievanceId=b.grievanceId and a.grievanceId=? order by b.commentId desc limit 1";
	$stmt = mysqli_prepare($con, $mailQuery);
	mysqli_stmt_bind_param($stmt, 's', $grievanceId);
	mysqli_stmt_execute($stmt);
	$mailResult = mysqli_stmt_get_result($stmt);
	$mail_row = mysqli_fetch_array($mailResult, MYSQLI_ASSOC);
		
		$recipients = $mail_row['grievanceEmailId'];
		$subject = "J&K Grievance Closed";
		$body ="Dear Applicant,<br/><br/>
		The grievance with grievance ID - $grievanceId has been addressed and answered.<br/> <br/>
		<table border='1' cellspacing='5' cellpadding='5'>
				
				<thead>
				<th><b>Grievance ID</b></th>
				<th><b>Applicant Name</b></th>
				<th><b>Grievance assigned to (A/Y)</b></th>
				<th><b>Comments</b></th>
				</thead>
				<tr>
				<td>".$grievanceId."</td>
				<td>".$mail_row['grievanceName']."</td>
				<td>".$mail_row['grievanceAssignedTo']."</td>
				<td>".$mail_row['comments']."</td>
				</tr>				
				</table></br></br>
				
		For further detailed information, kindly refer below link or please visit PMSSS Grievance Web Portal by logging in using credentials.<br/>
        http://www.aicte-jk-scholarship-gov.in/Grievance/grievanceIndex.php</br></br>

		With regards,<br/>
		PMSSS Cell
		<hr/>
		This is an auto-generated email message, please do not reply directly as we will not be able to answer. ";
		$altBody= "";
		if($mail_row['grievanceMobileNumber']!='')
		{
        $mclass = new sendSms();		
		$content="Dear Applicant,
		The grievance with Grievance ID - $grievanceId has been addressed. Kindly refer below link or please visit PMSSS Grievance Web Portal by logging in using credentials. https://www.aicte-jk-scholarship-gov.in/Grievance/grievanceIndex.php .";
		$signature=" Regards, AICTE";
		$mclass->sendSmsToUser($content,"91".$mail_row['grievanceMobileNumber'],$signature,$grievanceId,'Grievance Closed','J&K Team',$con);
		$s= sendMail($recipients, $subject, $body, $altBody,6);
		}
		else
		{
			$s='1';
		}
		}
		
		if($result && $commentsResult  && $s && $mclass )
		{		
			echo "Success";
		}
					
	}
	mysqli_close($con);
	
?>