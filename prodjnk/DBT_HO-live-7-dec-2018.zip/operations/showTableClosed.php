<?php
	include('config.php');
	$grievanceStatus=$_GET['id'];
	$query="Select * from grievance.grievances where grievanceStatus='Closed' ORDER BY grievanceId DESC";
	$result=mysqli_query($con,$query);
	$rows = array();
	$grievanceData = array();
	while($data = mysqli_fetch_assoc($result)) {
	
		$rows['grievanceId']=$data['grievanceId'];
		$rows['grievanceNature']=$data['grievanceNature'];
		$rows['grievanceSubject']=$data['grievanceSubject'];
		$rows['grievanceCreatedById']=$data['grievanceCreatedById'];
		$rows['grievanceCreatedOn']=$data['grievanceCreatedOn'];
		$rows['grievanceDescription']=$data['grievanceDescription'];		
		$rows['grievanceStatus']=$data['grievanceStatus'];
		$rows['grievanceAssignedTo']=$data['grievanceAssignedTo'];
		
		$commentQuery="SELECT comments,commentedOn from grievance.comments where grievanceId = '".$data['grievanceId']."' ORDER BY commentedOn DESC LIMIT 1 ";
		$commentResult=mysqli_query($con,$commentQuery);
		$count= mysqli_num_rows($commentResult);
		if($count==1){
		$commentsData=mysqli_fetch_assoc($commentResult);
			$rows['grievanceComments']=$commentsData['comments'];
			$rows['grievanceCommentedOn']=date("d-m-Y", strtotime($commentsData['commentedOn']));
		}
		else{
			$rows['grievanceComments']='';
			$rows['grievanceCommentedOn']='';
		}
		array_push($grievanceData,$rows);
	}
	echo json_encode($grievanceData);
	mysqli_close($con);
?>