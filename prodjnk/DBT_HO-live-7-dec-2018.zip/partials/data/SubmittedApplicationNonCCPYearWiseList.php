<?php

	session_start();
	
	include("../../../db_connect.php");
	$hoId=$_SESSION['hoId'];
	$hoId=substr($hoId, -7);
//	$studentQuery	=	"SELECT DBTApplicationSubmittedDate,studentUniqueId,disclaimer,studentRank,name,DBTApplicationStatus,otherStudentStreamAppliedFor,instituteState FROM students where DBTApplicationFormSubmitted='Y' and DBTApplicationStatus='Submitted' and admissionThroughCCP='No' and approvalFlag='N' and isScholarshipCompleted is null and yearOfCounselling='".$hoId."'";
	//$result = mysqli_query($con, $studentQuery) or die("Could not execute query");

	$studentQuery	=	"SELECT DBTApplicationSubmittedDate,studentUniqueId,disclaimer,studentRank,name,DBTApplicationStatus,otherStudentStreamAppliedFor,instituteState FROM students where DBTApplicationFormSubmitted='Y' and DBTApplicationStatus='Submitted' and admissionThroughCCP='No' and approvalFlag='N' and isScholarshipCompleted is null and yearOfCounselling=?";
	$stmt = mysqli_prepare($con, $studentQuery);
	mysqli_stmt_bind_param($stmt, 's', $hoId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);

	$studentData=array();
	
	while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
		$row_array['Submission_Date'] = $row['DBTApplicationSubmittedDate'];
		$row_array['Candidate_Id'] = $row['studentUniqueId'];
		$row_array['Beneficiary_Code'] = $row['disclaimer'];
		$row_array['Candidate_Rank'] = $row['studentRank'];
		$row_array['Candidate_Name'] = $row['name'];
		$row_array['Candidate_Status'] = $row['DBTApplicationStatus'];
		$row_array['Candidate_Category'] = $row['otherStudentStreamAppliedFor'];
		$row_array['College_State'] = $row['instituteState'];
//		$otherQuery	=	"select 
 // otherStudentCollegeName,OtherStudentCourseName,approvedTutionFees,approvedHostelFees,approvedBookNStationaryCharges,approvedOtherCharges,approvedTotal
//FROM
  //  students 
   
//where
    
  //     studentUniqueId='".$row['studentUniqueId']."'";
	
	
//	$otherresult = mysqli_query($con, $otherQuery) or die("Could not execute query");
//	$other_row=mysqli_fetch_array($otherresult);

	$otherQuery	=	"select 
  otherStudentCollegeName,OtherStudentCourseName,approvedTutionFees,approvedHostelFees,approvedBookNStationaryCharges,approvedOtherCharges,approvedTotal FROM students where studentUniqueId=?";
	$stmt = mysqli_prepare($con, $otherQuery);
	mysqli_stmt_bind_param($stmt, 'i', $row['studentUniqueId']);
	mysqli_stmt_execute($stmt);
	$otherresult = mysqli_stmt_get_result($stmt);
    $other_row=mysqli_fetch_array($otherresult, MYSQLI_ASSOC);

		$row_array['College_Name'] = $other_row['otherStudentCollegeName'];
		
		$extraQuery="select actualPaymentTill,paymentType from approval_audit where studentUniqueId='".$row['studentUniqueId']."' and DBTApplicationStatus='Approved' order by actualPaymentTill desc limit 1 ;";
		$extraResult=mysqli_query($con,$extraQuery);
		$extraRow=mysqli_fetch_array($extraResult);
		$row_array['paymentTill'] = $extraRow['actualPaymentTill'].'-'.$extraRow['paymentType'];
		array_push($studentData,$row_array);
	}
	
	echo json_encode($studentData);
?>