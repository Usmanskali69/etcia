<?php
	session_start();
	
	include("../../../db_connect.php");
	$hoId=$_SESSION['hoId'];
	$hoId=substr($hoId, -7);
	/*
	$studentQuery	=	"SELECT finalApprovalDate,DBTApplicationSubmittedDate,admissionThroughCCP,studentUniqueId,disclaimer,studentRank,name,fatherName,birthDate,casteCategory,primaryEmailId,DBTApplicationStatus,collegeUniqueId,courseUniqueId,streamAllottedIn,otherStudentCollegeName,otherStudentStreamAppliedFor,OtherStudentCourseName,instituteAddress,instituteState,examType from students where yearOfCounselling='".$hoId."' and studentUniqueId in (SELECT distinct studentUniqueId 
							FROM jnkcounciling.approval_audit
							where DBTApplicationStatus='Approved' AND studentUniqueId NOT IN('10001'))";
	
	
	$result = mysqli_query($con, $studentQuery) or die("Could not execute query");
	*/
	
	$studentQuery	=	"SELECT finalApprovalDate,DBTApplicationSubmittedDate,admissionThroughCCP,studentUniqueId,disclaimer,studentRank,name,fatherName,birthDate,casteCategory,primaryEmailId,DBTApplicationStatus,collegeUniqueId,courseUniqueId,streamAllottedIn,otherStudentCollegeName,otherStudentStreamAppliedFor,OtherStudentCourseName,instituteAddress,instituteState,examType from students where yearOfCounselling=? and studentUniqueId in (SELECT distinct studentUniqueId 
							FROM jnkcounciling.approval_audit
							where DBTApplicationStatus='Approved' AND studentUniqueId NOT IN('10001'))";
		$stmt1 = mysqli_prepare($con, $studentQuery);
		mysqli_stmt_bind_param($stmt2, 'i',$hoId);
		mysqli_stmt_execute($stmt1) or die("Query Failed1");
		$result = mysqli_stmt_get_result($stmt1);
		
		
	$studentData=array();
	
	while($row = mysqli_fetch_array($result)){
		
	/*	$approval_auditQuery	=	"	SELECT 	actualPaymentTill,paymentType 
										FROM	approval_audit 
										WHERE	studentUniqueId='".$row['studentUniqueId']."' and DBTApplicationStatus='Approved' order by approvalAuditId desc limit 1";
	
	
		$approval_auditresult = mysqli_query($con, $approval_auditQuery) or die("Could not execute query");
		$approval_audit_row=mysqli_fetch_array($approval_auditresult);
		*/
				
	$approval_auditQuery	=	"SELECT actualPaymentTill,paymentType FROM	approval_audit WHERE studentUniqueId=? and DBTApplicationStatus='Approved' order by approvalAuditId desc limit 1";	
		
		$stmt2 = mysqli_prepare($con, $approval_auditQuery);
		mysqli_stmt_bind_param($stmt2, 'i',$row['studentUniqueId']);
		mysqli_stmt_execute($stmt2) or die("Query Failed1");
		$approval_auditresult = mysqli_stmt_get_result($stmt2);
		$approval_audit_row = mysqli_fetch_array($approval_auditresult, MYSQLI_ASSOC);	
		
		$row_array['Payment_Till']= $approval_audit_row['actualPaymentTill']."-".$row['examType'];
		
		$row_array['Approval_Date'] = $row['approvalDate'];
		$row_array['Submission_Date'] = $row['DBTApplicationSubmittedDate'];
		$row_array['AdmissionThroughCCP'] = $row['admissionThroughCCP'];
		$row_array['Candidate_Id'] = $row['studentUniqueId'];
		$row_array['Beneficiary_Code'] = $row['disclaimer'];
		$row_array['Candidate_Rank'] = $row['studentRank'];
		$row_array['Candidate_Name'] = $row['name'];
		$row_array['Father_Name'] = $row['fatherName'];
		$row_array['DOB'] = $row['birthDate'];
		$row_array['Caste_Category'] = $row['casteCategory'];
		$row_array['EmailId'] = $row['primaryEmailId'];
		
		
		//$row_array['Candidate_Status'] = $row['DBTApplicationStatus'];
		if($row['admissionThroughCCP']=='Yes')
		{
		if($row['collegeUniqueId']!='' && $row['collegeUniqueId']!=null){
			if($row['streamAllottedIn']=='Engineering and Technology')
			{
				$row['streamAllottedIn']='Engineering';
			}
		$row_array['Candidate_Category'] = $row['streamAllottedIn'];
		
	/*	
		$collegeQuery	=	"select * FROM colleges where collegeUniqueId='".$row['collegeUniqueId']."'";
		$collegeresult = mysqli_query($con, $collegeQuery) or die("Could not execute query");
		$college_row=mysqli_fetch_array($collegeresult);
		*/		
		
		$collegeQuery	=	"select * FROM colleges where collegeUniqueId=?";
		$stmt3 = mysqli_prepare($con, $collegeQuery);
		mysqli_stmt_bind_param($stmt3, 'i',$row['collegeUniqueId']);
		mysqli_stmt_execute($stmt3) or die("Query Failed1");
		$collegeresult = mysqli_stmt_get_result($stmt3);
		$college_row = mysqli_fetch_array($collegeresult, MYSQLI_ASSOC);
		
		/*
		$courseQuery	=	"select  * FROM  courses  where  courseUniqueId='".$row['courseUniqueId']."'";
		$courseresult = mysqli_query($con, $courseQuery) or die("Could not execute query");
		$course_row=mysqli_fetch_array($courseresult);
		*/
		
		$courseQuery	=	"select  * FROM  courses  where  courseUniqueId=?";
		$stmt4 = mysqli_prepare($con, $courseQuery);
		mysqli_stmt_bind_param($stmt4, 'i',$row['courseUniqueId']);
		mysqli_stmt_execute($stmt4) or die("Query Failed1");
		$courseresult = mysqli_stmt_get_result($stmt4);
		$course_row = mysqli_fetch_array($courseresult, MYSQLI_ASSOC);
		
		$row_array['College_Name'] = $college_row['name'];
		$row_array['College_Address'] = $college_row['address'];
		$row_array['College_State'] = $college_row['state'];
		$row_array['Course_Name'] = $course_row['courseName'];
		
	}else
		{
		if($row['otherStudentStreamAppliedFor']=='Engineering and Technology')
		{
		$row['otherStudentStreamAppliedFor']='Engineering';
		}
		
		$row_array['Candidate_Category'] = $row['otherStudentStreamAppliedFor'];
		$row_array['College_Name'] = $row['otherStudentCollegeName'];
		$row_array['College_Address'] = $row['instituteAddress'];
		$row_array['College_State'] = $row['instituteState'];
		$row_array['Course_Name'] = $row['OtherStudentCourseName'];
		}
		}
		if($row['admissionThroughCCP']=='No')
		{
		$row_array['Candidate_Category'] = $row['otherStudentStreamAppliedFor'];
		$row_array['College_Name'] = $row['otherStudentCollegeName'];
		$row_array['College_Address'] = $row['instituteAddress'];
		$row_array['College_State'] = $row['instituteState'];
		$row_array['Course_Name'] = $row['OtherStudentCourseName'];
		}
		array_push($studentData,$row_array);
	}
	
	echo json_encode($studentData);
?>