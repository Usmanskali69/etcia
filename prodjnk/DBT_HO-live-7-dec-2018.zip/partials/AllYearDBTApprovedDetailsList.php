<div class="page-header">
	<h3>All Year DBT Approved Applications</h3>
	<div align="right">
	<a href="./partials/ajax/getExportedApprovedData.php"  class="btn btn-primary">Export Data</a>
	</div>
</div>
<table id="table1" data-toggle="table" data-url="partials/data/AllYearDBTApprovedApplication.php" data-show-export="true" data-cache="false" data-height="420" data-sort-name="Rejection_Date" data-sort-order="asc" data-show-columns="true" data-show-refresh="true" data-search="true" data-select-item-name="toolbar1" data-striped="true" data-pagination="true" data-side-pagination="client" data-page-list="[5, 10, 20, 50, 100, 200]">
	<thead>
		<tr>
			<!--<th data-field="Approval_Date" data-visible="true" data-sortable="true" >Approval Date/Time</th>
			<th data-field="Submission_Date" data-visible="true" data-sortable="true" >Submission Date/Time</th>-->
			<th data-field="AdmissionThroughCCP" data-visible="true" data-sortable="true" >Admission Through CCP</th>
			<th data-field="Candidate_Id" data-visible="true" data-sortable="true" >Candidate ID</th>
		<!--<th data-field="Candidate_Rank" data-visible="true" data-sortable="true" >Candidate Rank</th>-->
			<th data-field="Payment_Till" data-visible="true" data-sortable="true" >Payment Till</th>
			<th data-field="Candidate_Name" data-sortable="true" data-switchable="false">Candidate Name</th>
			<th data-field="Father_Name" data-sortable="true" data-switchable="false">Father Name</th>
			<th data-field="DOB" data-sortable="true" data-switchable="false">Date of Birth</th>
			<th data-field="Caste_Category" data-sortable="true" data-switchable="false">Caste Category</th>
			<th data-field="EmailId" data-sortable="true" data-switchable="false">Email Id</th>
			<th data-field="College_Name" data-sortable="true" data-switchable="false">College Name</th>
			<th data-field="College_Address" data-sortable="true" data-switchable="false">College Address</th>
			<th data-field="College_State" data-sortable="true" data-switchable="false">College State</th>
			<th data-field="Course_Name" data-sortable="true" data-switchable="false">Course Name</th>
			<!--<th data-field="edit_delete" data-formatter="operateFormatterVerifiedAllYear" data-events="operateEvents">Edit</th>-->
			
		</tr>
	</thead>
</table>

