<?php
	
	$do = $_GET["do"];
	
	if($do == "login") {

		$hoId=$_POST['hoId'];
		$loginpassword=$_POST['password'];
		
		require(realpath("../../db_connect.php"));
		
		$query = "SELECT * FROM dbtho where BINARY hoId like '" . $hoId . "' AND hoPassword like '" . md5($loginpassword). "'";
		//echo $query;
		$user = mysqli_query($con, $query);
		//echo mysqli_num_rows($user);
		if(mysqli_num_rows($user) == 1) {
			$user_row = mysqli_fetch_array($user);
			if($user_row['hoId']==$hoId) 
			{
				session_start();		
				
				$now = new DateTime();
				$now->add(new DateInterval('PT1H'));
				$now = $now->format('Y-m-d H:i:s');
				
				$_SESSION["valid5"] = true;
				$_SESSION["hoId"] = $hoId;
				$_SESSION["timeout"] = $now;
			
				mysqli_close($con);
				header('Location: ../../../DBT_HO/index.php');
			} else {
			$failureResponse = "invalid credentials";
			mysqli_close($con);
			header('Location: ../../../DBT_HO/login.php?r=invalid credential');
		}
		} else {
			$failureResponse = "invalid credentials";
			mysqli_close($con);
			header('Location: ../../../DBT_HO/login.php?r=invalid credential');
		}
	} else if($do == "logout") {
		session_start();
		$_SESSION = array();
		session_destroy();
		header('Location: ../../../DBT_HO/login.php');
	}
?>