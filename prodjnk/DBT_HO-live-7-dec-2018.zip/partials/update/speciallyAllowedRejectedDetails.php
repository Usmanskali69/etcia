<?php
session_start();
include('../../db_connect.php');

	$candidateID = htmlspecialchars($_GET["candidateID"]);

	$studentQuery="SELECT DBTApplicationStatus from students where studentUniqueId=?";
	$stmt1 =mysqli_prepare($con, $studentQuery);
	mysqli_stmt_bind_param($stmt1, 'i', $candidateID);
	mysqli_stmt_execute($stmt1);
	$studentResult = mysqli_stmt_get_result($stmt1);

	$student_row = mysqli_fetch_array($studentResult, MYSQLI_ASSOC);

	if($student_row['DBTApplicationStatus'] == 'New')
	{	
		$DBTApplicationStatus = 'Rejected';
		$query="UPDATE students 
					SET DBTApplicationStatus=?
					WHERE
						studentUniqueId=?";
			$stmt1 =mysqli_prepare($con, $query);
			mysqli_stmt_bind_param($stmt1, 'si', $DBTApplicationStatus, $candidateID);
			$result =mysqli_stmt_execute($stmt1);
				
		if($result)
		{
			echo "success";
		}
		else
		{
			echo "failure";
		}
	}
	else
	{
		echo "processed";
	}


?>