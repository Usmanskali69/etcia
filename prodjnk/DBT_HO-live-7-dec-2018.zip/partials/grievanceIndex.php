<br><ul class="nav nav-tabs">
  <?php if($_SESSION['hoId'] == "EGOVERNANCE"){?>
  <li class="dropdown active" id="section2InProgressGrievancesId"><a class="dropdown-toggle" data-toggle="dropdown" href="?q=section2InProgressGrievances"><i class="fa fa-2x fa-spinner" aria-hidden="true"></i> In Progress Grievances<span class="caret"></span></a>
  <ul class="dropdown-menu">
  <li><a href="?q=section2InProgressGrievances&q1=2012-13">2012-13</a></li>
  <li><a href="?q=section2InProgressGrievances&q1=2013-14">2013-14</a></li>
  <li><a href="?q=section2InProgressGrievances&q1=2014-15">2014-15</a></li>
  <li><a href="?q=section2InProgressGrievances&q1=2015-16">2015-16</a></li>
  <li><a href="?q=section2InProgressGrievances&q1=2016-17">2016-17</a></li>
  <li><a href="?q=section2InProgressGrievances&q1=Not Yet Admitted">2017-18</a></li>
  <li><a href="?q=section2InProgressGrievances&q1=Institute">Institute</a></li>
  <li><a href="?q=section2InProgressGrievances&q1=Facilitator">Facilitator</a></li>
  <li><a href="?q=section2InProgressGrievances&q1=EGOVERNANCE">EGOVERNANCE</a></li>
  </ul></li>
  <?php } else {?>
  <li class="active" id="section2InProgressGrievancesId"><a data-toggle="tab" href="#section2InProgressGrievances"><i class="fa fa-2x fa-spinner" aria-hidden="true"></i> In Progress Grievances</a></li>
  <?php } ?>
  <li class="section3ClosedGrievancesId" id="section3ClosedGrievancesId"><a data-toggle="tab" href="#section3ClosedGrievances"><i class="fa fa-2x fa-check-circle" aria-hidden="true"></i> Closed Grievances</a></li>
  <?php if($_SESSION['hoId'] != "LNT")
  {
  ?>
  <li class="section4AddGrievanceId" id="section4AddGrievanceId"><a data-toggle="tab" href="#section4AddGrievance"><i class="fa fa-2x fa-plus-circle aria-hidden="true"></i> Add Grievance</a></li>
  <?php
  }
  ?>
</ul>

<div class="tab-content">
	  <div id="section2InProgressGrievances" class="tab-pane fade in active">
		<?php
			include('grievances\InProgressGrievances.php');	
		?>
	  </div>
	  <div id="section3ClosedGrievances" class="tab-pane fade">
		<?php
			include('grievances\ClosedGrievances.php');	
		?>
	  </div>
	  <div id="section4AddGrievance" class="tab-pane fade">
		<?php
			include('grievances\addGrievance.php');	
		?>
	  </div>
	</div>