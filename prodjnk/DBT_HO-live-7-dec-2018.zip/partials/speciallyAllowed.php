<?php 
$year = substr($_SESSION['hoId'],6,7); 
?>
<div class="container-fluid"><br>
	<table id="table-methods-table" data-height="480" data-toggle="table" data-url="partials/data/speciallyAllowed.php?year=<?php echo $year;?>" data-pagination="true" data-search="true" data-sort-name="grievanceComments" data-sort-order="asc" data-show-refresh="true" >
		<thead >
			<tr>
				<div class="row" id="insideTable">
					<th data-field="Candidate_Id" data-visible="true" data-sortable="true" >Candidate ID</th>
					<th data-field="name" data-sortable="true">Student Name</th>
					<th data-field="fatherName" data-sortable="true">Father Name</th>							
					<th data-field="OtherStudentCollegename">College Name</th>
					<th data-field="instituteState">State</th>
					<th data-field="casteCategory" data-visible="false">Caste Category</th>
					<th data-field="otherStudentStreamAppliedFor">Category</th>
					<th data-field="OtherStudentCourseName" >Course</th>
					<th data-field="edit_delete" data-formatter="operateSpeciallyAllowed" data-events="operateEvents">Edit</th>									
				</div>
			</tr>
		</thead>
	</table>
</div>
	
