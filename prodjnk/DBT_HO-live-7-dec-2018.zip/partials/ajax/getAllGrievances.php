<?php
session_start();
if(isset($_SESSION['hoId']) && !empty($_SESSION['hoId']))
{
include('../../db_connect.php');
$Id  = htmlspecialchars($_GET['Id']);

echo '<div class="modal-header" >
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">All Grievances Raised by ('.$Id.')</h4>
      </div>      
        <div class="modal-body">';
$html='<table class="table table-bordered table-condensed f11">                       						
						<thead style="background-color:#D9EDF7">							
								<th width="10%" align="left">Grievance Id</th>
								<th width="10%" align="left"><b>Name</b></th>
								<th width="10%" align="left">Email&Mobile</th>								
								<th width="10%" align="left">Nature</th>
								<th width="10%" align="left">Assigned To</th>
								<th width="10%" align="left">Status</th>                                								
								<th width="10%" align="left">Comments</th>													
							</thead>
							';							
	if(( preg_match('/^[1-9][0-9]/', $Id) == 0) )
	{
		// $query= "SELECT * FROM grievance.grievances where grievanceEmailId = '$Id'";
		
		$query= "SELECT * FROM grievance.grievances where grievanceEmailId = ?";
	}
	else
	{
		// $query= "SELECT * FROM grievance.grievances where grievanceCreatedById = '$Id'";
		
		$query= "SELECT * FROM grievance.grievances where grievanceCreatedById = ? ";
	}
	// $Result	= mysqli_query($con,$query) or die("Could not execute query");

		$stmt = mysqli_prepare($con, $query);
	mysqli_stmt_bind_param($stmt, 's', $Id);
	mysqli_stmt_execute($stmt);
	$Result = mysqli_stmt_get_result($stmt);
	
	while($row=mysqli_fetch_array($Result, MYSQLI_ASSOC)){	
	$html.= '<tr>	
	<td><b>'.$row['grievanceId'].'</b> <br>on<br> <b>'.$row['grievanceCreatedOn'].'</b></td>
	<td>'.$row['grievanceName'].'</td>
	<td>'.$row['grievanceEmailId'].'<br>&<br>'.$row['grievanceMobileNumber'].'</td>
	<td>'.$row['grievanceNature'].'</td>
	<td>'.$row['grievanceAssignedTo'].'</td>
	<td>'.$row['grievanceStatus'].'</td>';
	
	// $auditQuery="SELECT * FROM grievance.comments WHERE grievanceId=".$row['grievanceId']." order by commentedOn desc limit 1";	
	
	// $auditResult = mysqli_query($con,$auditQuery);
	// $audit_row=mysqli_fetch_assoc($auditResult);
	
	$auditQuery="SELECT * FROM grievance.comments WHERE grievanceId=? order by commentedOn desc limit 1";	
	
	$stmt1 = mysqli_prepare($con, $auditQuery);
	mysqli_stmt_bind_param($stmt1, 's', $row['grievanceId']);
	mysqli_stmt_execute($stmt1);
	$auditResult = mysqli_stmt_get_result($stmt1);
	$audit_row=mysqli_fetch_array($auditResult, MYSQLI_ASSOC);
	
	$count= mysqli_num_rows($auditResult);
	
	if($count!=0)
	{
	$html .='<td>'.$audit_row['comments'].'<br>by<br> <b>'.$audit_row['commentedBy'].'</b><br>on<br><b>'.$audit_row['commentedOn'].'</b></td>';
	}
	else
	{
	$html .='<td>Not yet Responsed</td>';	
	}
	$html .='</tr>';	
	}$html.= '</table>
		
		</div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>';
	 echo  $html;
$con->close();
}else{
		header('Location: ../../../../jnkqa/DBT_HO/login.php');
	}
?> 