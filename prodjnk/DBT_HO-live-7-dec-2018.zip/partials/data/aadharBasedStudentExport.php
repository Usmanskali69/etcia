<?php
	session_start();
	$hoId=$_SESSION['hoId'];
	$hoId=substr($hoId, -7);
	include( '../../../rifd/Classes/PHPExcel.php');
	include( '../../../Classes/PHPExcel/IOFactory.php');
	$con = mysql_connect("192.168.1.101","root","admin123");
    $db = mysql_select_db("jnkcounciling",$con);
	
	$objReader = PHPExcel_IOFactory::createReader('Excel2007');
    $objPHPExcel = new PHPExcel();
	$objPHPExcel->getActiveSheet()->setTitle('Sheet1');

	$batchNumber=$_GET['batchNumber'];
	
	$sql = "SELECT 
				a.name as Full_Name_in_English,
				a.name as Full_Name_in_Recognized_Official_Language,
				CASE WHEN a.gender='Male' THEN 'M' WHEN a.gender='Female' THEN 'F' END as Gender,
				a.permanentAddress as Address_line_1,
				'' as Address_line_2,
				'' as Address_line_3,
				CASE WHEN a.permanentDistrict='Leh' THEN 'LEH (LADAKH)' WHEN a.permanentDistrict!='Leh' THEN a.permanentDistrict END as District,
				a.permanentState as State,
				'India' as Country,
				a.bankName as Bank_Name,
				a.bankifscCode as IFSCCode,
				a.bankAccountNumber as Account_Number,
				a.UIDNo as Aadhaar_Number,
				a.permanentPinCode as Pincode,
				a.studentUniqueId as Scheme_Specific_ID,
				50000 as Center__Share_Payment_Amount,
				50000 as State_Share_Payment_Amount
			FROM 
				students a
			WHERE 
				
				 DBTApplicationFormSubmitted='Y'
				 and DBTApplicationStatus='Submitted' 
			
				 and yearOfCounselling='".$hoId."'
				 and approvalFlag='N'
				 and isScholarshipCompleted is null
				AND a.name not in( 'test','sad')
				AND (disclaimer is null OR disclaimer ='')";
		//	 and admissionThroughCCP='Yes'
		//AND applicationStatus='Approved'
		//b.approvedTotal as Center__Share_Payment_Amount,
		//b.approvedTotal as State_Share_Payment_Amount		
	$rec = mysql_query($sql) or die (mysql_error());
	$num_fields = mysql_num_fields($rec);
	
	//$chars	= array("B1", "C1", "D1","E1","F1","G1","H1","I1","J1","L1","N1","Q1","S1","T1");
	
	$objPHPExcel->getActiveSheet()->setCellValue('A1', "Full Name in English");
	$objPHPExcel->getActiveSheet()->setCellValue('B1', "Full Name in Recognized Official Language");
	$objPHPExcel->getActiveSheet()->setCellValue('C1', "Gender");
	$objPHPExcel->getActiveSheet()->setCellValue('D1', "Address line 1");
	$objPHPExcel->getActiveSheet()->setCellValue('E1', "Address line 2");
	$objPHPExcel->getActiveSheet()->setCellValue('F1', "Address line 3");
	$objPHPExcel->getActiveSheet()->setCellValue('G1', "District");
	$objPHPExcel->getActiveSheet()->setCellValue('H1', "State");
	$objPHPExcel->getActiveSheet()->setCellValue('I1', "Country");
	$objPHPExcel->getActiveSheet()->setCellValue('J1', "Bank Name");
	$objPHPExcel->getActiveSheet()->setCellValue('K1', "IFSCCode");	
	$objPHPExcel->getActiveSheet()->setCellValue('L1', "Account Number");
	$objPHPExcel->getActiveSheet()->setCellValue('M1', "Aadhaar Number");	
	$objPHPExcel->getActiveSheet()->setCellValue('N1', "Pincode");
	$objPHPExcel->getActiveSheet()->setCellValue('O1', "Scheme Specific ID");	
	//$objPHPExcel->getActiveSheet()->setCellValue('N1', "Centre_Share_Payment_Amount");
	$objPHPExcel->getActiveSheet()->setCellValue('P1', "Center Share Payment Amount");
	$objPHPExcel->getActiveSheet()->setCellValue('Q1', "State Share Payment Amount");
	
	$rowNum=2;
	$c = 0;
	while($row = mysql_fetch_assoc($rec))
    {
		
			$objPHPExcel->getActiveSheet()->setCellValue('A'.$rowNum, $row['Full_Name_in_English']);
			$objPHPExcel->getActiveSheet()->setCellValue('B'.$rowNum, $row['Full_Name_in_Recognized_Official_Language']);
			$objPHPExcel->getActiveSheet()->setCellValue('C'.$rowNum, $row['Gender']);
			$objPHPExcel->getActiveSheet()->setCellValue('D'.$rowNum, $row['Address_line_1']);
			$objPHPExcel->getActiveSheet()->setCellValue('E'.$rowNum, $row['Address_line_2']);
			$objPHPExcel->getActiveSheet()->setCellValue('F'.$rowNum, $row['Address_line_3']);
			$objPHPExcel->getActiveSheet()->setCellValue('G'.$rowNum, $row['District']);
			$objPHPExcel->getActiveSheet()->setCellValue('H'.$rowNum, $row['State']);
			$objPHPExcel->getActiveSheet()->setCellValue('I'.$rowNum, $row['Country']);
			$objPHPExcel->getActiveSheet()->setCellValue('J'.$rowNum, $row['Bank_Name']);
			$objPHPExcel->getActiveSheet()->setCellValue('K'.$rowNum, $row['IFSCCode']);
			$objPHPExcel->getActiveSheet()->setCellValueExplicit('L'.$rowNum, $row['Account_Number'], PHPExcel_Cell_DataType::TYPE_STRING);
			$objPHPExcel->getActiveSheet()->setCellValueExplicit('M'.$rowNum, $row['Aadhaar_Number'], PHPExcel_Cell_DataType::TYPE_STRING);
			$objPHPExcel->getActiveSheet()->setCellValue('N'.$rowNum, $row['Pincode']);
			$objPHPExcel->getActiveSheet()->setCellValue('O'.$rowNum, $row['Scheme_Specific_ID']);
			$objPHPExcel->getActiveSheet()->setCellValue('P'.$rowNum, $row['Center__Share_Payment_Amount']);
			$objPHPExcel->getActiveSheet()->setCellValue('Q'.$rowNum, $row['State_Share_Payment_Amount']);
			$rowNum++;
    } 
	
	/* $counter = 'counterAadharStu.txt';
	$number = file_get_contents($counter);
	$number++;
	$fh = fopen($counter, 'w');
	fwrite($fh, $number);
	fclose($fh);
	$count = file_get_contents('counterAadharStu.txt'); */
	
	/* $rowsCount = mysql_num_rows($rec);
	echo $rowsCount; */
 /* if($rowsCount != '')
	{ */
	$sql2 = "SELECT
				count
			 FROM
				others
			 WHERE
				Id = 2";
				
	$rec2 = mysql_query($sql2) or die (mysql_error());
	$row2 = mysql_fetch_assoc($rec2);
				
	$count = $row2['count'];
	$count++;
	
	$sql3 = "UPDATE 
				others 
			 SET 
				count = '$count'
			 WHERE
				Id = 2";	
				
	$rec3 = mysql_query($sql3) or die (mysql_error());
	$row3 = mysql_fetch_assoc($rec3);
	
	header('Content-Type: application/vnd.ms-excel');
	$name="00".$count."_JK_".date("d")."_".date("m")."_".date("Y");
	header('Content-Disposition: attachment;filename="'.$name.'.xlsx"');
	header('Cache-Control: max-age=0');
	header('Cache-Control: max-age=1');
	header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
	header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
	header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
	header ('Pragma: public'); // HTTP/1.0

	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	$objWriter->save('php://output');	
	exit;
	/* }
	else
	{
		 echo "<script type='text/javascript'>alert('No records found');</script>";
	} */
?>