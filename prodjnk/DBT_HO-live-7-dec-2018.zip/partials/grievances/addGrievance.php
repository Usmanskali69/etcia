<?php
	require_once(realpath("./session/session_verify.php"));
?>
		<br>
		
		   <div class="tab-pane" id="grievanceForm">
			
				 <div class="header" >
				 <?php include("../db_connect.php");
				
				// fetching Student ID from session
				$hoId=htmlspecialchars($_SESSION['hoId']);
				if(isset($_SESSION['hoId']) && !empty($_SESSION['hoId']))
       {				
				//$query='SELECT * FROM grievance.grievances WHERE grievanceCreatedById="'.$hoId.'" and grievanceStatus = "In Progress" ';
				//echo $query;
				//$result = mysqli_query($con,$query);
				
				$query='SELECT * FROM grievance.grievances WHERE grievanceCreatedById=? and grievanceStatus = "In Progress" ';	
				$stmt1 =mysqli_prepare($con, $query);
				mysqli_stmt_bind_param($stmt1, 's', $hoId);
				mysqli_stmt_execute($stmt1);
				$result = mysqli_stmt_get_result($stmt1);
				$count = mysqli_num_rows($result);
					
				mysqli_close ($con);
				if($count<50){
				?>
				<button type="button" class="btn btn-info  new-record" id="createGrievanceId" onclick="createId()" style="margin:10px;">  <span style="padding-left:5px">Add Grievance</span></button>
				<?php
			}
				?>
				 <!--<span id="grievance"  ></span>
	<h4>View Grievance</h4>-->
</div>
<div class="col-md-12">
						<table id="table-methods-table" data-toggle="table" data-url="operations/showGrievanceDBT.php?id=<?php echo $hoId;?>" data-pagination="true" data-search="true" data-show-refresh="true">
							<thead  class="btn-primary">
								<tr>  
									<div class="row" id="insideTable">
										<th data-field="grievanceId">Grievance ID</th>										
										<!--<th data-field="grievanceNature">Grievance Nature</th>-->
										<th data-field="grievanceSubject">Grievance Subject</th>
										<th data-field="grievanceComments"> Comments</th>			
										<th data-field="grievanceCommentedOn">Commented On</th>										
										<th data-field="grievanceStatus" >Grievance Status</th>
										<!--<th data-field="grievanceComments">Grievance Comments</th>-->
										<th data-field="edit_delete" data-formatter="operateSave1" data-events="operateEvents1">Grievance Details</th>		
										<!--<th data-field="grievancesCreatedBy">Grievance Created By</th>-->							
									</div>
								</tr>
							</thead>
						</table>
</div>
<?php
			}else{
		header('Location: ../../../../jnkqa/DBT_HO/login.php');
	}
				?>	
					
</div> 
			

		
		<script>
function createId() {
	var d = new Date();
	var str1 = 16;
	var str2 = ("0" + (d.getMonth() + 1)).slice(-2);
	var str3 = ("0" + d.getDate()).slice(-2);
	var str4 = ("0" + d.getHours()).slice(-2);
	var str5 = ("0" + d.getMinutes()).slice(-2);
	var str6 = ("0" + d.getSeconds()).slice(-2);
	
	var grievanceId=str1+str2+str3+str4+str5+str6;
	window.location.href='addGrievanceForm.php?grievanceId='+grievanceId;
	
}
$(document).ready(function() {
//for redirecting to grievances after submit grievance
var q="<?php echo $_GET['q']; ?>";
if(q == 'submitted')
{
	$('#grievanceFormId').addClass('active');
	$('#grievanceForm').addClass('active');
	$('#grievanceFormId a ').attr("aria-expanded","true");
	$('#applicationFormId').removeClass('active');
	$('#applicationForm').removeClass('active');
}
$('#showGrievanceForm').submit(function(event) {
	    event.preventDefault();	
		
		$.ajax({
			url:"operations/showGrievanceDBT.php",
			type:"GET",
			dataType: "JSON",
			data: $("#showGrievanceForm").serialize()/*{ studentUniqueId: $('#studentUniqueID').val()} */,
			beforeSend: function() { 
								$("#showGrievanceDetails").html("");
								$("#showGrievance").prop("disabled", true); // disable button
								$("#showGrievance").val('Saving ...');
							},
			success: function(reply){
						console.log(reply);
							$("#showGrievance").prop("disabled", false); // disable button
								$("#showGrievance").val('Submit');	
								$('showGrievanceDetails').html("Candidate Id");
								
						if(reply.length==1){
								
								$.each(reply[0], function(index, value) {
								console.log(index+" : "+value);
								$("#showGrievanceDetails").append("<b class='col-lg-3'><font color='Red'>"+index+"</font></b>");
								$("#showGrievanceDetails").append("<b class='col-lg-9'><font color='Green'>"+value+"</font></b><br>");								
								});
								$("#showGrievanceDetails").append("<br>");		
								$("#showGrievanceDetails").append("<br>");	
								
								
							}else{
								$("#showGrievanceDetails").html("<b><font color='Red'>Grievance ID does not exists.</font></b>");
							}
						}
		});
		});
   
});


     
</script>
<script>
function operateSave1(value, row, index) {
				return [
					'<div class="text-center"><a class="showGrievanceDBT" href="javascript:void(0)" title="Click for Full Details">',
					'<span class="glyphicon glyphicon-eye-open"></span>',
					'</a>',
					'</div>',
					
				].join('');
			}
			
			
			
			
			window.operateEvents1 = {
				
				
				'click .showGrievanceDBT': function (e, value, row, index) {
					window.location = "grievanceDetailsDBT.php?candidateID="+row.grievanceCreatedById+"&grievanceId="+row.grievanceId;
				}
			};
			</script>
			
	</body>
</html>