<?php
	include('../db_connect.php');
	// $auditQrys = "SELECT * FROM approval_audit WHERE studentUniqueId='".$studentUniqueId."' and DBTApplicationStatus='Approved'";
	// $auditRess = mysqli_query($con, $auditQrys);
	
	$auditQrys="SELECT * FROM approval_audit WHERE studentUniqueId=? and DBTApplicationStatus='Approved'";
	$stmt = mysqli_prepare($con, $auditQrys);
	mysqli_stmt_bind_param($stmt, 'i', $studentUniqueId);
	mysqli_stmt_execute($stmt);
	$auditRess = mysqli_stmt_get_result($stmt);
	
	// $currauditQrys = "SELECT * FROM approval_audit WHERE studentUniqueId='".$studentUniqueId."' and DBTApplicationStatus='Approved' order by approvalAuditId desc limit 1";
	// $currauditRess = mysqli_query($con, $currauditQrys);
	
	$currauditQrys="SELECT * FROM approval_audit WHERE studentUniqueId=? and DBTApplicationStatus='Approved' order by approvalAuditId desc limit 1";
	$stmt = mysqli_prepare($con, $currauditQrys);
	mysqli_stmt_bind_param($stmt, 'i', $studentUniqueId);
	mysqli_stmt_execute($stmt);
	$currauditRess = mysqli_stmt_get_result($stmt);
	
	// $dropdownQuery = "SELECT isXIIMarksheetVerified FROM approval_audit WHERE studentUniqueId='".$studentUniqueId."' and DBTApplicationStatus='Approved' order by approvalAuditId desc limit 1";
	// $dropdownResult = mysqli_query($con, $dropdownQuery);
	// $dropdown_Row=mysqli_fetch_array($dropdownResult);
	
	$dropdownQuery="SELECT isXIIMarksheetVerified FROM approval_audit WHERE studentUniqueId=? and DBTApplicationStatus='Approved' order by approvalAuditId desc limit 1";
	$stmt = mysqli_prepare($con, $dropdownQuery);
	mysqli_stmt_bind_param($stmt, 'i', $studentUniqueId);
	mysqli_stmt_execute($stmt);
	$dropdownResult = mysqli_stmt_get_result($stmt);
	$dropdown_Row = mysqli_fetch_array($dropdownResult, MYSQLI_ASSOC);
	
	// $PaymentTypeQuery="	SELECT 
							// LEFT(isXIIMarksheetVerified , 1) as PAYMENT_YEAR,count(approvalAuditId) as Appearance
						// FROM
							// approval_audit
						// WHERE
							// studentUniqueId = '$studentUniqueId'
						// and DBTApplicationStatus='Approved' 
						// GROUP BY PAYMENT_YEAR 
						// order by approvalAuditId DESC LIMIT 1 ";
	// $PaymentTypeResult = mysqli_query($con, $PaymentTypeQuery);
	// $payment_type_row = mysqli_fetch_array($PaymentTypeResult);	

	$PaymentTypeQuery="SELECT 
							LEFT(isXIIMarksheetVerified , 1) as PAYMENT_YEAR,count(approvalAuditId) as Appearance
						FROM
							approval_audit
						WHERE
							studentUniqueId = ?
						and DBTApplicationStatus='Approved' 
						GROUP BY PAYMENT_YEAR 
						order by approvalAuditId DESC LIMIT 1 ";
	$stmt = mysqli_prepare($con, $PaymentTypeQuery);
	mysqli_stmt_bind_param($stmt, 'i', $studentUniqueId);
	mysqli_stmt_execute($stmt);
	$PaymentTypeResult = mysqli_stmt_get_result($stmt);
	$payment_type_row = mysqli_fetch_array($PaymentTypeResult, MYSQLI_ASSOC);	
	if($user_row['approvalFlag']=='Y')
	{
?>

<div class="container">
	<ul class="nav nav-tabs" style="margin-top:20px;">
		<li class="active"><a href="#current-application" data-toggle="tab">Current Application</a><li>
		<li><a href="#previous-approval-application" data-toggle="tab">Previously Approved Application</a></li>
	</ul>
	<div class="tab-content" style="border:1px solid #E0E0E0;">
		<div class="tab-pane active" id="current-application">
				<form id="finalApproveOrReject" name="finalApproveOrReject" class="form-horizontal" role="form" method="post" enctype="multipart/form-data">
				<input hidden name="category" id="category" value="<?php echo $college_row['category'];?>"/>
				<input hidden name="stream" id="stream" value="<?php echo $user_row['otherStudentStreamAppliedFor'];?>"/>
				<input hidden name="admissionThroughCCP" id="admissionThroughCCP" value="<?php echo $user_row['admissionThroughCCP'];?>"/>
				<input hidden name="yearOfCounselling" id="yearOfCounselling" value="<?php echo $user_row['yearOfCounselling'];?>"/>
				<div class="container" style="background-color: <?php if($user_row['admissionThroughCCP']=='Yes'){if($user_row['yearOfCounselling']=='2012-13'){echo '#FFFFCC';}else if($user_row['yearOfCounselling']=='2014-15'){echo '#CCFFCC';}else if($user_row['yearOfCounselling']=='2013-14'){echo '#D0D0D0';}else if($user_row['yearOfCounselling']=='2015-16'){echo '##FFFFFF ';}}else{ echo '#FFCCCC';}?>">
							<div class="panel-body">
								<div class="col-sm-12" role="complementary">
									<?php
								if(mysqli_num_rows($currauditRess) > 0){
								?>
								<div class="panel panel-default">
									<div class="panel-body table-responsive">
									<table class="table table-bordered table-condensed f11">
										<tr>
											<td colspan="5" align="center" class="danger"><b>Previously Approved Details</b></td>
										</tr>
										<tr>
											<td  align="left" width="20%"><b>Candidate Id</b></td>
											<td  align="left" width="20%"><b>Payment Till</b></td>
											<td  align="left" width="20%"><b>Approved Total</b></td>
											<td  align="left" width="20%"><b>Payment Type</b></td>
											<td  align="left" width="20%"><b>Final Approval Date</b></td>
														
										</tr>
										<?php
											
												while($audit_row = mysqli_fetch_array($currauditRess)){
										?>
													<tr>
														<td  align="left"><?php echo $audit_row['studentUniqueId'];?></td>
														<?php if($audit_row['isXIIMarksheetVerified']==''){?>
												<td  align="left"><?php echo $audit_row['actualPaymentTill'].'-'.$audit_row['paymentType'];?></td>
												<?php } else {?>
											    <td  align="left"><?php echo $audit_row['isXIIMarksheetVerified'];?></td>
												<?php } ?>
														<td  align="left"><?php echo $audit_row['approvedTotal'];?></td>
														<td  align="left"><?php echo $audit_row['paymentType'];?></td>
														<td  align="left"><?php echo $audit_row['finalApprovalDate'];?></td>
														
														
														
													</tr>
										<?php
												}
											
										?>
									</table>
									</div>
								</div>
								<?php
								}
								?>
									<div class="panel panel-default">
										<div class="panel-body table-responsive">
										
										<table class="table table-bordered table-condensed f11">
											<tr>
												<td colspan="4" align="center" class="danger"><b>Basic Details</b></td>
											</tr>
											
											<tr>
												<td  align="left" width="20%"><b>Candidate Id :</b></td>
												<td  align="left"><input type="hidden" id="candidateID" name="candidateID" value="<?php echo $user_row['studentUniqueId'];?>"/><?php echo $user_row['studentUniqueId'];?></td>
													
												<td valign="center" width="15%"  rowspan="8">
														<img src="../jk_media/<?php echo $user_row['photo'];?>" width="200" height="200" style="background: 10px solid black" >
												</td>
											</tr>
											<tr>
											<td align="left" width="20%"><b>Beneficiary Code:</b></td>
											
											 <?php if($user_row['approvalFlag']=='N' || $user_row['finalApprovedFlag']=='N'){ ?>
												<td  align="left"><input type="text" id="disclaimer" class="form-control" name="disclaimer" value="<?php echo $user_row['disclaimer'];?>" </td>
						
											<?php	}
											else{ ?>
												<td  align="left"><input type="text" id="disclaimer" class="form-control" name="disclaimer" value="<?php echo $user_row['disclaimer'];?>" required="required" readonly></td>
											<?php } ?>
											</tr>
											<!--<tr>
												<td align="left" width="20%"><b>Beneficiary Code:</b></td>
												<td align="left"><?php //echo $user_row['disclaimer'];?></td>
											</tr>-->
											<tr>
												<td align="left" width="20%"><font color="Red"><b>Candidate Name:</b></font></td>
												<td align="left"> <?php if($user_row['speciallyAllowedFlag']=='Y'){ echo $user_row['name']; }else{echo $user_row['firstName'];?>&nbsp;<?php echo $user_row['middleName'];?>&nbsp;<?php echo $user_row['lastName'];}?></td>
											</tr>
											<tr>
												<td align="left" width="20%"><b>Gender:</b></td>
												<td align="left"><?php echo $user_row['gender'];?></td>
											</tr>
											<tr>
												<td align="left" width="20%"><b>Father Name:</b></td>
												<td align="left"><?php echo $user_row['fatherName'];?></td>
											</tr>
											<tr>
												<td align="left" width="20%"><b>Date Of Birth:</b></td>
												<td align="left"><?php echo $user_row['birthDate'];?></td>
											</tr>
											<tr>
												<td align="left" width="20%"><b>Caste Category:</b></td>
												<td align="left"><?php echo $user_row['casteCategory'];?></td>
											</tr>
							
											<tr>
												<td align="left" width="20%"><b>Mobile No:</b></td>
												<td align="left"><?php echo $user_row['mobileNo'];?></td>
											</tr>
											<tr>
												<td align="left" width="20%"><b>Alternate Email Id (if any):</b></td>
												<td align="left"><?php echo $user_row['alternateEmailId'];?></td>
											</tr>
											<tr>
												<td align="left" width="20%"><font color="Red"><b>Aadhar Card Number:</b></font></td>
												<td align="left"><?php echo $user_row['UIDNo'];?></td>
											</tr>
											
										</table>
										</div>
									</div>
									
									<!--<div class="panel panel-default">
										<div class="panel-body table-responsive">
										<table class="table table-bordered table-condensed f11">
											<tr>
												<td colspan="4" align="center" class="danger"><b>Address Details:</b></td>
											</tr>
											<tr>
												<td colspan="2" align="center" ><b>Permanent Residential Address:</b></td>
												<td colspan="2" align="center" ><b>Current Residential Address:</b></td>
											</tr>
											<tr>
												<td width="20%" align="left"><b>Permanent Address:</b></td>
												<td width="30%" align="left"><?php echo $user_row['permanentAddress'];?></td>
												<td width="20%" align="left"><b>Current Address:</b></td>
												<td width="30%" align="left"><?php echo $user_row['hostelAddress'];?></td>
											</tr>
											<tr>
												<td width="20%" align="left"><b>State:</b></td>
												<td width="30%" align="left"><?php echo $user_row['permanentState'];?></td>
												<td width="20%" align="left"><b>State:</b></td>
												<td width="30%" align="left"><?php echo $user_row['hostelState'];?></td>
											</tr>
											<tr>
												<td width="20%" align="left"><b>District:</b></td>
												<td width="30%" align="left"><?php echo $user_row['permanentDistrict'];?></td>
												<td width="20%" align="left"><b>District:</b></td>
												<td width="30%" align="left"><?php echo $user_row['hostelDistrict'];?></td>
											</tr>
											<tr>
												<td width="20%" align="left"><b>City:</b></td>
												<td width="30%" align="left"><?php echo $user_row['permanentCity'];?></td>
												<td width="20%" align="left"><b>City:</b></td>
												<td width="30%" align="left"><?php echo $user_row['hostelCity'];?></td>
											</tr>
											<tr>
												<td width="20%" align="left"><b>Pin code:</b></td>
												<td width="30%" align="left"><?php echo $user_row['permanentPinCode'];?></td>
												<td width="20%" align="left"><b>Pin code:</b></td>
												<td width="30%" align="left"><?php echo $user_row['hostelPincode'];?></td>
											</tr>
											
										</table>					
										
										</div>	
									</div>-->
									
									
									<div class="panel panel-default">
										<div class="panel-body table-responsive">
										<table class="table table-bordered table-condensed f11">
											<tr>
												<td colspan="4" align="center" class="danger"><b>Institute Details:</b></td>
											</tr>
											
											<tr>
												<td colspan="4" align="left"><b>(I) Basic Institute Details:</b></td>
											</tr>
											<tr>
												<td width="20%" align="left"><b>Admission through Centralized Counselling Process:</b></td>
												<td width="30%" align="left"><?php echo $user_row['admissionThroughCCP'];?></td>
												<td width="20%" align="left"><b>Year of Admission:</b></td>
												<td width="30%" align="left"><?php echo $user_row['yearOfCounselling'];?></td>
											</tr>
											<tr>
												<td width="20%" align="left"><b>Institute ID:</b></td>
												<td width="30%" align="left"><?php if($user_row['collegeUniqueId']!='' && $user_row['collegeUniqueId']!=null){ echo $user_row['collegeUniqueId'];} else { echo $user_row['otherStudentCollegeId'];}?></td>
												<td width="20%" align="left"><font color="Red"><b>Institute Name:</b></font></td>
												<td width="30%" align="left"><?php if($user_row['collegeUniqueId']!='' && $user_row['collegeUniqueId']!=null){ echo $college_row['name'];} else { echo $user_row1['otherStudentCollegename'];}?></td>
											</tr>
											<tr>
												<td width="20%" align="left"><font color="Red"><b>Course Name:</b></font></td>
												<td width="30%" align="left"><?php if($user_row['collegeUniqueId']!='' && $user_row['collegeUniqueId']!=null){ echo $course_row['courseName'];} else { echo $user_row1['otherStudentCourseName'];}?></td>
												
												<td width="20%" align="left"><b>Affiliating University:</b></td>
												<td width="30%" align="left"><?php if($user_row['collegeUniqueId']!='' && $user_row['collegeUniqueId']!=null){ echo $course_row['university'];} else { echo $user_row1['otherStudentUniversity'];}?></td>
												
												
											</tr>
											
											<tr>
												<td width="20%" align="left"><b>Institute Category:</b></td>
												<td width="30%" align="left"><?php echo $user_row['instituteCategory'];?></td>
												<td width="20%" align="left"><b>Other Institute Category:</b></td>
												<td width="30%" align="left"><?php if($user_row['instituteCategory']=='Any Other'){echo $user_row['otherInstituteCategory'];}
												else {echo "-";}?></td>
											</tr>
											<tr>
												<td width="20%" align="left"><b><font color="Red">Institute Stream:</font></b></td>
												<td width="30%" align="left"><?php if($user_row['collegeUniqueId']!='' && $user_row['collegeUniqueId']!=null){ echo $college_row['category'];} else { echo $user_row['otherStudentStreamAppliedFor'];}?></td>
												
												
												
											</tr>
											<tr>
												
												<td width="20%" align="left"><b>Institute Website:</b></td>
												<td width="30%" align="left"><?php echo $user_row['instituteWebsite'];?></td>
												
											</tr>
											<tr>
												<td colspan="4" align="left"><b>(II) Contact Person Details:</b></td>
											</tr>
											<tr>
												<td width="20%" align="left"><b>Contact Person Name:</b></td>
												<td width="30%" align="left"><?php echo $user_row['contactPerson'];?></td>
												<td width="20%" align="left"><b>Designation of contact person:</b></td>
												<td width="30%" align="left"><?php echo $user_row['designationOfContactPerson'];?></td>
												
												
											</tr>
											<tr>
												<td width="20%" align="left"><b>Contact Number:</b></td>
												<td width="30%" align="left"><?php echo $user_row['contactPersonNumber'];?></td>
											</tr>
											
											
										</table>					
										</div>
										</div>
										
								<?php $current_year1=date("Y");
		$yearOfCounselling= substr($user_row['yearOfCounselling'], 0, 4);		
		if((int)$yearOfCounselling < (int)$current_year1){?>
								<div class="panel panel-default">
									<div class="panel-body table-responsive">
									<table class="table table-bordered table-condensed f11">
										<tr>
											<td colspan="7" align="center" class="danger"><b>Academic Record:</b></td>
										</tr>
										<tr>
											<td colspan="2" align="left"><b>Examination Type:</b></td>
											<td colspan="1" align="left"><?php echo $user_row['examType'];?></td>
											<td colspan="2" align="left"><b>Examination pattern:</b></td>
											<td colspan="2" align="left"><?php echo $user_row['examPattern'];?></td>
										</tr>
										<tr>
											<td colspan="2" align="left"><b>Enrollment No:</b></td>
											<td colspan="1" align="left"><?php echo $user_row['enrollmentNo'];?></td>
											<td colspan="2" align="left"><b>University Name:</b></td>
											<td colspan="2" align="left"><?php echo $user_row['UniversityName'];?></td>
										</tr>
										<tr>
										<td colspan="7">&nbsp;</td>
										</tr>
										
										
						<?php 
							include("db_connect.php");
							// $AYquery="select  @s:=@s+1 serial_number, semester,percentageOrGPA,rollNo,result,attachment,ayId from academic_year_record,
							// (SELECT @s:= 0) AS s where studentUniqueId='".$user_row['studentUniqueId']."'";							
							// $AYResult=mysqli_query($con,$AYquery);
							
				$examQuery="select  @s:=@s+1 serial_number, semester,percentageOrGPA,rollNo,result,attachment,ayId from academic_year_record,
							(SELECT @s:= 0) AS s where studentUniqueId=?";	
			$stmt4 = mysqli_prepare($con, $examQuery);
			mysqli_stmt_bind_param($stmt4, 'i', $user_row['studentUniqueId']);
			mysqli_stmt_execute($stmt4);
			$AYResult = mysqli_stmt_get_result($stmt4);
	
							if(mysqli_num_rows($AYResult)>0){?>
									
								<tr>										
										<br/><td><b>Sr no.</b></td><td><b>Semester/Year</b></td><td><b>Percentage/SGPA Obtained</b></td><td><b>Roll Number</b></td><td><b>Result</b></td><td align="center"><b>Uploaded</b></td><td align="center"><b>Preview</b></td>
								</tr>
						<?php					
							while($AY_row=mysqli_fetch_array($AYResult, MYSQLI_ASSOC)){
									?>
									<tr>
									<td><?php echo $AY_row['serial_number'];?></td>
									<td><?php echo $AY_row['semester'];?></td>
									<td><?php echo $AY_row['percentageOrGPA'];?></td>
									<td><?php echo $AY_row['rollNo'];?></td>
									<td><?php echo $AY_row['result'];?></td>
									<td align="center"><?php if($AY_row['attachment']!='' && $AY_row['attachment']!=null)
						{
							echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
						}
						else
						{
							echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
						}?></td>
									<td align="center"><?php 
										echo '<a href="../DBT_AY_AttachmentModal.php?studentId='.$user_row['studentUniqueId'].'&academicId='.$AY_row['ayId'].'&type=HO" data-toggle="modal" data-target="#attachmenModal">
					<h4><span class="glyphicon glyphicon-eye-open" aria-hidden="true">
					</span></h4>
					</a>';?></td>
									</tr>
										<?php }?>
										</table>
									</div>
								</div>
								<?php }}	?>
									<div class="panel panel-default">
										<div class="panel-body table-responsive">
											<table class="table table-bordered table-condensed f11">
												<tr>
													<td colspan="4" align="center" class="danger"><b>Bank Details:</b></td>
												</tr>
												<tr>
													<td colspan="4" align="left"><b>Saving Bank Account Details</b></td>
												</tr>
												<tr>
													<td width="20%" align="left"><font color="Red"><b>Account Holder Name(Candidate):</b></font></td>
													<td width="30%" align="left"><?php echo $user_row['accountHolderName'];?></td>
													<td width="20%" align="left"><font color="Red"><b>Bank Name:</b></font></td>
													<td width="30%" align="left"><?php echo $user_row['bankName'];?></td>
												</tr>
												<tr>
													<td width="20%" align="left"><b>Bank Branch Name:</b></td>
													<td width="30%" align="left"><?php echo $user_row['bankBranchName'];?></td>
													<td width="20%" align="left"><b>Branch Code:</b></td>
													<td width="30%" align="left"><?php echo $user_row['branchCode'];?></td>
												</tr>
												<tr>
													<td width="20%" align="left"><font color="Red"><b>Bank IFSC Code:</b></font></td>
													<td width="30%" align="left"><?php echo $user_row['bankifscCode'];?></td>
													<td width="20%" align="left"><font color="Red"><b>Bank Account Number:</b></font></td>
													<td width="30%" align="left"><?php echo $user_row['bankAccountNumber'];?></td>
												</tr>
																		
												<tr>
													<td width="20%" align="left"><b>Bank Address:</b></td>
													<td width="30%" align="left"><?php echo $user_row['bankAddress'];?></td>
													
												</tr>
												
												
											</table>								
										</div>	
									</div>
									
									<div class="panel panel-default">
										<div class="panel-body table-responsive">
											<table class="table table-bordered table-condensed f11">
												<tr>
													<td colspan="4" align="center" class="danger"><b>Attachments:</b></td>
												</tr>
												<tr>
													<td align="center" ><b>Attachment Name</b></td>
													<td align="center" ><b>Uploaded</b></td>
													<td align="center" ><b>Preview</b></td>
													<td align="center" ><b>Download</b></td>
												</tr>
												<tr>
												<?php if($user_row['speciallyAllowedFlag'] == 'N'){?>
													<td width="60%" align="left"><b>Joining Report:</b></td>
													<td width="20%" align="center">
														<?php if($user_row['joiningReport']!='' && $user_row['joiningReport']!=null)
								{
									echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
								}
								else
								{
									echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
								}?>
													</td>
													<td width="20%" align="center"><a href="DBTAttachmentModal.php?type=joiningReport&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
															<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
															</span></h4>
															</a>					
													</td>
													<td width="20%" align="center">
													<?php if($user_row['joiningReport']!='' && $user_row['joiningReport']!=null){?>
													<a href="../DBT_HO/DownloadAttachment.php?studentUniqueId=<?php echo $user_row['studentUniqueId']; ?>&attachmentName=joiningReport"><h4><span class='glyphicon glyphicon-download text-success' aria-hidden='true'></span></h4></a>
													<?php } else {?>
													<h4><span class='glyphicon glyphicon-download text-danger' aria-hidden='true'></span></h4>
													<?php } ?>
												</td>
													
												</tr>
												<tr>
													<td width="60%" align="left"><b>Tution Fee Receipts:</b></td>
													<td width="20%" align="center">
														<?php if($user_row['feeReceipt']!='' && $user_row['feeReceipt']!=null)
								{
									echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
								}
								else
								{
									echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
								}?>
													</td>
													<td width="20%" align="center"><a href="DBTAttachmentModal.php?type=feeReceipt&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
														<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
														</span></h4>
														</a>
													</td>
													<td width="20%" align="center">
													<?php if($user_row['feeReceipt']!='' && $user_row['feeReceipt']!=null){?>
													<a href="../DBT_HO/DownloadAttachment.php?studentUniqueId=<?php echo $user_row['studentUniqueId']; ?>&attachmentName=feeReceipt"><h4><span class='glyphicon glyphicon-download text-success' aria-hidden='true'></span></h4></a>
													<?php } else {?>
													<h4><span class='glyphicon glyphicon-download text-danger' aria-hidden='true'></span></h4>
													<?php } ?>
												</td>
												</tr>
												<?php }else{?>
												<tr>
													<td width="60%" align="left"><b>Joining Report/Tuition Fee/Hostel Fee/Reasonability of Rent/Other incidental charges Receipt:</b></td>
													<td width="20%" align="center">
													<?php if($user_row['joiningtutionhostelReceipt']!='' && $user_row['joiningtutionhostelReceipt']!=null)
													{
														echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
													}
													else
													{
														echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
													}?>
													</td>
													<td width="20%" align="center">
														<a href="DBTAttachmentModal.php?type=JoiningTutionHostelReceipt&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
															<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
															</span></h4>
														</a>
													</td>
													<td width="20%" align="center">
													<?php if($user_row['joiningtutionhostelReceipt']!='' && $user_row['joiningtutionhostelReceipt']!=null){?>
													<a href="../DBT_HO/DownloadAttachment.php?studentUniqueId=<?php echo $user_row['studentUniqueId']; ?>&attachmentName=joiningtutionhostelReceipt"><h4><span class='glyphicon glyphicon-download text-success' aria-hidden='true'></span></h4></a>
													<?php } else {?>
													<h4><span class='glyphicon glyphicon-download text-danger' aria-hidden='true'></span></h4>
													<?php } ?>
												</td>
												</tr>
												<tr>
													<td width="60%" align="left"><b>HSC Marksheet:</b></td>
													<td width="20%" align="center">
													<?php if($user_row['hscmarksheetfile']!='' && $user_row['hscmarksheetfile']!=null)
													{
														echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
													}
													else
													{
														echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
													}?>
													</td>
													<td width="20%" align="center">
														<a href="DBTAttachmentModal.php?type=HscMarksheet&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
															<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
															</span></h4>
														</a>
													</td>
													<td width="20%" align="center">
													<?php if($user_row['hscmarksheetfile']!='' && $user_row['hscmarksheetfile']!=null){?>
													<a href="../DBT_HO/DownloadAttachment.php?studentUniqueId=<?php echo $user_row['studentUniqueId']; ?>&attachmentName=hscmarksheetfile"><h4><span class='glyphicon glyphicon-download text-success' aria-hidden='true'></span></h4></a>
													<?php } else {?>
													<h4><span class='glyphicon glyphicon-download text-danger' aria-hidden='true'></span></h4>
													<?php } ?>
												</td>
												</tr>
												<tr>
													<td width="60%" align="left"><b>SSC Marksheet:</b></td>
													<td width="20%" align="center">
													<?php if($user_row['sscmarksheetfile']!='' && $user_row['sscmarksheetfile']!=null)
													{
														echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
													}
													else
													{
														echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
													}?>
													</td>
													<td width="20%" align="center">
														<a href="DBTAttachmentModal.php?type=SscMarksheet&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
															<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
															</span></h4>
														</a>
													</td>
													<td width="20%" align="center">
													<?php if($user_row['sscmarksheetfile']!='' && $user_row['sscmarksheetfile']!=null){?>
													<a href="../DBT_HO/DownloadAttachment.php?studentUniqueId=<?php echo $user_row['studentUniqueId']; ?>&attachmentName=sscmarksheetfile"><h4><span class='glyphicon glyphicon-download text-success' aria-hidden='true'></span></h4></a>
													<?php } else {?>
													<h4><span class='glyphicon glyphicon-download text-danger' aria-hidden='true'></span></h4>
													<?php } ?>
												</td>
												</tr>
												<?php } ?>
												<tr>
													<td width="20%" align="left"><b>Do you reside in college Hostel:</b></td>
													<td width="30%" align="center"><?php echo $user_row['resideInCollege'];?></td>
													
												</tr>
																		
												<tr>
												<?php if($user_row['resideInCollege']=='No' && $user_row['speciallyAllowedFlag']=='N'){?>
													<td width="60%" align="left"><b>Reasonability of Rent Certificate:</b></td>
													<td width="20%" align="center">
														<?php if($user_row['rentReceipt']!='' && $user_row['rentReceipt']!=null)
								{
									echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
								}
								else
								{
									echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
								}?>
													</td>
													<td width="20%" align="center">
														<a href="DBTAttachmentModal.php?type=rentReceipt&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
														<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
														</span></h4>
														</a>
													</td>
													<td width="20%" align="center">
													<?php if($user_row['rentReceipt']!='' && $user_row['rentReceipt']!=null){?>
													<a href="../DBT_HO/DownloadAttachment.php?studentUniqueId=<?php echo $user_row['studentUniqueId']; ?>&attachmentName=rentReceipt"><h4><span class='glyphicon glyphicon-download text-success' aria-hidden='true'></span></h4></a>
													<?php } else {?>
													<h4><span class='glyphicon glyphicon-download text-danger' aria-hidden='true'></span></h4>
													<?php } ?>
												</td>
												<?php }?>
												<?php if($user_row['resideInCollege']=='Yes' && $user_row['speciallyAllowedFlag']=='N'){?>
													<td width="60%" align="left"><b>Hostel Fee Receipt:</b></td>
													<td width="20%" align="center">
														<?php if($user_row['collegehostelReceipt']!='' && $user_row['collegehostelReceipt']!=null)
								{
									echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
								}
								else
								{
									echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
								}?>
													
													</td>
													<td width="20%" align="center">
														<a href="DBTAttachmentModal.php?type=collegehostelReceipt&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
														<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
														</span></h4>
														</a>
													</td>
													<td width="20%" align="center">
													<?php if($user_row['collegehostelReceipt']!='' && $user_row['collegehostelReceipt']!=null){?>
													<a href="../DBT_HO/DownloadAttachment.php?studentUniqueId=<?php echo $user_row['studentUniqueId']; ?>&attachmentName=collegehostelReceipt"><h4><span class='glyphicon glyphicon-download text-success' aria-hidden='true'></span></h4></a>
													<?php } else {?>
													<h4><span class='glyphicon glyphicon-download text-danger' aria-hidden='true'></span></h4>
													<?php } ?>
												</td>
												<?php }?>
												</tr>
												
												<tr>
													<td width="60%" align="left"><b>Book receipts:</b></td>
													<td width="20%" align="center"><?php if($user_row['bookReceipt']!='' && $user_row['bookReceipt']!=null)
								{
									echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
								}
								else
								{
									echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
								}?></td>
													<td width="20%" align="center">
														<a href="DBTAttachmentModal.php?type=bookReceipt&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
														<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
														</span></h4>
														</a>
													</td>
													<td width="20%" align="center">
													<?php if($user_row['bookReceipt']!='' && $user_row['bookReceipt']!=null){?>
													<a href="../DBT_HO/DownloadAttachment.php?studentUniqueId=<?php echo $user_row['studentUniqueId']; ?>&attachmentName=bookReceipt"><h4><span class='glyphicon glyphicon-download text-success' aria-hidden='true'></span></h4></a>
													<?php } else {?>
													<h4><span class='glyphicon glyphicon-download text-danger' aria-hidden='true'></span></h4>
													<?php } ?>
												</td>
												</tr>
												<?php if($user_row['speciallyAllowedFlag']=='N'){ ?>
												<tr>
													<td width="60%" align="left"><b>Other incidental charges Receipt:</b></td>
													<td width="20%" align="center">
													<?php if($user_row['otherIncidentalChargesReceipt']!='' && $user_row['otherIncidentalChargesReceipt']!=null)
								{
									echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
								}
								else
								{
									echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
								}?>
								</td>
													<td width="20%" align="center">
														<a href="DBTAttachmentModal.php?type=otherIncidentalCharges&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
														<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
														</span></h4>
														</a>
													</td>
													<td width="20%" align="center">
													<?php if($user_row['otherIncidentalChargesReceipt']!='' && $user_row['otherIncidentalChargesReceipt']!=null){?>
													<a href="../DBT_HO/DownloadAttachment.php?studentUniqueId=<?php echo $user_row['studentUniqueId']; ?>&attachmentName=otherIncidentalCharges"><h4><span class='glyphicon glyphicon-download text-success' aria-hidden='true'></span></h4></a>
													<?php } else {?>
													<h4><span class='glyphicon glyphicon-download text-danger' aria-hidden='true'></span></h4>
													<?php } ?>
												</td>
												</tr>
												<?php } ?>
												<tr>
													<td width="60%" align="left"><b>Bank Pass Book:</b></td>
													<td width="20%" align="center">
														<?php if($user_row['bankPassBook']!='' && $user_row['bankPassBook']!=null)
								{
									echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
								}
								else
								{
									echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
								}?>
													</td>
													<td width="20%" align="center">
														<a href="DBTAttachmentModal.php?type=bankPassBook&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
														<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
														</span></h4>
														</a>
													</td>
													<td width="20%" align="center">
													<?php if($user_row['bankPassBook']!='' && $user_row['bankPassBook']!=null){?>
													<a href="../DBT_HO/DownloadAttachment.php?studentUniqueId=<?php echo $user_row['studentUniqueId']; ?>&attachmentName=bankPassBook"><h4><span class='glyphicon glyphicon-download text-success' aria-hidden='true'></span></h4></a>
													<?php } else {?>
													<h4><span class='glyphicon glyphicon-download text-danger' aria-hidden='true'></span></h4>
													<?php } ?>
												</td>
												</tr>
												<tr>
													<td width="20%" align="left"><b>Aadhar Card:</b></td>
													<td width="20%" align="center">
													<?php if($user_row['aadharCard']!='' && $user_row['aadharCard']!=null)
								{
									echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
								}
								else
								{
									echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
								}?>
													</td>
													<td width="30%" align="center">
														<a href="DBTAttachmentModal.php?type=aadharCard&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
														<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
														</span></h4>
														</a>
													</td>
													<td width="20%" align="center">
													<?php if($user_row['aadharCard']!='' && $user_row['aadharCard']!=null){?>
													<a href="../DBT_HO/DownloadAttachment.php?studentUniqueId=<?php echo $user_row['studentUniqueId']; ?>&attachmentName=aadharCard"><h4><span class='glyphicon glyphicon-download text-success' aria-hidden='true'></span></h4></a>
													<?php } else {?>
													<h4><span class='glyphicon glyphicon-download text-danger' aria-hidden='true'></span></h4>
													<?php } ?>
												</td>
												</tr>
												
											</table>								
										</div>	
									</div>
									
									<div class="panel panel-default">
										<div class="panel-body table-responsive">
											<table class="table table-bordered table-condensed f11">
												<tr>
													<td colspan="6" align="center" class="danger"><b>Fee Details:</b></td>
												</tr>
												<tr>
												<td align="left"><b>Payment Type:</b></td>
												<td colspan="2" align="left">
												<?php if($user_row['DBTApplicationStatus']=='Submitted' && $user_row['finalApprovedFlag']=='N'){?>
												<select name="paymentType" id="paymentType" class="form-control" required="required">
													<option value=""> - Select Type - </option>
													<option value="Semester" <?php if ($user_row['paymentType']=='Semester'){echo 'selected';}?>>Semester</option>
													<option value="Yearly" <?php if ($user_row['paymentType']=='Yearly'){echo 'selected';}?>>Yearly</option>
												</select>
												<?php }else{echo $user_row['paymentType'];}?>
											</td>
											<td  align="left"><b>Course Duration:</b></td>
											<td colspan="2" align="left">
											<?php if($user_row['approvalFlag']!='Y' && $user_row['DBTApplicationStatus']=='Submitted'){?>
												<input type="text" name="courseDuration" id="courseDuration" class="form-control" value="<?php echo $user_row['courseDuration'];?>" required="required" >
											<?php }else{echo $user_row['courseDuration'];}?></td>
											<div id="courseDurationErrorMsg"></div>
											</tr>
												<tr>
												<td colspan="3" align="center"><b>(A)</b></td>
												<td colspan="3" align="center"><b>(B)</b></td>
											</tr>
											<tr>
												<td align="center"></td>
												<td align="center"><b>Applied</b></td>
												<td align="center"><b>Approved</b></td>
												<td align="center"></td>
												<td align="center"><b>Applied</b></td>
												<td align="center"><b>Approved</b></td>
											</tr>
											<tr>
												<td width="20%" align="left"><b>Tution Fee:</b></td>
												<td width="15%" align="left"><?php echo $user_row['tutionFees'];?></td>
												<td width="15%" align="left" id="tutionFeesError">
												<?php if($user_row['DBTApplicationStatus']=='Submitted' && $user_row['finalApprovedFlag']=='N' && ( $_SESSION['hoId']!='JKFINANCE1' && $_SESSION['hoId']!='JKFINANCE2' && $_SESSION['hoId']!='JKGOV')){?>
												<input class="form-control" name="approvedTutionFees" id="approvedTutionFees" type="number" value="<?php echo $user_row['approvedTutionFees'];?>" required="required" >
												<?php }else{echo $user_row['approvedTutionFees'];}?>
												<div id="tutionFeesErrorMsg"></div>
												</td>
												<td width="20%" align="left"><b>Hostel and Mess Fee:</b></td>
												<td width="15%" align="left"><?php echo $user_row['hostelFees']?></td>
												<td width="15%" align="left">
												<?php if($user_row['DBTApplicationStatus']=='Submitted' && $user_row['finalApprovedFlag']=='N' && ( $_SESSION['hoId']!='JKFINANCE1' && $_SESSION['hoId']!='JKFINANCE2' && $_SESSION['hoId']!='JKGOV')){?>
												<input class="form-control" name="approvedHostelFees" id="approvedHostelFees" type="number" value="<?php echo $user_row['approvedHostelFees'];?>" required="required" >
												<?php }else{echo $user_row['approvedHostelFees'];}?>
												</td>
											</tr>
											<tr>
												<td colspan="3" align="left" rowspan="2"></td>
												
												<td width="20%" align="left"><b>Books & Stationary:</b></td>
												<td width="15%" align="left"><?php echo $user_row['bookNStationaryCharges'];?></td>
												<td width="15%" align="left">
												<?php if($user_row['DBTApplicationStatus']=='Submitted' && $user_row['finalApprovedFlag']=='N' && ( $_SESSION['hoId']!='JKFINANCE1' && $_SESSION['hoId']!='JKFINANCE2' && $_SESSION['hoId']!='JKGOV')){?>
												<input class="form-control" name="approvedBookNStationaryCharges" id="approvedBookNStationaryCharges" type="number" value="<?php echo $user_row['approvedBookNStationaryCharges'];?>" required="required" >
												<?php }else{echo $user_row['approvedBookNStationaryCharges'];}?>
												</td>
											</tr>
											<tr>
											
											<td width="20%" align="left"><b>Other Incidental Charges :</b></td>
												<td width="15%" align="left"><?php echo $user_row['otherCharges'];?></td>
												<td width="15%" align="left">
												<?php if($user_row['DBTApplicationStatus']=='Submitted' && $user_row['finalApprovedFlag']=='N' && ( $_SESSION['hoId']!='JKFINANCE1' && $_SESSION['hoId']!='JKFINANCE2' && $_SESSION['hoId']!='JKGOV')){?>
												<input class="form-control" name="approvedOtherCharges" id="approvedOtherCharges" type="number" value="<?php echo $user_row['approvedOtherCharges'];?>" required="required" >
												<?php }else{echo $user_row['approvedOtherCharges'];}?>
												</td>
											</tr>
											<tr>
											
												<td width="20%" align="left"><b>Total (A) :</b></td>
												<td width="15%" align="left"><?php echo $user_row['tutionFees'];?></td>
												<td width="15%" align="left"><input class="form-control" name="approvedTotalA" id="approvedTotalA" type="number" value="<?php echo $user_row['approvedTutionFees'];?>" required="required"  readonly></td>
												<td width="20%" align="left"><b>Total (B) :</b></td>
												<td width="15%" align="left"><?php echo $user_row['total'];?></td>
												<td width="15%" align="left" id="totalBError"><input class="form-control" name="approvedTotalB" id="approvedTotalB" type="number" max="100000" value="<?php echo $user_row['approvedTotalB'];?>" required="required" readonly><div id="totalBErrorMsg"></div></td>
											</tr>
											<tr>
											
												<td width="20%" align="left"><b>Total :</b></td>
												
												<td colspan="5" align="left"><input class="form-control" name="approvedTotal" id="approvedTotal" type="number" value="<?php echo $user_row['approvedTotal'];?>" required="required"  readonly></td>
												
											</tr>	
												
											</table>								
										</div>	
									</div>
									
									<div class="panel panel-default">
										<div class="panel-body table-responsive">
											<table class="table table-bordered table-condensed f11">
												<tr>
													<td colspan="4" align="center" class="danger"><b>Approval/Rejection:</b></td>
												</tr>
												<tr>
												<td width="20%" ><b>Payment Semester/Year:</b></td>
												<td width="20%" ><select name="newPaymentType" id="newPaymentType" class="form-control" required="required" <?php if($user_row['DBTApplicationStatus']!='Submitted' || ( $_SESSION['hoId']=='JKFINANCE1' || $_SESSION['hoId']=='JKFINANCE2' || $_SESSION['hoId']=='JKGOV')){echo 'readonly';}?>>
												<option value=""> - Select - </option>
												<?php 	
												include('suffix.php');
												$Duration=$user_row['courseDuration'];
												if($dropdown_Row['isXIIMarksheetVerified']!=''){
													if($payment_type_row['PAYMENT_YEAR']!='' && $payment_type_row['Appearance']==1)
													{
														if (strpos($dropdown_Row['isXIIMarksheetVerified'], 'Short') !== false) {
															$value = addOrdinalNumberSuffix($payment_type_row['PAYMENT_YEAR']).' Year Payment';
														}else{
															$value = addOrdinalNumberSuffix($payment_type_row['PAYMENT_YEAR']).' Year Short Payment';
														}
														?>
														<option value="<?php echo $value;?>" <?php if($user_row['isXIIMarksheetVerified']==$value) echo 'selected';?>><?php echo $value; ?></option>
														<?php
													}
													$var=$dropdown_Row['isXIIMarksheetVerified'];
													$var1=$var[0]+1;$dValue=$var1;
												}else{
												$dValue=1;
												} 
												for($d=$dValue;$d<=$Duration;$d++){ 
														$prefix1=addOrdinalNumberSuffix($d).' Year Payment';
														$prefix =addOrdinalNumberSuffix($d).' Year Short Payment';?>
												<option value="<?php echo $prefix1; ?>" <?php if($user_row['isXIIMarksheetVerified']==$prefix1) echo 'selected';?>><?php echo $prefix1; ?></option>
												<option value="<?php echo $prefix; ?>" <?php if($user_row['isXIIMarksheetVerified']==$prefix) echo 'selected';?>><?php echo $prefix; ?></option>
                                                <?php } ?>				
											</select>	</td>
													<td width="20%" align="left"><b>Approval/Rejection Comment:</b></td>
													<td width="40%" align="left" id="commentError">
													
													<textarea class="form-control" name="approvalOrRejectionComment" id="approvalOrRejectionComment" type="text" rows="2" required="required" <?php if($user_row['DBTApplicationStatus']!='Submitted' || ( $_SESSION['hoId']=='JKFINANCE1' || $_SESSION['hoId']=='JKFINANCE2' || $_SESSION['hoId']=='JKGOV')){echo 'readonly';}?>><?php echo $user_row['approvalOrRejectionComment'];?></textarea><div id="commentErrorMsg"></div>
													
													</td>
												</tr>
											</table>
										</div>
									</div>
								</div>
							</div>
							<div  class="col-lg-offset-2 col-lg-2" id="approveOrRejectMessage">
							
						</div>
						
						<?php if($user_row['DBTApplicationStatus']=='Submitted' && $user_row['finalApprovedFlag']!='Y'  && $_SESSION['hoId']!='JKFINANCE1' && $_SESSION['hoId']!='JKFINANCE2' && $_SESSION['hoId']!='JKGOV'){?>
						<div class="col-lg-2">
							<button class="btn btn-success btn-block" id='finalApprove'> Approve</button>
						</div>
						<div class="col-lg-2">
							<a class="btn btn-info btn-block" type="button" id='ApproveAndStopScholarship' data-toggle="modal" data-target="#confirm-complete"> Approve & Complete</a>
						</div>
						<div class="col-lg-2">
							<button class="btn btn-danger btn-block" id='finalReject'>Reject</button>
						</div>		
						<div class="col-lg-2">
							<button class="btn btn-primary btn-block" id='finalSave'>Save</button>
						</div>	
						<?php }?>	
								
								
						</div>
				</form>
						<div class="modal fade bs-example-modal-lg" id="attachmenModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" >
						  <div class="modal-dialog modal-lg" role="document">
							<div class="modal-content">
							  
							</div>
						  </div>
						</div>
			</div><!-- end of current-application -->
		<?php
			include('../db_connect.php');
			// $auditQry = "SELECT * FROM approval_audit WHERE studentUniqueId='".$studentUniqueId."' and DBTApplicationStatus='Approved'";
			// $auditRes = mysqli_query($con, $auditQry);
			
			$auditQry="SELECT * FROM approval_audit WHERE studentUniqueId=? and DBTApplicationStatus='Approved'";
	$stmt5 = mysqli_prepare($con, $auditQry);
	mysqli_stmt_bind_param($stmt5, 'i', $studentUniqueId);
	mysqli_stmt_execute($stmt5);
	$auditRes = mysqli_stmt_get_result($stmt5);
			
		?>
		<div class="tab-pane" id="previous-approval-application">
			<div class="panel-body">
				<div class="col-sm-12" role="complementary">
					<div class="panel panel-default">
						<div class="panel-body table-responsive">
							<table class="table table-bordered table-condensed f11">
								<tr>
									<td colspan="10" align="center" class="danger"><b>Audit Details</b></td>
								</tr>
								<tr>
									<td  align="left" width="20%"><b>Candidate Id</b></td>
									<td  align="left" width="20%"><b>Payment Type</b></td>
									<td  align="left" width="20%"><b>Approved Tution Fees</b></td>
									<td  align="left" width="20%"><b>Approved Hostel Fees</b></td>
									<td  align="left" width="20%"><b>Approved Book and Stationary Charges</b></td>
									<td  align="left" width="20%"><b>Approved Other Charges</b></td>
									<td  align="left" width="20%"><b>Approved Total</b></td>
									<td  align="left" width="20%"><b>Approvel/Rejection Comments</b></td>
									<td  align="left" width="20%"><b>Payment Till</b></td>
									<td  align="left" width="20%"><b>Final Approval Date</b></td>
												
								</tr>
								<?php
									if(mysqli_num_rows($auditRes) > 0){
										while($audit_row = mysqli_fetch_array($auditRes)){
								?>
											<tr>
												<td  align="left"><?php echo $audit_row['studentUniqueId'];?></td>
												<td  align="left"><?php echo $audit_row['paymentType'];?></td>
												<td  align="left"><?php echo $audit_row['approvedTutionFees'];?></td>
												<td  align="left"><?php echo $audit_row['approvedHostelFees'];?></td>
												<td  align="left"><?php echo $audit_row['approvedBookNStationaryCharges'];?></td>
												<td  align="left"><?php echo $audit_row['approvedOtherCharges'];?></td>
												<td  align="left"><?php echo $audit_row['approvedTotal'];?></td>
												<td  align="left"><?php echo $audit_row['approvalOrRejectionComment'];?></td>
												<?php if($audit_row['isXIIMarksheetVerified']==''){?>
												<td  align="left"><?php echo $audit_row['actualPaymentTill'].'-'.$audit_row['paymentType'];?></td>
												<?php } else {?>
											    <td  align="left"><?php echo $audit_row['isXIIMarksheetVerified'];?></td>
												<?php } ?>
												<td  align="left"><?php echo $audit_row['finalApprovalDate'];?></td>
											</tr>
								<?php
										}
									}else{
								?>
										<tr>
											<td colspan="10" align="center"><?php if(mysqli_num_rows($auditRes) == 0){ echo 'No Records Found'; } ?></td>
										</tr>
								<?php
								
									}
								?>
											
							</table>
						</div>
					</div>
				</div>
			</div>
		</div><!--/#audit-application-->
	</div><!-- end of tab-content -->
</div><!-- end of container -->				
<div class="modal fade" id="confirm-complete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-contentt" style="background-color:white">
            <div class="modal-header">
                Confirm Submit
            </div>
            <div class="modal-body">
                <div>Are you sure? you want to <b>Approve and Complete the Scholarship</b> of this Candidate?</div><br>
		        <div><textarea class="form-control"  name="Comments" id="Comments" placeholder="Reason for Approve and Complete the Scholarship" required="required"></textarea></div>				
				<div ><input type="checkbox"  style='margin-top: 20px;' name="declaration" id="declaration" value="Y" required="required"><b><font color="red"> Approve and Complete the Scholarship for this Student.</b></font>			
			    </div>
				
		   </div>
            <div class="modal-footer">
				<div id="ApproveAndCompleteMessage" class="col-md-6" align='left'></div>		
                <div  class="col-md-6">
					<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
					<button href="#" id="ApproveAndCompleteScholarship"  class="btn btn-success success">Submit</button>
				</div>
            </div>
        </div>
    </div>
</div>
	<?php }else{?>
	<br><br><br><h3 align="center">1st Level Approval Of Student is Pending.</h3>
	<?php }?>
	