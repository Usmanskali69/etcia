<?php
session_start();
include('../../db_connect.php');
include('../../../mailer.php');

$candidateID = htmlspecialchars($_GET["candidateID"]);

$studentQuery="SELECT DBTApplicationStatus from students where studentUniqueId=?";
$stmt1 =mysqli_prepare($con, $studentQuery);
mysqli_stmt_bind_param($stmt1, 'i', $candidateID);
mysqli_stmt_execute($stmt1);
$studentResult = mysqli_stmt_get_result($stmt1);

$student_row = mysqli_fetch_array($studentResult, MYSQLI_ASSOC);
	if($student_row['DBTApplicationStatus'] == 'New')
	{	
		$DBTApplicationStatus = 'Approved';
		$paymentFor='4th Year Payment';
		$query="UPDATE students 
					SET DBTApplicationStatus=?,isXIIMarksheetVerified=?
					WHERE
						studentUniqueId=?";
			$stmt1 =mysqli_prepare($con, $query);
			mysqli_stmt_bind_param($stmt1, 'ssi', $DBTApplicationStatus,$paymentFor , $candidateID);
			$result =mysqli_stmt_execute($stmt1);
		
		$actualPaymentTill = 8;
		$query2="UPDATE approval_audit 
					SET actualPaymentTill=?,approvalOrRejectionComment=?,isXIIMarksheetVerified=?
					WHERE
						studentUniqueId=?";
			$stmt2 =mysqli_prepare($con, $query2);
			mysqli_stmt_bind_param($stmt2, 'issi', $actualPaymentTill, $DBTApplicationStatus,$paymentFor, $candidateID);
			$result2 =mysqli_stmt_execute($stmt2);
				
		if($result && $result2)
		{
			echo "success";
		}
		else
		{
			echo "failure";
		}
	}
	else
	{
		echo "processed";
	}

?>