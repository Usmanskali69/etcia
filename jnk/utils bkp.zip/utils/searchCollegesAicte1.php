<!DOCTYPE html>
<html lang="en">
	<head>
		<title>J&K Counselling(College/Course search page)</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<link rel="stylesheet" href="../css/bootstrap.min.css">  
		
		
</head>
	<body>
		<div id="header" class="navbar navbar-default navbar-fixed-top">
			<div class="navbar-header">
				<button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target=".navbar-collapse">
				<i class="fa fa-bars"></i>
				</button>
				<a class="navbar-brand" href="first_page.php">
				<i class="fa fa-folder-open"></i>  J&K Counselling(College/Course search page)
				</a>
				<br/>
				<div style="margin-left:15px;" class="pull-right">
					<i style='color:red;'>
						<b>Engineering/HMCT/Nursing Seats for Open/SC/SEBC caste category candidates are full</b>
					</i>
				</div>
			</div>
			<nav class="collapse navbar-collapse">
				<ul class="nav navbar-nav pull-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<i class="fa fa-user fa-lg"></i> </b></a>
						<ul class="dropdown-menu pull-right">
							<li><a href="#"><i class="fa fa-user fa-fw"></i></a></li>
							<li class="divider"></li>
						</ul>
					</li>
				</ul>
			</nav>
		</div>
		<div class="container-fluid">
		<div class="row" style="margin-top:60px;">
			<div class="col-lg-3" id="left">
				<div class="panel panel-default">
					<div class="panel-body">
						<form role="form">
							<div class="form-group">
						<form class="navbar-form" role="search">
						<!-- <div class="input-group">
							<input type="text" class="form-control" placeholder="Search" name="q">
							<div class="input-group-btn">
							    <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
							</div>
							</div>-->
						<div class="form-group">
						<label for="State">State:</label>
						<?php
						
							include('../db_connect.php'); //Connection to DB using db_connect.php
							
							$result = mysqli_query($con,"SELECT DISTINCT state FROM region where state!='' and state!='Jammu and Kashmir' Order by state"); //Query to retrieve all States
							
							$stateList='<select name="state" id="state" required class="form-control"><option value="">--Select State--</option>';
							
							while($row = mysqli_fetch_array($result)) {
								$stateList.='<option name="'.$row['state'].'" value="'.$row['state'].'">'.$row['state'].'</option>';
							}
							$stateList.='</select>';
							
							echo $stateList;
							?>
						</div>
						<div class="form-group">
						<label for="Category">Stream:</label>
						<select name='Category' class="form-control" id='category'>
						<option value="">--Select Stream--</option>
						<option value="General">General</option> 
						<option value="Engineering and Technology">Engineering</option>
						<option value="HMCT">HMCT</option> 
						<option value="Nursing">Nursing</option>
						</select>
						</div>
						<div class="form-group">
						<label for="Type Of Institute">Type of Institute:</label>
						<select name='Type Of Institute' class="form-control" id='typeOfInstitute'>
						<option value="">--Select Type of Institute--</option>
						<option value="Government">Government</option>
						<option value="Private">Private</option>
						</select>
						</div>
						<div class="form-group">
						<label for="Course">Course:</label>
						<?php
						
							include('../db_connect.php'); //Connection to DB using db_connect.php
							
							$result = mysqli_query($con,"SELECT DISTINCT courseName FROM courses where courseName!='' Order by courseName"); //Query to retrieve all States
							
							$courseList='<div id="coursesdiv"><select name="courseName" id="courseName" class="form-control"><option value="">--Select Courses--</option>';
							
							while($row = mysqli_fetch_array($result)) {
								$courseList.='<option name="'.$row['courseName'].'" value="'.$row['courseName'].'">'.$row['courseName'].'</option>';
							}
							$courseList.='</select></div>';
							
							echo $courseList;
							?>
						</div>
						<!--<div class="form-group">
						<label for="Seat Category">Seat Category:</label>
						<select name='Seat Category' class="form-control" value='Both' id='seatcategory'>
						<option value="">Both</option>
						<option value="Open">Open</option> 
						<option value="Reserved">Reserved</option>
						</select>
						</div>-->
						<div class="form-group">
						<label for="Women Institute">Women Institute:</label>
						<select name='Women Institute' class="form-control" id='womenInstitute'>
						<option value="">--Select Yes/No--</option>
						<option value="No"> No</option>
						<option value="Yes"> Yes</option>
						</select>
						</div>
						<button type="submit" class="btn btn-primary" id="search" style="width:100%">Search</button>
						</form>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-9 pre-scrollable" style="height: auto;max-height: 600px" id="institute" >
			

			</div>
		</div>
		<div class="row">
			<div class="modal fade bs-example-modal-lg" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog modal-lg">
					<div class="modal-content">
					</div>
				</div>
			</div>
		</div>
		
		<script type="text/javascript" src="../js/jquery.js"></script>
		<script type="text/javascript" src="../js/bootstrap.min.js"></script>
		<script type="text/javascript" src="../js/bootstrap-table.js"></script>
		<script type="text/javascript" src="js/custom/searchCollegesAicte1.js"></script>

		
		

		
	</body>
</html>