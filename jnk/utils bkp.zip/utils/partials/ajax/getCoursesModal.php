<?php
include('../../../db_connect.php');
$coursesId  = $_GET['courseid'];




echo '<div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Courses List</h4>
      </div>
      
        <div class="modal-body">';
$instsql    = "SELECT name, state, typeOfInstitute, district FROM colleges where collegeUniqueId = '$coursesId'";
$instresult = $con->query($instsql);
if ($instresult->num_rows > 0) {
    echo "<table>";
    while ($row = $instresult->fetch_assoc()) 
	{
		echo "<div class='col-md-2'><b>Institute Name:</b> </div><div class='col-md-10'>" . $row['name'] . "</div><hr>";
		echo "<div class='col-md-2'><b>Institute Type:</b> </div><div class='col-md-2' style='text-align:left'>" . $row['typeOfInstitute'] . "</div><div class='col-md-1'><b>State: </b></div><div class='col-md-2'>" . $row['state'] . "</div><div class='col-md-1'><b>District:</b> </div><div class='col-md-2'>" . $row['district']." </div>"; 
    }
    echo "</table>";
    echo "<hr>";
}
$sql        = "SELECT courseUniqueId, courseName, category, university FROM courses where collegeUniqueId = '$coursesId' and Seats > 0";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    echo "<table class='table table-bordered'>";
    echo "<tr><th>Course ID</th><th>Course Name</th><th>Stream</th><th>Affilating University</th></tr>";
    // output data of each row
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["courseUniqueId"] . "</td><td>" . $row["courseName"] . "</td><td>" . $row["category"] . "</td><td>" . $row["university"] . "</td></tr>";
    }
    echo "</table>";
    
} else {
    echo "0 results";
}
echo '</div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
      </div>';
$con->close();
?> 
