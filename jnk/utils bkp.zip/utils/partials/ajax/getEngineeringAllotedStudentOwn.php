<?php
	
	include("../../../db_connect.php");
	
	$year = intval (substr(date ("Y"),2,2))+1;
	$currentYear = date("Y");
	$yearOfCounselling = $currentYear.'-'.$year;
	
	$otherQuery = "SELECT * FROM others WHERE id=1";
	
	$result = mysqli_query($con,$otherQuery);
	
	$otherRow =mysqli_fetch_array($result);
	
	if($otherRow['isReallocationStarted']=='No'){
		$applicationStatus = 'Seat Allocated - Own';
	}else{
		$applicationStatus = 'Seat Allocated - RC';
	}
	
	$query = "SELECT 
				studentUniqueId,name as studentName,studentRank,allotmentCategory,counsellingCentre, streamAppliedfor, applicationStatus
			FROM
				students s
			WHERE
				s.applicationStatus = '".$applicationStatus."'
				AND	s.streamAllottedIn = 'Engineering'
				AND yearOfCounselling='$yearOfCounselling'
			ORDER BY s.allotmentDate DESC
			LIMIT 5";
				
	$result = mysqli_query($con,$query);
	
	if(mysqli_num_rows($result) != 0){
		$table = '	<h4><font color="#6D7B8D">Through Own Admission</font></h4><br>
		               <table class="table table-hover table-bordered">
		                 <thead class="btn-primary">
						<tr>
							<th width="5%">Candidate Rank</th>
							<th width="10%">Candidate Name</th>						
							<th width="10%">Stream Applied for</th>
							<th width="10%">Allotment Category</th>
							<th width="05%">Counselling Centre</th>	
							<th width="10%">Status</th>
						</tr>
						</thead>';

		
		while ($row = mysqli_fetch_array($result)){
		if($row["allotmentCategory"]=="Socially and Economically Backward Classes (SEBC)"){
				$allotmentCategory='SEBC';			
			}
			else
			{
				$allotmentCategory=$row["allotmentCategory"];
			}
		$table .= '	<tr>
						<td>'.$row["studentRank"].'</td>
						<td>'.ucwords(strtolower($row["studentName"])).'</td>					
						<td>'.$row["streamAppliedfor"].'</td>					
						<td>'.$allotmentCategory.'</td>
						<td>'.$row["counsellingCentre"].'</td>
						<td>'.$row["applicationStatus"].'</td>
					</tr>';
		}
		
		$table.='</table>';
		
		echo $table;
	}else{
		echo '<h4 style="color: red;">No Student allotted in Engineering Category through Own Admission</h4>';
	}
?>