<?php

	session_start();
	if(isset($_SESSION['hoId']) && !empty($_SESSION['hoId']))
{
	include("../../../db_connect.php");
	
	$studentQuery	=	"SELECT DBTApplicationSubmittedDate,studentUniqueId,studentRank,name,DBTApplicationStatus,collegeUniqueId,streamAllottedIn,otherStudentStreamAppliedFor FROM students where DBTApplicationFormSubmitted='Y' and DBTApplicationStatus='Submitted' and admissionThroughCCP='Yes' and yearOfCounselling='2015-16' and  approvalFlag='N'
";
	
	
	$result = mysqli_query($con, $studentQuery) or die("Could not execute query");
	$studentData=array();
	
	while($row = mysqli_fetch_array($result)){
		$row_array['Submission_Date'] = $row['DBTApplicationSubmittedDate'];
		$row_array['Candidate_Id'] = $row['studentUniqueId'];
		$row_array['Candidate_Rank'] = $row['studentRank'];
		$row_array['Candidate_Name'] = $row['name'];
		$row_array['Candidate_Status'] = $row['DBTApplicationStatus'];
		if($row['collegeUniqueId']!='' && $row['collegeUniqueId']!=null){
		if($row['streamAllottedIn']=='Engineering and Technology')
		{
		$row['streamAllottedIn']='Engineering';
		}
		$row_array['Candidate_Category'] = $row['streamAllottedIn'];
	}else
		{
		if($row['otherStudentStreamAppliedFor']=='Engineering and Technology')
		{
		$row['otherStudentStreamAppliedFor']='Engineering';
		}
		$row_array['Candidate_Category'] = $row['otherStudentStreamAppliedFor'];
		}
	// $otherQuery	=	"select otherStudentCollegeName,OtherStudentCourseName, approvedTutionFees,approvedHostelFees, approvedBookNStationaryCharges, approvedOtherCharges,approvedTotal FROM students where studentUniqueId='".$row['studentUniqueId']."'";	
	
	// $otherresult = mysqli_query($con, $otherQuery) or die("Could not execute query");
	// $other_row=mysqli_fetch_array($otherresult);
	
	
	$otherQuery="select otherStudentCollegeName,OtherStudentCourseName, approvedTutionFees,approvedHostelFees, approvedBookNStationaryCharges, approvedOtherCharges,approvedTotal FROM students where studentUniqueId=? ";
		$stmt1 = mysqli_prepare($con, $otherQuery);
		mysqli_stmt_bind_param($stmt1, 'i',$row['studentUniqueId']);
		mysqli_stmt_execute($stmt1) or die("Query Failed1");
		$otherresult = mysqli_stmt_get_result($stmt1);
		$other_row = mysqli_fetch_array($otherresult, MYSQLI_ASSOC);
	
		if($row['admissionThroughCCP']=='Yes')
		{
		if($row['collegeUniqueId']!='' && $row['collegeUniqueId']!=null){
		
		// $collegeQuery	= "select * FROM colleges where collegeUniqueId='".$row['collegeUniqueId']."'";	
	
	// $collegeresult = mysqli_query($con, $collegeQuery) or die("Could not execute query");
	// $college_row=mysqli_fetch_array($collegeresult);

      $collegeQuery="select * FROM colleges where collegeUniqueId=? ";	
 		$stmt2 = mysqli_prepare($con, $collegeQuery);
		mysqli_stmt_bind_param($stmt2, 'i',$row['collegeUniqueId']);
		mysqli_stmt_execute($stmt2) or die("Query Failed1");
		$collegeresult = mysqli_stmt_get_result($stmt2);
		$college_row = mysqli_fetch_array($collegeresult, MYSQLI_ASSOC);
		
		$row_array['College_Name'] = $college_row['name'];		
		
	}else
		{
		$row_array['College_Name'] = $other_row['otherStudentCollegeName'];
		
		}
		}
		if($row['admissionThroughCCP']=='No')
		{
		
		$row_array['College_Name'] = $other_row['otherStudentCollegeName'];
		
		}
		array_push($studentData,$row_array);
	}
	
	echo json_encode($studentData);
	
	
	}else{
		header('Location: ../../../../jnkqa/DBT_HO/login.php');
	}
?>