$(document).ready(function() {

    var i = 0;
	

	$('#seatcategory').hide();
	$('#seatcategorylabel').hide();
	
    $.ajaxSetup({
        cache: false
    });
    setInterval(function() {

			console.log(i);
        if (i != 0) {
            $('#institute').load('../../utils/partials/ajax/getInstitutes.php?state=' + encodeURIComponent($('#state').val()) + '&courseName=' + encodeURIComponent($('#courseName').val()) + '&category=' + encodeURIComponent($('#category').val()) + '&typeOfInstitute=' + encodeURIComponent($('#typeOfInstitute').val()) + '&seatcategory=' + encodeURIComponent($('#seatcategory').val()) + '&isWomenInstitute=' + encodeURIComponent($('#womenInstitute').val())); //console.log("if"+i++);
        }
    }, 5000);

    $('#search').click(function(e) {
        e.preventDefault();
       i=0;
            $.ajax({
                type: 'POST',
                url: '../../utils/partials/ajax/getInstitutes.php?state=' + $('#state').val() + '&courseName=' + $('#courseName').val() + '&category=' + $('#category').val() + '&typeOfInstitute=' + $('#typeOfInstitute').val() + '&seatcategory=' + $('#seatcategory').val() + '&isWomenInstitute=' + $('#womenInstitute').val(),
                success: function(institute) {

                    $('#institute').html(institute); //console.log("else"+i);
					i++;

                }


            });

        
    });
	
	$('#refreshWindow').click(function(e) {
	i=0;
	location.reload(true);
	});



    $(document).on('hidden.bs.modal', function(e) {
        var target = $(e.target);
        target.removeData('bs.modal')
            .find(".modal-content").html('');
    });

	$("#candidateIdSearch").click(function(e) {
        e.preventDefault();
        var CandidateId = $("#CandidateId").val();
		console.log(CandidateId);
		var postParam='candidateId=' + CandidateId;
        $.ajax({
            type: "GET",
            url: "../../utils/partials/ajax/getStudentDetailsForSearchPage.php",
            data: postParam,
            cache: false,
            success: function(html) {
			var formattedDate=new Date();
var d = formattedDate.getDate();
var m =  formattedDate.getMonth();
m += 1;
var y = formattedDate.getFullYear();
var hr=formattedDate.getHours();
var mi=formattedDate.getMinutes()+15;
var ss=formattedDate.getSeconds();
if(mi>60){

mi=mi-60;
hr=hr+1;
}
if(mi<10)
{
mi="0"+mi;
}
var date=y+"/"+m+"/"+d+" "+hr+":"+mi+":"+ss;

	
	console.log(date);
  

			var reply = html.replace(/\s+/, ""); 
				console.log(html);
				//console.log(html);
				if(reply =='Open')
				{
				$("#counter")
 .countdown(date, function(event) {
    $(this).text(
      event.strftime('%M:%S')
    );
  });
  $("#counter").on('finish.countdown', function(event){location.reload();});
				$("#CandidateId").prop('disabled', true);
				$("#state").prop('disabled', false);
				$("#category").prop('disabled', false);
				$("#typeOfInstitute").prop('disabled', false);
				$("#courseName").prop('disabled', false);
				$("#search").prop('disabled', false);
				$("#CandidateError").html('');
				$("#seatcategory").append("<option value='Open' selected>Open</option>");
				}
				else if(reply =='Reserve')
				{
				$("#counter")
 .countdown(date, function(event) {
    $(this).text(
      event.strftime('%M:%S')
    );
  });
  $("#counter").on('finish.countdown', function(event){location.reload();});
				$("#CandidateId").prop('disabled', true);
				$("#state").prop('disabled', false);
				$("#category").prop('disabled', false);
				$("#typeOfInstitute").prop('disabled', false);
				$("#courseName").prop('disabled', false);
				$("#search").prop('disabled', false);
				$("#CandidateError").html('');
				$("#seatcategory").append("<option value='Reserved' selected>Reserve</option>");
				}
				else if(reply =='SeatsFull')
				{
				$("#counter")
 .countdown(date, function(event) {
    $(this).text(
      event.strftime('%M:%S')
    );
  });
  $("#counter").on('finish.countdown', function(event){location.reload();});
				//$("#seatcategory").append("<option value='SeatsFull' selected>Seats are Full</option>");
				$("#CandidateError").html('');
				$("#institute").html("No more seats available");
				}
				else
				{	
				$("#state").prop('disabled', true);
				$("#category").prop('disabled', true);
				$("#typeOfInstitute").prop('disabled', true);
				$("#courseName").prop('disabled', true);
				$("#womenInstitute").prop('disabled', true);
				$("#search").prop('disabled', true);
				$("#womenInstitute").html("<option value='' selected>--Select Yes/No--</option>");
				$("#seatcategory").html("<option value='' selected>--Select seat category--</option>");
					$("#CandidateError").html("<label for='Invalid' style='color:Red;'>Invalid Candidate Id</label>");
				}
            }
        });
		$.ajax({
            type: "GET",
            url: "../../utils/partials/ajax/getStudentNameAndGender.php",
            data: postParam,
            cache: false,
			
            success: function(html) {
			var html = html.replace(/\s+/, "");
			//console.log(html);
			if(html=='Invalid')
			{
				$("#state").prop('disabled', true);
				$("#category").prop('disabled', true);
				$("#typeOfInstitute").prop('disabled', true);
				$("#courseName").prop('disabled', true);
				$("#womenInstitute").prop('disabled', true);
				$("#search").prop('disabled', true);
				$("#womenInstitute").html("<option value='' selected>--Select Yes/No--</option>");
				$("#seatcategory").html("<option value='' selected>--Select seat category--</option>");
				$("#CandidateError").html("<label for='Invalid' style='color:Red;'>Invalid Candidate Id</label>");
			}
			else
			{
				
				var reply = html.split(','); 
				console.log(reply);
				$("#candidateName").html("<label for='Name'>Candidate Name :</label>"+" "+reply[0]);
				if(reply[1]=='Male')
				{
				$("#womenInstitute").empty();
				$("#womenInstitute").html("<option value='No' selected> No</option>");
				$("#womenInstitute").prop('disabled', true);
				}
				if(reply[1]=='Female')
				{
				$("#womenInstitute").empty();
				$("#womenInstitute").append("<option value=''>--Select Yes/No--</option>");
				$("#womenInstitute").append("<option value='Yes'>Yes</option>");
				$("#womenInstitute").prop('disabled', false);
				}
				if(reply[2]=='EngFull')
				{
				$('#collegeStatus').html("<i style='color:red;'><b>"+reply[3]+"  Engineering seats are full</b></i>");
				$("#category").empty();
				$("#category").append("<option value=''>--Select Stream--</option>");
				$("#category").append("<option value='General'>General</option>");
				
				}
				if(reply[2]=='GenFull')
				{			
					$('#collegeStatus').html("<i style='color:red;'><b>"+reply[3]+"  General seats are full</b></i>");
					$("#category").empty();
					$("#category").append("<option value=''>--Select Stream--</option>");
					if(reply[2]=='GenFull' && reply[4]=='Science')
					{					
						$("#category").append("<option value='Engineering and Technology'>Engineering</option>");
						$("#category").append("<option value='HMCT'>HMCT</option>");
						$("#category").append("<option value='Nursing'>Nursing</option>");
					}
				}
				if(reply[2]=='')
				{
				$("#category").empty();
				$("#category").append("<option value=''>--Select Stream--</option>");
				$("#category").append("<option value='General'>General</option>");
				$("#category").append("<option value='Engineering and Technology'>Engineering</option>");
				$("#category").append("<option value='HMCT'>HMCT</option>");
				$("#category").append("<option value='Nursing'>Nursing</option>");			
				}	
            }}
        });
    });
	
    $("#category").change(function() {
        i=0;
        var stateSelected = $("#state option:selected").val();
        var categorySelected = $("#category option:selected").val();
        var typeOfInstituteSelected = $("#typeOfInstitute option:selected").val();
		var womenInstituteSelected = $("#womenInstitute option:selected").val();
		var seatcategorySelected = $("#seatcategory option:selected").val();
		var postParam = 'state=' + stateSelected + '&category=' + categorySelected + '&typeOfInstitute=' + typeOfInstituteSelected + '&isWomenInstitute=' + womenInstituteSelected + '&seatcategory=' + seatcategorySelected;
        //console.log(postParam);
        $.ajax({
            type: "GET",
            url: "../../utils/partials/ajax/getCourseDetails.php",
            data: postParam,
            cache: false,
            success: function(html) {
                $("#coursesdiv").html(html);
            }
        });
    });
    $("#category").change(function() {
        i=0;
        var categorySelected = $("#category option:selected").val();

        if (categorySelected == 'General') {
			$("#typeOfInstitute").val('');
            $("#typeOfInstitute").attr('disabled', true);
        } else {
            $("#typeOfInstitute").attr('disabled', false);
        }
    });
    $("#state").change(function() {
		i=0;
        var stateSelected = $("#state option:selected").val();
        var categorySelected = $("#category option:selected").val();
        var typeOfInstituteSelected = $("#typeOfInstitute option:selected").val();
		var womenInstituteSelected = $("#womenInstitute option:selected").val();
		var seatcategorySelected = $("#seatcategory option:selected").val();
		var postParam = 'state=' + stateSelected + '&category=' + categorySelected + '&typeOfInstitute=' + typeOfInstituteSelected + '&isWomenInstitute=' + womenInstituteSelected + '&seatcategory=' + seatcategorySelected;
       // console.log(postParam);
        $.ajax({
            type: "GET",
            url: "../../utils/partials/ajax/getCourseDetails.php",
            data: postParam,
            cache: false,
            success: function(html) {
				//console.log(html+"abc");
                $("#coursesdiv").html(html);
            }
        });
    });
    $("#typeOfInstitute").change(function() {

        i=0;
        var stateSelected = $("#state option:selected").val();
        var categorySelected = $("#category option:selected").val();
        var typeOfInstituteSelected = $("#typeOfInstitute option:selected").val();
		var womenInstituteSelected = $("#womenInstitute option:selected").val();
		var seatcategorySelected = $("#seatcategory option:selected").val();
		var postParam = 'state=' + stateSelected + '&category=' + categorySelected + '&typeOfInstitute=' + typeOfInstituteSelected + '&isWomenInstitute=' + womenInstituteSelected + '&seatcategory=' + seatcategorySelected;
        //console.log(postParam);
        $.ajax({
            type: "GET",
            url: "../../utils/partials/ajax/getCourseDetails.php",
            data: postParam,
            cache: false,
            success: function(html) {
                $("#coursesdiv").html(html);
            }
        });

    });
    $("#courseName").change(function() {
        i=0;
    });
    $("#womenInstitute").change(function() {
        i=0;
		var stateSelected = $("#state option:selected").val();
        var categorySelected = $("#category option:selected").val();
        var typeOfInstituteSelected = $("#typeOfInstitute option:selected").val();
		var womenInstituteSelected = $("#womenInstitute option:selected").val();
		var seatcategorySelected = $("#seatcategory option:selected").val();
		var postParam = 'state=' + stateSelected + '&category=' + categorySelected + '&typeOfInstitute=' + typeOfInstituteSelected + '&isWomenInstitute=' + womenInstituteSelected + '&seatcategory=' + seatcategorySelected;
        //console.log(postParam);
        $.ajax({
            type: "GET",
            url: "../../utils/partials/ajax/getCourseDetails.php",
            data: postParam,
            cache: false,
            success: function(html) {
                $("#coursesdiv").html(html);
            }
        });
    });
    $("#seatcategory").change(function() {
        i=0;
		var stateSelected = $("#state option:selected").val();
        var categorySelected = $("#category option:selected").val();
        var typeOfInstituteSelected = $("#typeOfInstitute option:selected").val();
		var womenInstituteSelected = $("#womenInstitute option:selected").val();
		var seatcategorySelected = $("#seatcategory option:selected").val();
		var postParam = 'state=' + stateSelected + '&category=' + categorySelected + '&typeOfInstitute=' + typeOfInstituteSelected + '&isWomenInstitute=' + womenInstituteSelected + '&seatcategory=' + seatcategorySelected;
        //console.log(postParam);
        $.ajax({
            type: "GET",
            url: "../../utils/partials/ajax/getCourseDetails.php",
            data: postParam,
            cache: false,
            success: function(html) {
                $("#coursesdiv").html(html);
            }
        });
    });
});