$(document).ready(function(){	
	if($('#grievanceAssignedTo').val() == ''){
		$('#addGrievanceAttachment').hide();
	}
	else{
		$('#SubmitButton').hide();
		$('#addGrievanceAttachment').show();
	}
});
 
  $("#uploadFile").on('click',function(e){ 
    	$('#grievanceAttachment').validate({
		ignore: [],
		rules: {
			attachmentType: {
				minlength: 2,
				maxlength: 50,				
				required: true
			}
			},			
		highlight: function(element) {
			$(element).closest('.form-group').addClass('has-error');
			console.log('validation');
		},
		unhighlight: function(element) {
			$(element).closest('.form-group').removeClass('has-error');
		},
		errorElement: 'span',
		errorClass: 'help-block',
		errorPlacement: function(error, element) 
		{
			if(element.parent('.input-group').length) 
				{
					error.appendTo(element.parent());
				} 			
		}
		
	});
  });
  $("#SubmitButton , #FinalSubmitButton").on('click',function(e){
  	$('#submiteGrievanceForm').validate({
		ignore: [],
		rules: {
			grievanceSubject: {
				minlength: 10,
				maxlength: 100,				
				required: true
			},					
			grievanceDescription: {
				minlength: 10,
				maxlength: 600,
				required: true
			},
			grievanceAssignedTo: {							
				required: true
			},
			},			
		highlight: function(element) {
			$(element).closest('.form-group').addClass('has-error');
			console.log('validation');
		},
		unhighlight: function(element) {
			$(element).closest('.form-group').removeClass('has-error');
		},
		errorElement: 'span',
		errorClass: 'help-block',
		errorPlacement: function(error, element) 
		{
			if(element.parent('.input-group').length) 
				{
				error.insertAfter(element.parent());
				} 
			else  if ( element.is(":radio") ) 
				{
					error.appendTo( element.parents('.form-group') );
				}
			else 
				{
				error.insertAfter(element);
				}
		}
		
	});
	if ($("#submiteGrievanceForm").valid()) {
	event.preventDefault();
	//console.log($("#submiteGrievanceForm").serialize());
	$.ajax({
            url: "operations/createNewGrievanceDBT.php", // Url to which the request is send
            type: "POST", // Type of request to be send, called as method
            data: $("#submiteGrievanceForm").serialize(),
            beforeSend: function()
				{
					$('#SubmitButton').text('Saving..');
					$('#SubmitButton').prop('disabled', true);
					
				}, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            success: function(data) // A function to be called if request succeeds
                {
                    console.log(data);
					var reply = data.replace(/\s+/, ""); 
					if(reply.trim() =='Success'){
						$('#SubmitButton').text('Save');
						$('#SubmitButton').prop('disabled', false);
						$('#SubmitButton').hide();						
						$('#addGrievanceAttachment').show();
						
					}
                }
        });
	}
});
 $("#FinalSubmitButton").on('click',function(e){
  event.preventDefault();
	if ($("#submiteGrievanceForm").valid()) {
	  $.ajax({
				url: "operations/createNewGrievanceDBT.php", // Url to which the request is send
				type: "POST", // Type of request to be send, called as method
				data: $("#submiteGrievanceForm").serialize(),
				beforeSend: function()
					{
						$('#SubmitButton').text('Saving..');
						$('#SubmitButton').prop('disabled', true);
					}, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
				success: function(data) // A function to be called if request succeeds
					{
						console.log(data);
						var reply = data.replace(/\s+/, ""); 
						if(reply.trim() =='Success'){
							$('#grievanceMessage').html("Grievance with ID "+$('#grievanceId').val()+" created successfully");
							$('#confirmSubmit').modal('show'); 
							setTimeout(function(){
								$('#confirmSubmit').modal('hide');
								window.location.href= 'index.php?q=grievances';
								
								},1500); 
							
						}
					}
			});
	}
  });
  
  
/*   $('#confirmDeleteGrievance').on('click',function(e){
console.log('delete functiom');

$.('#content').html('Changes will not be save if you go back. Do you want to proceed?');
$('#confirmDelete').modal('show');
/*$.('#footer').html('<button type="submit" class="btn btn-success" id="Back" onclick="deleteGrievance()">Yes</button><button type="button" class="btn btn-default" data-dismiss="modal">Close</button>');


}); */


 $('#grievanceAttachmentpdffile').change(function() {
        $('#grievanceAttachmentsubfile').val($(this).val());
		
    });

	
   $('#grievanceAttachment').submit(function(event) {
		
		event.preventDefault();
		$('#grievanceAttachment').validate({
		ignore: [],
		rules: {
			attachmentType: {							
				required: true
			},			
			},			
		highlight: function(element) {
			$(element).closest('.-group').addClass('has-error');
			console.log('validation');
		},
		unhighlight: function(element) {
			$(element).closest('.form-group').removeClass('has-error');
		},
		errorElement: 'span',
		errorClass: 'help-block',
		errorPlacement: function(error, element) 
		{
			if(element.parent('.input-group').length) 
				{
				error.insertAfter(element.parent());
				} 
			else  if ( element.is(":radio") ) 
				{
					error.appendTo( element.parents('.form-group') );
				}
			else 
				{
				error.insertAfter(element);
				}
		}
		
	});
        $.ajax({
            url: "grievanceAttachmentDBT.php", // Url to which the request is send
            type: "POST", // Type of request to be send, called as method
            data: new FormData(this),
            beforeSend: function()
				{
					$('#attachmentsErrorMessage').html('');
					$('#uploadFile').text('Uploading..');
					$('#uploadFile').prop('disabled', true);
				}, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false, // The content type used when sending data to the server.
            cache: false, // To unable request pages to be cached
            processData: false, // To send DOMDocument or non processed data file it is set to false
            success: function(data) // A function to be called if request succeeds
                {
					console.log(data);
					var reply = data.replace(/\s+/, ""); 
                    $('#uploadFile').text('Upload');
                    $('#uploadFile').prop('disabled', false);
					$('#attachmentType').val('');
					if(reply.trim()=='1')
					{
						var Id="grievanceId="+$("#grievanceId").val();
						
						$.ajax({
						url: "attachmentDetailsDBT.php", // Url to which the request is send
						type: "GET", // Type of request to be send, called as method
						data: Id,
						success: function(data) // A function to be called if request succeeds
								{
								$("#attachmentsTable").html(data);
								}
						});
                    }
					else{
						$('#attachmentsErrorMessage').html('<b>Please upload .jpg/.jpeg/.png/.pdf of maximum 1Mb size</b>').css("color", "#ff0000");
					}
                    

                }
        });
        // stop the form from submitting the normal way and refreshing the page
        
    });
	$(document).on('hidden.bs.modal', function(e) {
		
			var target = $(e.target);
			console.log(target[0].id);
			if(target[0].id !='confirmDelete')
			{
				target.removeData('bs.modal')
				.find(".modal-content").html('');
				$('#attachmentsTable').load('attachmentDetailsDBT.php?grievanceId='+$("#grievanceId").val());
			}
    });