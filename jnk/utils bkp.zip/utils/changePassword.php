<!DOCTYPE html>
<html lang="en">

	<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="SUVOJIT AOWN/ VANASHREE PUROHIT/ LAKSHMI GOPAKUMAR">

		<title>J&K Scholarship</title>

		<!-- Bootstrap Core CSS -->
		<link href="../css/bootstrap.min.css" rel="stylesheet">

		<!-- Custom CSS -->
		<link href="../css/main.css" rel="stylesheet">

		<!-- Custom Fonts -->
		<link href="../font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
		
	</head>

	<body>
		<div id="header" class="navbar navbar-default navbar-fixed-top">
			<div class="navbar-header">
				<button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target=".navbar-collapse">
					<i class="fa fa-bars"></i>
				</button>
				<a class="navbar-brand" href="index.php">
					<i class="fa fa-folder-open"></i>  J&K Scholarships
				</a>
			</div>
			<nav class="collapse navbar-collapse">
				
				<ul class="nav navbar-nav pull-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
							<i class="fa fa-user fa-lg"></i> <?php echo $_SESSION['loginName']; ?><b class="caret"></b></a>
						<ul class="dropdown-menu pull-right">
							<li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a></li>
							<li class="divider"></li>
							<li><a href="../session/auth.php?do=logout"><i class="fa fa-power-off"></i> Logout</a></li>
						</ul>
					</li>
				</ul>
			</nav>
		</div>
		<div class="container" style="margin-top:80px;">
			
			<div class="col-lg-offset-4 col-lg-4">

				<div class="login-panel panel panel-default">
					<div class="panel-heading">
						<h3 class="panel-title">Change Credentials</h3>
						<h6><b>Note:</b> You need to change the username (email-Id) and password for the first time.Kindly use the changed password for further logging into the application.</h6>
					</div>
					<div class="panel-body ">
						<div id="successMessage">
						
							<!--<div class="alert alert-danger">
								<cite>**Incorrect Username or Password**</cite>
							</div>-->
							<div class="col-lg-12">
								<form id="changePasswordForm" role="form" method="post">
										
										<div class="form-group" style="padding-left:0px;" id="email">
											<input class="form-control" id="changedLoginName" name="changedLoginName" placeholder="Email Id" type="text" autofocus  required="required" onCopy="return false" onDrag="return false" onDrop="return false" onPaste="return false"/>
											<div id="emailError"></div>
										</div>
										<div class="form-group" style="padding-left:0px;" id="email2">
											<input class="form-control" id="confirmLoginName" name="confirmLoginName" placeholder="Confirm Email Id" type="text" autofocus  required="required" onCopy="return false" onDrag="return false" onDrop="return false" onPaste="return false"/>
											<div id="emailError2"></div>
										</div>
										<div class="form-group" >
											<input class="form-control"  id="changedPassword" name="changedPassword" placeholder="Password" type="password"  required="required" onCopy="return false" onDrag="return false" onDrop="return false" onPaste="return false">
										</div>
										<div class="form-group" id="pwd" >
											<input class="form-control" id="confirmPassword" name="confirmPassword" placeholder="Confirm Password" type="password"  required="required" onCopy="return false" onDrag="return false" onDrop="return false" onPaste="return false">
											<div id="confirmPasswordError"></div>
										</div>
										<div class="form-group" id="emailErrorMessage">
											
										</div>
										<!-- Change this to a button or input when using this as a form -->
										<button class="btn btn-lg btn-success btn-block" id="changePasswordButton">Save Changes</button>
																
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>

		</div>
		
		<script src="../js/jquery.js"></script>
		<script src="../js/bootstrap.min.js"></script>
		<script type="text/javascript" src="../js/jquery.validate.min.js"></script>
		<script src="js/custom/validateChangedPassword.js"></script>
		<script>
		
		function validateEmail(sEmail) {
			var filter = /^([a-zA-Z0-9_\-\&\*\+='/\{\}~][a-zA-Z0-9_\-\.&\*\+='/\{\}~]*)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
			console.log(filter.test(sEmail));
			if (filter.test(sEmail)) {
				return true;
			} else {
				return false;
			}
		}
		
		function confirmPassword() {
			
			if ($('#changedPassword').val() == $('#confirmPassword').val()) {
				return true;
			} else {
				$("#pwd").addClass("has-error");
				$("#confirmPasswordError").html("Both Passwords should match").css("color", "#a94442");
				
				return false;
			}
		}
		
		function confirmEmail() {
			
					console.log("Focusout");
					var email = $('#changedLoginName').val();
					var confirmEmail = $('#confirmLoginName').val();
					if(email !== confirmEmail){
						$("#email2").addClass("has-error");
						$("#emailError2").html("Email and Confirm Email should match").css("color", "#a94442");
						return false;
					}else{
						$("#email2").removeClass("has-error");
						$("#emailError2").html("");
						return true;
					}
				
			}
			
		$(document).ready(function() {
		
			$("#changedLoginName").change(function() {
				var sEmail = $("#changedLoginName").val();
				
				if (sEmail != '') {
					if (validateEmail(sEmail)) {
						$("#email").removeClass("has-error");
						$("#emailError").html("");
					} else {
						$("#email").addClass("has-error");
						$("#emailError").html("Invalid Email Id").css("color", "#a94442");


					}
				} else {
					$("#email").removeClass("has-error");
					$("#emailError").html("");

				}

			});
			
			$("#changedLoginName").focusout(function(){
					if($('#confirmLoginName').val() != ''){
						var email = $('#changedLoginName').val();
						var confirmEmail = $('#confirmLoginName').val();
						if(email !== confirmEmail){
							$("#email2").addClass("has-error");
							$("#emailError2").html("Email and Confirm Email should match").css("color", "#a94442");
						}else{
							$("#email2").removeClass("has-error");
							$("#emailError2").html("");
						}
					}
			});
			
			$("#confirmLoginName").focusout(function(){
					console.log("Focusout");
					var email = $('#changedLoginName').val();
					var confirmEmail = $('#confirmLoginName').val();
					if(email !== confirmEmail){
						$("#email2").addClass("has-error");
						$("#emailError2").html("Email and Confirm Email should match").css("color", "#a94442");
					}else{
						$("#email2").removeClass("has-error");
						$("#emailError2").html("");
					}
			});
				
				
			$("#confirmPassword").change(function() {
			console.log("ss");
				if($("#changedPassword").val() != $("#confirmPassword").val()){
					$("#pwd").addClass("has-error");
					$("#confirmPasswordError").html("Both Passwords should match").css("color", "#a94442");
					return false;
				}else{
					$("#pwd").removeClass("has-error");
					$("#confirmPasswordError").html("");
					return true;
				}
			});
			
			$("#changePasswordForm").submit(function(){
				if($("#changePasswordForm").valid() && validateEmail($("#changedLoginName").val()) && confirmPassword() && confirmEmail()){
						// process the form
						$.ajax({
							type        : 'GET', // define the type of HTTP verb we want to use (POST for our form)
							url         : 'partials/update/updateEmailPassword.php', // the url where we want to POST
							data        :  $("#changePasswordForm").serialize(), // our data object
							encode      : true,
							beforeSend: function() { 
								$("#changePasswordButton").prop("disabled", true); // disable button
								$("#changePasswordButton").val('Saving ...');
							},
							success: function(data) {
								var reply = data.replace(/\s+/, ""); //remove any trailing white spaces from returned string
								
								if (reply.trim() === 'Success'){
								console.log('idhar');
									$("#successMessage").html('<div class="alert alert-success"><cite>Email and Password changed successfully. You will be  redirected to login page in 10 secs. Kindly use the new username (email Id) and Password for further logging into to application</cite></div>');
									
									window.setTimeout(function () {
										location.href = "../session/auth.php?do=logout";
									}, 10000);
								}
								if (reply.trim() === 'Failure'){
								$("#emailErrorMessage").html('<div class="alert alert-danger"><cite>This Email Id is already used by another Candidate</cite></div>');
								$("#changePasswordButton").prop("disabled", false); // disable button
								$("#changePasswordButton").text('Save Changes');
							}
							}
						});
						
						
				}
				// stop the form from submitting the normal way and refreshing the page
				event.preventDefault();
			});
		});
		</script>
	</body>
</html>