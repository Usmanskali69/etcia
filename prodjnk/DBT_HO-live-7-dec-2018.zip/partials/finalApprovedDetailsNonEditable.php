<?php
	include('../db_connect.php');
	// $auditQrys = "SELECT * FROM approval_audit WHERE studentUniqueId='".$studentUniqueId."' and DBTApplicationStatus='Approved'";
	// $auditRess = mysqli_query($con, $auditQrys);
	
	$auditQrys = "SELECT * FROM approval_audit WHERE studentUniqueId=? and DBTApplicationStatus='Approved'";
	$stmt = mysqli_prepare($con, $auditQrys);
	mysqli_stmt_bind_param($stmt, 's', $studentUniqueId);
	mysqli_stmt_execute($stmt);
	$auditRess = mysqli_stmt_get_result($stmt);
	
	// $currauditQrys = "SELECT * FROM approval_audit WHERE studentUniqueId='".$studentUniqueId."' and DBTApplicationStatus='Approved' order by approvalAuditId desc limit 1";
	// $currauditRess = mysqli_query($con, $currauditQrys);
	
	$currauditQrys = "SELECT * FROM approval_audit WHERE studentUniqueId=? and DBTApplicationStatus='Approved' order by approvalAuditId desc limit 1";
	$stmt11 = mysqli_prepare($con, $currauditQrys);
	mysqli_stmt_bind_param($stmt11, 's', $studentUniqueId);
	mysqli_stmt_execute($stmt11);
	$currauditRess = mysqli_stmt_get_result($stmt11);
			
?>
<div class="container">
	<ul class="nav nav-tabs" style="margin-top:20px;">
		<li class="active"><a href="#current-application" data-toggle="tab">Current Application</a><li>
		<?php
			if(mysqli_num_rows($auditRess) > 0){
		?>
		<li><a href="#previous-approval-application" data-toggle="tab">Previously Approved Application</a></li>
		<?php
		}
		?>
	</ul>
	<div class="tab-content" style="border:1px solid #E0E0E0;">
		<div class="tab-pane active" id="current-application">
				<form id="finalApproveOrReject" name="finalApproveOrReject" class="form-horizontal" role="form" method="post" enctype="multipart/form-data">
				<input hidden name="category" id="category" value="<?php echo $college_row['category'];?>"/>
				<input hidden name="stream" id="stream" value="<?php echo $user_row['otherStudentStreamAppliedFor'];?>"/>
				<input hidden name="admissionThroughCCP" id="admissionThroughCCP" value="<?php echo $user_row['admissionThroughCCP'];?>"/>
				<input hidden name="yearOfCounselling" id="yearOfCounselling" value="<?php echo $user_row['yearOfCounselling'];?>"/>
				<div class="container" style="background-color: <?php if($user_row['admissionThroughCCP']=='Yes'){if($user_row['yearOfCounselling']=='2012-13'){echo '#FFFFCC';}else if($user_row['yearOfCounselling']=='2014-15'){echo '#CCFFCC';}else if($user_row['yearOfCounselling']=='2013-14'){echo '#D0D0D0';}else if($user_row['yearOfCounselling']=='2015-16'){echo '##FFFFFF ';}}else{ echo '#FFCCCC';}?>">
							<div class="panel-body">
								<div class="col-sm-12" role="complementary">
									<?php
								if(mysqli_num_rows($currauditRess) > 0){
								?>
								<div class="panel panel-default">
									<div class="panel-body table-responsive">
									<table class="table table-bordered table-condensed f11">
										<tr>
											<td colspan="5" align="center" class="danger"><b>Previously Approved Details</b></td>
										</tr>
										<tr>
											<td  align="left" width="20%"><b>Candidate Id</b></td>
											<td  align="left" width="20%"><b>Payment Till</b></td>
											<td  align="left" width="20%"><b>Approved Total</b></td>
											<td  align="left" width="20%"><b>Payment Type</b></td>
											<td  align="left" width="20%"><b>Final Approval Date</b></td>
														
										</tr>
										<?php
											
												while($audit_row = mysqli_fetch_array($currauditRess, MYSQLI_ASSOC)){
										?>
													<tr>
														<td  align="left"><?php echo $audit_row['studentUniqueId'];?></td>
														<td  align="left"><?php echo $audit_row['actualPaymentTill'].'-'.$audit_row['paymentType'];?></td>
														<td  align="left"><?php echo $audit_row['approvedTotal'];?></td>
														<td  align="left"><?php echo $audit_row['paymentType'];?></td>
														<td  align="left"><?php echo $audit_row['finalApprovalDate'];?></td>
														
														
														
													</tr>
										<?php
												}
											
										?>
									</table>
									</div>
								</div>
								<?php
								}
								?>
									<div class="panel panel-default">
										<div class="panel-body table-responsive">
										
										<table class="table table-bordered table-condensed f11">
											<tr>
												<td colspan="4" align="center" class="danger"><b>Basic Details</b></td>
											</tr>
											
											<tr>
												<td  align="left" width="20%"><b>Candidate Id :</b></td>
												<td  align="left"><input type="hidden" id="candidateID" name="candidateID" value="<?php echo $user_row['studentUniqueId'];?>"/><?php echo $user_row['studentUniqueId'];?></td>
													
												<td valign="center" width="15%"  rowspan="8">
														<img src="../<?php echo $user_row['photo'];?>" width="200" height="200" style="background: 10px solid black" >
												</td>
											</tr>
											<tr>
												<td align="left" width="20%"><b>Beneficiary Code:</b></td>
												<td align="left"><?php echo $user_row['disclaimer'];?></td>
											</tr>
											<tr>
												<td align="left" width="20%"><font color="Red"><b>Candidate Name:</b></font></td>
												<td align="left"> <?php if($user_row['speciallyAllowedFlag']=='Y'){ echo $user_row['name']; }else{echo $user_row['firstName'];?>&nbsp;<?php echo $user_row['middleName'];?>&nbsp;<?php echo $user_row['lastName'];}?></td>
											</tr>
											<?php if($user_row['speciallyAllowedFlag']=='Y'){ ?>
							<tr>
												<td align="left" width="20%"><b>Father Name:</b></td>
												<td align="left"><?php echo $user_row['fatherName'];?></td>
											</tr>
											<tr>
												<td align="left" width="20%"><b>Date Of Birth:</b></td>
												<td align="left"><?php echo $user_row['birthDate'];?></td>
											</tr>
											<tr>
												<td align="left" width="20%"><b>Caste Category:</b></td>
												<td align="left"><?php echo $user_row['casteCategory'];?></td>
											</tr>
							<?php } ?>
											<tr>
												<td align="left" width="20%"><b>Mobile No:</b></td>
												<td align="left"><?php echo $user_row['mobileNo'];?></td>
											</tr>
											<tr>
												<td align="left" width="20%"><b>Alternate Email Id (if any):</b></td>
												<td align="left"><?php echo $user_row['alternateEmailId'];?></td>
											</tr>
											<tr>
												<td align="left" width="20%"><font color="Red"><b>Aadhar Card Number:</b></font></td>
												<td align="left"><?php echo $user_row['UIDNo'];?></td>
											</tr>
											
										</table>
										</div>
									</div>
									
									<!--<div class="panel panel-default">
										<div class="panel-body table-responsive">
										<table class="table table-bordered table-condensed f11">
											<tr>
												<td colspan="4" align="center" class="danger"><b>Address Details:</b></td>
											</tr>
											<tr>
												<td colspan="2" align="center" ><b>Permanent Residential Address:</b></td>
												<td colspan="2" align="center" ><b>Current Residential Address:</b></td>
											</tr>
											<tr>
												<td width="20%" align="left"><b>Permanent Address:</b></td>
												<td width="30%" align="left"><?php echo $user_row['permanentAddress'];?></td>
												<td width="20%" align="left"><b>Current Address:</b></td>
												<td width="30%" align="left"><?php echo $user_row['hostelAddress'];?></td>
											</tr>
											<tr>
												<td width="20%" align="left"><b>State:</b></td>
												<td width="30%" align="left"><?php echo $user_row['permanentState'];?></td>
												<td width="20%" align="left"><b>State:</b></td>
												<td width="30%" align="left"><?php echo $user_row['hostelState'];?></td>
											</tr>
											<tr>
												<td width="20%" align="left"><b>District:</b></td>
												<td width="30%" align="left"><?php echo $user_row['permanentDistrict'];?></td>
												<td width="20%" align="left"><b>District:</b></td>
												<td width="30%" align="left"><?php echo $user_row['hostelDistrict'];?></td>
											</tr>
											<tr>
												<td width="20%" align="left"><b>City:</b></td>
												<td width="30%" align="left"><?php echo $user_row['permanentCity'];?></td>
												<td width="20%" align="left"><b>City:</b></td>
												<td width="30%" align="left"><?php echo $user_row['hostelCity'];?></td>
											</tr>
											<tr>
												<td width="20%" align="left"><b>Pin code:</b></td>
												<td width="30%" align="left"><?php echo $user_row['permanentPinCode'];?></td>
												<td width="20%" align="left"><b>Pin code:</b></td>
												<td width="30%" align="left"><?php echo $user_row['hostelPincode'];?></td>
											</tr>
											
										</table>					
										
										</div>	
									</div>-->
									
									
									<div class="panel panel-default">
										<div class="panel-body table-responsive">
										<table class="table table-bordered table-condensed f11">
											<tr>
												<td colspan="4" align="center" class="danger"><b>Institute Details:</b></td>
											</tr>
											
											<tr>
												<td colspan="4" align="left"><b>(I) Basic Institute Details:</b></td>
											</tr>
											<tr>
												<td width="20%" align="left"><b>Admission through Centralized Counselling Process:</b></td>
												<td width="30%" align="left"><?php echo $user_row['admissionThroughCCP'];?></td>
												<td width="20%" align="left"><b>Year of Admission:</b></td>
												<td width="30%" align="left"><?php echo $user_row['yearOfCounselling'];?></td>
											</tr>
											<tr>
												<td width="20%" align="left"><b>Institute ID:</b></td>
												<td width="30%" align="left"><?php if($user_row['collegeUniqueId']!='' && $user_row['collegeUniqueId']!=null){ echo $user_row['collegeUniqueId'];} else { echo $user_row['otherStudentCollegeId'];}?></td>
												<td width="20%" align="left"><font color="Red"><b>Institute Name:</b></font></td>
												<td width="30%" align="left"><?php if($user_row['collegeUniqueId']!='' && $user_row['collegeUniqueId']!=null){ echo $college_row['name'];} else { echo $user_row1['otherStudentCollegename'];}?></td>
											</tr>
											<tr>
												<td width="20%" align="left"><font color="Red"><b>Course Name:</b></font></td>
												<td width="30%" align="left"><?php if($user_row['collegeUniqueId']!='' && $user_row['collegeUniqueId']!=null){ echo $course_row['courseName'];} else { echo $user_row1['otherStudentCourseName'];}?></td>
												
												<td width="20%" align="left"><b>Affiliating University:</b></td>
												<td width="30%" align="left"><?php if($user_row['collegeUniqueId']!='' && $user_row['collegeUniqueId']!=null){ echo $course_row['university'];} else { echo $user_row1['otherStudentUniversity'];}?></td>
												
												
											</tr>
											
											<tr>
												<td width="20%" align="left"><b>Institute Category:</b></td>
												<td width="30%" align="left"><?php echo $user_row['instituteCategory'];?></td>
												<td width="20%" align="left"><b>Other Institute Category:</b></td>
												<td width="30%" align="left"><?php if($user_row['instituteCategory']=='Any Other'){echo $user_row['otherInstituteCategory'];}
												else {echo "-";}?></td>
											</tr>
											<tr>
												<td width="20%" align="left"><b><font color="Red">Institute Stream:</font></b></td>
												<td width="30%" align="left"><?php if($user_row['collegeUniqueId']!='' && $user_row['collegeUniqueId']!=null){ echo $college_row['category'];} else { echo $user_row['otherStudentStreamAppliedFor'];}?></td>
												
												
												
											</tr>
											<tr>
												
												<td width="20%" align="left"><b>Institute Website:</b></td>
												<td width="30%" align="left"><?php echo $user_row['instituteWebsite'];?></td>
												
											</tr>
											<tr>
												<td colspan="4" align="left"><b>(II) Contact Person Details:</b></td>
											</tr>
											<tr>
												<td width="20%" align="left"><b>Contact Person Name:</b></td>
												<td width="30%" align="left"><?php echo $user_row['contactPerson'];?></td>
												<td width="20%" align="left"><b>Designation of contact person:</b></td>
												<td width="30%" align="left"><?php echo $user_row['designationOfContactPerson'];?></td>
												
												
											</tr>
											<tr>
												<td width="20%" align="left"><b>Contact Number:</b></td>
												<td width="30%" align="left"><?php echo $user_row['contactPersonNumber'];?></td>
											</tr>
											
											
										</table>					
										</div>
										</div>
										
										<?php $current_year1=date("Y");
		$yearOfCounselling= substr($user_row['yearOfCounselling'], 0, 4);
		
		if((int)$yearOfCounselling < (int)$current_year1){?>
									<div class="panel panel-default">
										<div class="panel-body table-responsive">
										<table class="table table-bordered table-condensed f11">
											<tr>
												<td colspan="7" align="center" class="danger"><b>Academic Record:</b></td>
											</tr>
											<tr>
												<td colspan="2" align="left"><b>Examination Type:</b></td>
												<td colspan="1" align="left"><?php echo $user_row['examType'];?></td>
												<td colspan="2" align="left"><b>Examination pattern:</b></td>
												<td colspan="2" align="left"><?php echo $user_row['examPattern'];?></td>
											</tr>
											<tr>
												<td colspan="2" align="left"><b>Enrollment No:</b></td>
												<td colspan="1" align="left"><?php echo $user_row['enrollmentNo'];?></td>
												<td colspan="2" align="left"><b>University Name:</b></td>
												<td colspan="2" align="left"><?php echo $user_row['universityName'];?></td>
											</tr>
											<tr>
											<td colspan="7">&nbsp;</td>
											
											<?php
											$query_year='SELECT year(DBTApplicationSubmittedDate) as yearSubmitted FROM students WHERE studentUniqueId="'.$studentUniqueId.'"';
								//ho $query_year;
								$result_year = mysqli_query($con,$query_year) or die('Query Failed');
								$user_row_year = mysqli_fetch_array($result_year);
											$yearOfCounselling= substr($user_row['yearOfCounselling'], 0, 4);
														$current_year = $user_row_year['yearSubmitted'];
													$yeardiff=intval($current_year)-intval($yearOfCounselling);
													$candidateId= $user_row['studentUniqueId'];
													$j=0;
													
													$examType=$user_row['examType'];
												// $status_qry="SELECT paymentTill,actualPaymentTill,DBTApplicationStatus FROM approval_audit where studentUniqueId='".$candidateId."' order by approvalAuditId desc limit 1";
// $count_qry="SELECT count(approvalAuditId) as countAuditRecord FROM approval_audit where studentUniqueId='".$candidateId."'";

// $status_result = mysqli_query($con, $status_qry);
// $status_data =mysqli_fetch_array($status_result);

$status_qry="SELECT paymentTill,actualPaymentTill,DBTApplicationStatus FROM approval_audit where studentUniqueId=? order by approvalAuditId desc limit 1";
$stmt3 = mysqli_prepare($con, $status_qry);
	mysqli_stmt_bind_param($stmt3, 'i', $candidateId);
	mysqli_stmt_execute($stmt3);
	
	$status_result = mysqli_stmt_get_result($stmt3);
	$status_data = mysqli_fetch_array($status_result, MYSQLI_ASSOC);
	
	$count_qry="SELECT count(approvalAuditId) as countAuditRecord FROM approval_audit where studentUniqueId=?";

$stmt4 = mysqli_prepare($con, $count_qry);
	mysqli_stmt_bind_param($stmt4, 'i', $candidateId);
	mysqli_stmt_execute($stmt4);	
	$count_result = mysqli_stmt_get_result($stmt4);
	$count_data = mysqli_fetch_array($count_result, MYSQLI_ASSOC);
	
// $count_result = mysqli_query($con, $count_qry);
// $count_data =mysqli_fetch_array($count_result);

$countAuditRecord = $count_data['countAuditRecord'];
$DBTApplicationStatus = $status_data['DBTApplicationStatus'];
	
if($countAuditRecord>0){
$actualPaymentTill = $status_data['actualPaymentTill'];

if($DBTApplicationStatus=='Rejected'){
$j=$actualPaymentTill-1;
}
else{

//$j=$actualPaymentTill;
$j=$actualPaymentTill;

}
}
elseif($yearOfCounselling<=2015 && $countAuditRecord==0){
$yeardiff=2015-intval($yearOfCounselling);
$j=0;
if($examType=='Yearly')
{
	$j=$yeardiff;
}
if($examType=='Semester')
{
	$j=$yeardiff*2;
	
}
}
else
{
$yeardiff=intval($current_year)-intval($yearOfCounselling);
$j=0;

if($examType=='Yearly')
{
	$j=$yeardiff;
}
if($examType=='Semester')
{
	$j=$yeardiff*2;
	if($current_month < 07)
	{
		$j=$j-1;
	}
}
}
										

											
											 if($j>0){ ?>
											</tr>
											<tr>
												<br/>
												<td><b>Sr no.</b></td><td><b>Semester/Year</b></td><td><b>Percentage/SGPA Obtained</b></td><td><b>Roll Number</b></td><td><b>Result</b></td><td align="center"><b>Uploaded</b></td><td align="center"><b>Preview</b></td>
											</tr>
											<?php } ?>
											<?php for($i=1;$i<=$j;$i++){
											$sem="";
									
									if($i==1 && $examType=='Semester')
									{
									$sem=$i.'st Sem';
									}
									else if($i==1 && $examType=='Yearly')
									{
									$sem=$i.'st Year';
									}
									else if($i==2 && $examType=='Semester')
									{
									$sem=$i.'nd Sem';
									} 
									else if($i==2 && $examType=='Yearly')
									{
									$sem=$i.'nd Year';
									} 
									else if($i==3 && $examType=='Semester')
									{
									
									$sem=$i.'rd Sem';
									} 
									else if($i==3 && $examType=='Yearly')
									{
									$sem=$i.'rd Year';
									}
									else
									{
									if($examType=='Semester'){ $sem=$i.'th Sem';}
									if($examType=='Yearly'){$sem=$i.'th Year';}
									
									}
									include("db_connect.php");
									$AYquery="select * from academic_year_record where studentUniqueId='".$user_row['studentUniqueId']."' and semester='".$sem."'";
									//echo $AYquery;
									$AYresult = mysqli_query($con, $AYquery);
									$AY_row=mysqli_fetch_array($AYresult);
									mysqli_close();
									$semester=$AY_row['semester'];
									$percentage=$AY_row['percentageOrGPA'];
									$rollNo=$AY_row['rollNo'];
									$result=$AY_row['result'];
											?>
											<tr>
											<td><?php echo $i;?></td>
											<td><?php echo $semester;?></td>
											<td><?php echo $percentage?></td>
											<td><?php echo $rollNo;?></td>
											<td><?php echo $result;?></td>
											<td align="center"><?php if($AY_row['attachment']!='' && $AY_row['attachment']!=null)
								{
									echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
								}
								else
								{
									echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
								}?></td>
											<td align="center"><?php $semPass=str_replace(' ', '', $sem);
												echo '<a href="DBT_AY_AttachmentModal.php?studentId='.$user_row['studentUniqueId'].'&semPass='.$semPass.'" data-toggle="modal" data-target="#attachmenModal">
							<h4><span class="glyphicon glyphicon-eye-open" aria-hidden="true">
							</span></h4>
							</a>';?></td>
											</tr>
											<?php }?>
											</table>
											</tr>
											</table>
										
										</div>
									</div>
									<?php }?>	
										
										
									
									
									<div class="panel panel-default">
										<div class="panel-body table-responsive">
											<table class="table table-bordered table-condensed f11">
												<tr>
													<td colspan="4" align="center" class="danger"><b>Bank Details:</b></td>
												</tr>
												<tr>
													<td colspan="4" align="left"><b>Saving Bank Account Details</b></td>
												</tr>
												<tr>
													<td width="20%" align="left"><font color="Red"><b>Account Holder Name(Candidate):</b></font></td>
													<td width="30%" align="left"><?php echo $user_row['accountHolderName'];?></td>
													<td width="20%" align="left"><font color="Red"><b>Bank Name:</b></font></td>
													<td width="30%" align="left"><?php echo $user_row['bankName'];?></td>
												</tr>
												<tr>
													<td width="20%" align="left"><b>Bank Branch Name:</b></td>
													<td width="30%" align="left"><?php echo $user_row['bankBranchName'];?></td>
													<td width="20%" align="left"><b>Branch Code:</b></td>
													<td width="30%" align="left"><?php echo $user_row['branchCode'];?></td>
												</tr>
												<tr>
													<td width="20%" align="left"><font color="Red"><b>Bank IFSC Code:</b></font></td>
													<td width="30%" align="left"><?php echo $user_row['bankifscCode'];?></td>
													<td width="20%" align="left"><font color="Red"><b>Bank Account Number:</b></font></td>
													<td width="30%" align="left"><?php echo $user_row['bankAccountNumber'];?></td>
												</tr>
																		
												<tr>
													<td width="20%" align="left"><b>Bank Address:</b></td>
													<td width="30%" align="left"><?php echo $user_row['bankAddress'];?></td>
													
												</tr>
												
												
											</table>								
										</div>	
									</div>
									
									<div class="panel panel-default">
										<div class="panel-body table-responsive">
											<table class="table table-bordered table-condensed f11">
												<tr>
													<td colspan="4" align="center" class="danger"><b>Attachments:</b></td>
												</tr>
												<tr>
													<td align="center" ><b>Attachment Name</b></td>
													<td align="center" ><b>Uploaded</b></td>
													<td align="center" ><b>Preview</b></td>
													<td align="center" ><b>Download</b></td>
												</tr>
												<tr>
												<?php if($user_row['speciallyAllowedFlag'] == 'N'){?>
													<td width="60%" align="left"><b>Joining Report:</b></td>
													<td width="20%" align="center">
														<?php if($user_row['joiningReport']!='' && $user_row['joiningReport']!=null)
								{
									echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
								}
								else
								{
									echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
								}?>
													</td>
													<td width="20%" align="center"><a href="DBTAttachmentModal.php?type=joiningReport&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
															<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
															</span></h4>
															</a>					
													</td>
													<td width="20%" align="center">
													<?php if($user_row['joiningReport']!='' && $user_row['joiningReport']!=null){?>
													<a href="../DBT_HO/DownloadAttachment.php?studentUniqueId=<?php echo $user_row['studentUniqueId']; ?>&attachmentName=joiningReport"><h4><span class='glyphicon glyphicon-download text-success' aria-hidden='true'></span></h4></a>
													<?php } else {?>
													<h4><span class='glyphicon glyphicon-download text-danger' aria-hidden='true'></span></h4>
													<?php } ?>
												</td>
													
												</tr>
												<tr>
													<td width="60%" align="left"><b>Tution Fee Receipts:</b></td>
													<td width="20%" align="center">
														<?php if($user_row['feeReceipt']!='' && $user_row['feeReceipt']!=null)
								{
									echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
								}
								else
								{
									echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
								}?>
													</td>
													<td width="20%" align="center"><a href="DBTAttachmentModal.php?type=feeReceipt&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
														<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
														</span></h4>
														</a>
													</td>
													<td width="20%" align="center">
													<?php if($user_row['feeReceipt']!='' && $user_row['feeReceipt']!=null){?>
													<a href="../DBT_HO/DownloadAttachment.php?studentUniqueId=<?php echo $user_row['studentUniqueId']; ?>&attachmentName=feeReceipt"><h4><span class='glyphicon glyphicon-download text-success' aria-hidden='true'></span></h4></a>
													<?php } else {?>
													<h4><span class='glyphicon glyphicon-download text-danger' aria-hidden='true'></span></h4>
													<?php } ?>
												</td>
												</tr>
												<?php }else{?>
												<tr>
													<td width="60%" align="left"><b>Joining Report/Tuition Fee/Hostel Fee/Reasonability of Rent/Other incidental charges Receipt:</b></td>
													<td width="20%" align="center">
													<?php if($user_row['joiningtutionhostelReceipt']!='' && $user_row['joiningtutionhostelReceipt']!=null)
													{
														echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
													}
													else
													{
														echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
													}?>
													</td>
													<td width="20%" align="center">
														<a href="DBTAttachmentModal.php?type=JoiningTutionHostelReceipt&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
															<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
															</span></h4>
														</a>
													</td>
												</tr>
												<tr>
													<td width="60%" align="left"><b>HSC Marksheet:</b></td>
													<td width="20%" align="center">
													<?php if($user_row['hscmarksheetfile']!='' && $user_row['hscmarksheetfile']!=null)
													{
														echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
													}
													else
													{
														echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
													}?>
													</td>
													<td width="20%" align="center">
														<a href="DBTAttachmentModal.php?type=HscMarksheet&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
															<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
															</span></h4>
														</a>
													</td>
												</tr>
												<tr>
													<td width="60%" align="left"><b>SSC Marksheet:</b></td>
													<td width="20%" align="center">
													<?php if($user_row['sscmarksheetfile']!='' && $user_row['sscmarksheetfile']!=null)
													{
														echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
													}
													else
													{
														echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
													}?>
													</td>
													<td width="20%" align="center">
														<a href="DBTAttachmentModal.php?type=SscMarksheet&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
															<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
															</span></h4>
														</a>
													</td>
												</tr>
												<?php } ?>
												<tr>
													<td width="20%" align="left"><b>Do you reside in college Hostel:</b></td>
													<td width="30%" align="center"><?php echo $user_row['resideInCollege'];?></td>
													
												</tr>
																		
												<tr>
												<?php if($user_row['resideInCollege']=='No' && $user_row['speciallyAllowedFlag']=='N'){?>
													<td width="60%" align="left"><b>Reasonability of Rent Certificate:</b></td>
													<td width="20%" align="center">
														<?php if($user_row['rentReceipt']!='' && $user_row['rentReceipt']!=null)
								{
									echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
								}
								else
								{
									echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
								}?>
													</td>
													<td width="20%" align="center">
														<a href="DBTAttachmentModal.php?type=rentReceipt&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
														<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
														</span></h4>
														</a>
													</td>
													<td width="20%" align="center">
													<?php if($user_row['rentReceipt']!='' && $user_row['rentReceipt']!=null){?>
													<a href="../DBT_HO/DownloadAttachment.php?studentUniqueId=<?php echo $user_row['studentUniqueId']; ?>&attachmentName=rentReceipt"><h4><span class='glyphicon glyphicon-download text-success' aria-hidden='true'></span></h4></a>
													<?php } else {?>
													<h4><span class='glyphicon glyphicon-download text-danger' aria-hidden='true'></span></h4>
													<?php } ?>
												</td>
												<?php }?>
												<?php if($user_row['resideInCollege']=='Yes' && $user_row['speciallyAllowedFlag']=='N'){?>
													<td width="60%" align="left"><b>Hostel Fee Receipt:</b></td>
													<td width="20%" align="center">
														<?php if($user_row['collegehostelReceipt']!='' && $user_row['collegehostelReceipt']!=null)
								{
									echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
								}
								else
								{
									echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
								}?>
													
													</td>
													<td width="20%" align="center">
														<a href="DBTAttachmentModal.php?type=collegehostelReceipt&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
														<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
														</span></h4>
														</a>
													</td>
													<td width="20%" align="center">
													<?php if($user_row['collegehostelReceipt']!='' && $user_row['collegehostelReceipt']!=null){?>
													<a href="../DBT_HO/DownloadAttachment.php?studentUniqueId=<?php echo $user_row['studentUniqueId']; ?>&attachmentName=collegehostelReceipt"><h4><span class='glyphicon glyphicon-download text-success' aria-hidden='true'></span></h4></a>
													<?php } else {?>
													<h4><span class='glyphicon glyphicon-download text-danger' aria-hidden='true'></span></h4>
													<?php } ?>
												</td>
												<?php }?>
												</tr>
												
												<tr>
													<td width="60%" align="left"><b>Book receipts:</b></td>
													<td width="20%" align="center"><?php if($user_row['bookReceipt']!='' && $user_row['bookReceipt']!=null)
								{
									echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
								}
								else
								{
									echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
								}?></td>
													<td width="20%" align="center">
														<a href="DBTAttachmentModal.php?type=bookReceipt&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
														<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
														</span></h4>
														</a>
													</td>
													<td width="20%" align="center">
													<?php if($user_row['bookReceipt']!='' && $user_row['bookReceipt']!=null){?>
													<a href="../DBT_HO/DownloadAttachment.php?studentUniqueId=<?php echo $user_row['studentUniqueId']; ?>&attachmentName=bookReceipt"><h4><span class='glyphicon glyphicon-download text-success' aria-hidden='true'></span></h4></a>
													<?php } else {?>
													<h4><span class='glyphicon glyphicon-download text-danger' aria-hidden='true'></span></h4>
													<?php } ?>
												</td>
												</tr>
												<?php if($user_row['speciallyAllowedFlag']=='N'){ ?>
												<tr>
													<td width="60%" align="left"><b>Other incidental charges Receipt:</b></td>
													<td width="20%" align="center">
													<?php if($user_row['otherIncidentalChargesReceipt']!='' && $user_row['otherIncidentalChargesReceipt']!=null)
								{
									echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
								}
								else
								{
									echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
								}?>
								</td>
													<td width="20%" align="center">
														<a href="DBTAttachmentModal.php?type=otherIncidentalCharges&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
														<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
														</span></h4>
														</a>
													</td>
													<td width="20%" align="center">
													<?php if($user_row['otherIncidentalChargesReceipt']!='' && $user_row['otherIncidentalChargesReceipt']!=null){?>
													<a href="../DBT_HO/DownloadAttachment.php?studentUniqueId=<?php echo $user_row['studentUniqueId']; ?>&attachmentName=otherIncidentalCharges"><h4><span class='glyphicon glyphicon-download text-success' aria-hidden='true'></span></h4></a>
													<?php } else {?>
													<h4><span class='glyphicon glyphicon-download text-danger' aria-hidden='true'></span></h4>
													<?php } ?>
												</td>
												</tr>
												<?php } ?>
												<tr>
													<td width="60%" align="left"><b>Bank Pass Book:</b></td>
													<td width="20%" align="center">
														<?php if($user_row['bankPassBook']!='' && $user_row['bankPassBook']!=null)
								{
									echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
								}
								else
								{
									echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
								}?>
													</td>
													<td width="20%" align="center">
														<a href="DBTAttachmentModal.php?type=bankPassBook&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
														<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
														</span></h4>
														</a>
													</td>
													<td width="20%" align="center">
													<?php if($user_row['bankPassBook']!='' && $user_row['bankPassBook']!=null){?>
													<a href="../DBT_HO/DownloadAttachment.php?studentUniqueId=<?php echo $user_row['studentUniqueId']; ?>&attachmentName=bankPassBook"><h4><span class='glyphicon glyphicon-download text-success' aria-hidden='true'></span></h4></a>
													<?php } else {?>
													<h4><span class='glyphicon glyphicon-download text-danger' aria-hidden='true'></span></h4>
													<?php } ?>
												</td>
												</tr>
												<tr>
													<td width="20%" align="left"><b>Aadhar Card:</b></td>
													<td width="20%" align="center">
													<?php if($user_row['aadharCard']!='' && $user_row['aadharCard']!=null)
								{
									echo "<h4><span class='glyphicon glyphicon-ok text-success' aria-hidden='true'></span></h4>";
								}
								else
								{
									echo "<h4><span class='glyphicon glyphicon-remove text-danger' aria-hidden='true'></span></h4>";
								}?>
													</td>
													<td width="30%" align="center">
														<a href="DBTAttachmentModal.php?type=aadharCard&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal">
														<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
														</span></h4>
														</a>
													</td>
													<td width="20%" align="center">
													<?php if($user_row['aadharCard']!='' && $user_row['aadharCard']!=null){?>
													<a href="../DBT_HO/DownloadAttachment.php?studentUniqueId=<?php echo $user_row['studentUniqueId']; ?>&attachmentName=aadharCard"><h4><span class='glyphicon glyphicon-download text-success' aria-hidden='true'></span></h4></a>
													<?php } else {?>
													<h4><span class='glyphicon glyphicon-download text-danger' aria-hidden='true'></span></h4>
													<?php } ?>
												</td>
												</tr>
												
											</table>								
										</div>	
									</div>
									
									<div class="panel panel-default">
										<div class="panel-body table-responsive">
											<table class="table table-bordered table-condensed f11">
												<tr>
													<td colspan="6" align="center" class="danger"><b>Fee Details:</b></td>
												</tr>
												<tr>
												<td width="20%" align="left"><b>Payment Type:</b></td>
												<td width="30%" align="left">
												<?php echo $user_row['paymentType'];?>
											</td>
											<td width="20%" align="left"><b>Course Duration:</b></td>
											<td width="50%" align="left">
											<?php echo $user_row['courseDuration'];?>
											</td>
											<div id="courseDurationErrorMsg"></div>
											</tr>
												<tr>
												<td colspan="3" align="center"><b>(A)</b></td>
												<td colspan="3" align="center"><b>(B)</b></td>
											</tr>
											<tr>
												<td align="center"></td>
												<td align="center"><b>Applied</b></td>
												<td align="center"><b>Approved</b></td>
												<td align="center"></td>
												<td align="center"><b>Applied</b></td>
												<td align="center"><b>Approved</b></td>
											</tr>
											<tr>
												<td width="20%" align="left"><b>Tution Fee:</b></td>
												<td width="15%" align="left"><?php echo $user_row['tutionFees'];?></td>
												<td width="15%" align="left" id="tutionFeesError">
												<?php echo $user_row['approvedTutionFees'];?>
												
												<div id="tutionFeesErrorMsg"></div>
												</td>
												<td width="20%" align="left"><b>Hostel and Mess Fee:</b></td>
												<td width="15%" align="left"><?php echo $user_row['hostelFees']?></td>
												<td width="15%" align="left">
												<?php echo $user_row['approvedHostelFees'];?>
												
												</td>
											</tr>
											<tr>
												<td colspan="3" align="left" rowspan="2"></td>
												
												<td width="20%" align="left"><b>Books & Stationary:</b></td>
												<td width="15%" align="left"><?php echo $user_row['bookNStationaryCharges'];?></td>
												<td width="15%" align="left">
												<?php echo $user_row['approvedBookNStationaryCharges'];?>			
												</td>
											</tr>
											<tr>
											
											<td width="20%" align="left"><b>Other Incidental Charges :</b></td>
												<td width="15%" align="left"><?php echo $user_row['otherCharges'];?></td>
												<td width="15%" align="left">
													<?php echo $user_row['approvedOtherCharges'];?>
												</td>
											</tr>
											<tr>
											
												<td width="20%" align="left"><b>Total (A) :</b></td>
												<td width="15%" align="left"><?php echo $user_row['tutionFees'];?></td>
												<td width="15%" align="left"><?php echo $user_row['approvedTutionFees'];?>
												<td width="20%" align="left"><b>Total (B) :</b></td>
												<td width="15%" align="left"><?php echo $user_row['total'];?></td>
												<td width="15%" align="left" id="totalBError"><?php echo $user_row['approvedTotalB'];?></td>
											</tr>
											<tr>
											
												<td width="20%" align="left"><b>Total :</b></td>
												
												<td colspan="5" align="left"><?php echo $user_row['approvedTotal'];?></td>
												
											</tr>	
												
											</table>								
										</div>	
									</div>
									
									<div class="panel panel-default">
										<div class="panel-body table-responsive">
											<table class="table table-bordered table-condensed f11">
												<tr>
													<td colspan="2" align="center" class="danger"><b>Approval/Rejection Comment:</b></td>
												</tr>
												<tr>
													<td width="20%" align="left"><b>Approval/Rejection Comment:</b></td>
													<td width="80%" align="left" id="commentError">
														<?php echo $user_row['approvalOrRejectionComment'];?>	
													</td>
												</tr>
											</table>
										</div>
									</div>
								</div>
							</div>
							<div  class="col-lg-offset-2 col-lg-2" id="approveOrRejectMessage">
							
						</div>
						</div>
				</form>
						<div class="modal fade bs-example-modal-lg" id="attachmenModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" >
						  <div class="modal-dialog modal-lg" role="document">
							<div class="modal-content">
							  
							</div>
						  </div>
						</div>
			</div><!-- end of current-application -->
		<?php
			include('../db_connect.php');
			$auditQry = "SELECT * FROM approval_audit WHERE studentUniqueId='".$studentUniqueId."' and DBTApplicationStatus='Approved'";
			$auditRes = mysqli_query($con, $auditQry);
			
		?>
		<div class="tab-pane" id="previous-approval-application">
			<div class="panel-body">
				<div class="col-sm-12" role="complementary">
					<div class="panel panel-default">
						<div class="panel-body table-responsive">
							<table class="table table-bordered table-condensed f11">
								<tr>
									<td colspan="10" align="center" class="danger"><b>Audit Details</b></td>
								</tr>
								<tr>
									<td  align="left" width="20%"><b>Candidate Id</b></td>
									<td  align="left" width="20%"><b>Payment Type</b></td>
									<td  align="left" width="20%"><b>Approved Tution Fees</b></td>
									<td  align="left" width="20%"><b>Approved Hostel Fees</b></td>
									<td  align="left" width="20%"><b>Approved Book and Stationary Charges</b></td>
									<td  align="left" width="20%"><b>Approved Other Charges</b></td>
									<td  align="left" width="20%"><b>Approved Total</b></td>
									<td  align="left" width="20%"><b>Approvel/Rejection Comments</b></td>
									<td  align="left" width="20%"><b>Payment Till</b></td>
									<td  align="left" width="20%"><b>Final Approval Date</b></td>
												
								</tr>
								<?php
									if(mysqli_num_rows($auditRes) > 0){
										while($audit_row = mysqli_fetch_array($auditRes)){
								?>
											<tr>
												<td  align="left"><?php echo $audit_row['studentUniqueId'];?></td>
												<td  align="left"><?php echo $audit_row['paymentType'];?></td>
												<td  align="left"><?php echo $audit_row['approvedTutionFees'];?></td>
												<td  align="left"><?php echo $audit_row['approvedHostelFees'];?></td>
												<td  align="left"><?php echo $audit_row['approvedBookNStationaryCharges'];?></td>
												<td  align="left"><?php echo $audit_row['approvedOtherCharges'];?></td>
												<td  align="left"><?php echo $audit_row['approvedTotal'];?></td>
												<td  align="left"><?php echo $audit_row['approvalOrRejectionComment'];?></td>
												<td  align="left"><?php  echo $audit_row['actualPaymentTill'].'-'.$audit_row['paymentType'];?></td>
												<td  align="left"><?php echo $audit_row['finalApprovalDate'];?></td>
											</tr>
								<?php
										}
									}else{
								?>
										<tr>
											<td colspan="10" align="center"><?php if(mysqli_num_rows($auditRes) == 0){ echo 'No Records Found'; } ?></td>
										</tr>
								<?php
								
									}
								?>
											
							</table>
						</div>
					</div>
				</div>
			</div>
		</div><!--/#audit-application-->
	</div><!-- end of tab-content -->
</div><!-- end of container -->				
		