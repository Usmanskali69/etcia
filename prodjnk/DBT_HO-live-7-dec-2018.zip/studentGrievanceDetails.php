<?php
	require_once(realpath("session/session_verify.php"));
?>
<!DOCTYPE html>
<html lang="en">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="Suvojit Aown">

		<title>J&K Scholarship</title>

		<!-- Bootstrap Core CSS -->
		<link href="../css/bootstrap.min.css" rel="stylesheet">

		<!-- Bootstrap Table CSS -->
		<link href="../css/bootstrap-table.min.css" rel="stylesheet" >
		
		<!-- Bootstrap Date Picker CSS -->
		<link href="../css/bootstrap-datetimepicker.min.css" rel="stylesheet">
		
		<!-- Custom Fonts -->
		<link href="../font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		
		<link href="../css/style.css" rel="stylesheet" type="text/css">
	</head>

	<body>
		<div id="header" class="navbar navbar-default navbar-fixed-top">
			<div class="navbar-header">
				<button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target=".navbar-collapse">
					<i class="fa fa-bars"></i>
				</button>
				<a class="navbar-brand" href="index.php">
					<i class="fa fa-folder-open"></i>  J&K Scholarships
				</a>
			</div>
			<nav class="collapse navbar-collapse">
				
				<ul class="nav navbar-nav pull-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
							<i class="fa fa-user fa-lg"></i> <?php echo $_SESSION['hoId']; ?><b class="caret"></b></a>
						<ul class="dropdown-menu pull-right">
							<li><a href="#"><i class="fa fa-user fa-fw"></i> Center Profile</a></li>
							<li class="divider"></li>
							<li><a href="session/auth.php?do=logout"><i class="fa fa-power-off"></i> Logout</a></li>
						</ul>
					</li>
				</ul>
			</nav>
		</div>
		<div class="container" style="margin-bottom: 20px;">
		
			<?php
				include("../db_connect.php");
				$loginName=$_SESSION['hoId'];
				// fetching Student ID from session
				
				$studentUniqueId=htmlspecialchars($_GET['candidateID']);				
				$grievanceId = htmlspecialchars($_GET['grievanceId']);	
				
				if( preg_match('/^[1-9][0-9]/', $_GET['candidateID']) == 1)
				{
				
				//$query="SELECT * FROM students WHERE studentUniqueId='".$studentUniqueId."'";				
				//$result = mysqli_query($con,$query);	
				
				$query="SELECT * FROM students WHERE studentUniqueId=?";
				$stmt1 =mysqli_prepare($con, $query);
						mysqli_stmt_bind_param($stmt1, 'i', $studentUniqueId);
						mysqli_stmt_execute($stmt1);
				$result = mysqli_stmt_get_result($stmt1);							
				$user_row = mysqli_fetch_array($result, MYSQLI_ASSOC);
				
				//$collegequery="SELECT b.* FROM students a, colleges b WHERE a.collegeUniqueId=b.collegeUniqueId and studentUniqueId='".$studentUniqueId."'";				
				//$collegeresult = mysqli_query($con,$collegequery);	
				
				$collegequery="SELECT b.* FROM students a, colleges b WHERE a.collegeUniqueId=b.collegeUniqueId and studentUniqueId=?";
				$stmt2 =mysqli_prepare($con, $collegequery);
						mysqli_stmt_bind_param($stmt2, 'i', $studentUniqueId);
						mysqli_stmt_execute($stmt2);
				$collegeresult = mysqli_stmt_get_result($stmt2);	
				$college_row = mysqli_fetch_array($collegeresult, MYSQLI_ASSOC);
				}
				else
				{
				//$query="SELECT * FROM students WHERE primaryEmailId='".$studentUniqueId."'";				
				//$result = mysqli_query($con,$query);

				$query="SELECT * FROM students WHERE primaryEmailId=?";	
				$stmt3 =mysqli_prepare($con, $query);
						mysqli_stmt_bind_param($stmt3, 'i', $studentUniqueId);
						mysqli_stmt_execute($stmt3);
				$result = mysqli_stmt_get_result($stmt3);	
				$user_row = mysqli_fetch_array($result, MYSQLI_ASSOC);

                // $collegequery="SELECT * FROM students a, colleges b WHERE a.collegeUniqueId=b.collegeUniqueId and primaryEmailId='".$studentUniqueId."'";				
				//$collegeresult = mysqli_query($con,$collegequery);	
				
				
				$collegequery="SELECT * FROM students a, colleges b WHERE a.collegeUniqueId=b.collegeUniqueId and primaryEmailId=?";		
				$stmt4 =mysqli_prepare($con, $collegequery);
						mysqli_stmt_bind_param($stmt4, 'i', $studentUniqueId);
						mysqli_stmt_execute($stmt4);
				$collegeresult = mysqli_stmt_get_result($stmt4);		
				$college_row = mysqli_fetch_array($collegeresult, MYSQLI_ASSOC);				
					
				}
				
				
				
				//connect to grievance DB
				//$grievanceQuery="SELECT * FROM grievance.grievances WHERE grievanceId='".$grievanceId."'";
				//$grievanceResult = mysqli_query($con,$grievanceQuery);
				
				$grievanceQuery="SELECT * FROM grievance.grievances WHERE grievanceId=?";
				$stmt5 =mysqli_prepare($con, $grievanceQuery);
						mysqli_stmt_bind_param($stmt5, 'i', $grievanceId);
						mysqli_stmt_execute($stmt5);
				$grievanceResult = mysqli_stmt_get_result($stmt5);	
				$grievance_row = mysqli_fetch_array($grievanceResult, MYSQLI_ASSOC);
				
				//$commentsQuery="SELECT * FROM grievance.comments WHERE grievanceId='".$grievanceId."'";
				//$commentsResult=mysqli_query($con,$commentsQuery);

				$commentsQuery="SELECT * FROM grievance.comments WHERE grievanceId=?";
				$stmt6 =mysqli_prepare($con, $commentsQuery);
						mysqli_stmt_bind_param($stmt6, 'i', $grievanceId);
						mysqli_stmt_execute($stmt6);
				$commentsResult = mysqli_stmt_get_result($stmt6);					
				$comments_num = mysqli_num_rows($commentsResult);
				
				//$attachmentsQuery="SELECT * FROM grievance.attachments WHERE grievanceId='".$grievanceId."'";
				//$attachmentsResult=mysqli_query($con,$attachmentsQuery);
				
				$attachmentsQuery="SELECT * FROM grievance.attachments WHERE grievanceId=?";
				$stmt7 =mysqli_prepare($con, $attachmentsQuery);
						mysqli_stmt_bind_param($stmt7, 'i', $grievanceId);
						mysqli_stmt_execute($stmt7);
				$attachmentsResult = mysqli_stmt_get_result($stmt7);	
				$attachments_num = mysqli_num_rows($attachmentsResult);
				
				//$studentQuery="SELECT * FROM grievance.studentdetails WHERE grievanceId='".$grievanceId."'";
				//$studentResult=mysqli_query($con,$studentQuery);
				
				$studentQuery="SELECT * FROM grievance.studentdetails WHERE grievanceId=?";
				$stmt8 =mysqli_prepare($con, $studentQuery);
						mysqli_stmt_bind_param($stmt8, 'i', $grievanceId);
						mysqli_stmt_execute($stmt8);
				$studentResult = mysqli_stmt_get_result($stmt8);	
				$student_row = mysqli_fetch_array($studentResult, MYSQLI_ASSOC);
				
			?>
			<input type="hidden" name="candidateID" value="<?php echo htmlspecialchars($_GET['candidateID']);?>">
			
			<div class="row setup-content step activeStepInfo frm" id="step-6">
				<?php
					include("partials/forms/grievanceDetailForm.php");
				?>
			</div> 
			
		</div>
				
		<script type="text/javascript" src="../js/jquery.js"></script>
		<script type="text/javascript" src="../js/bootstrap.min.js"></script>
		<script type="text/javascript" src="../js/bootstrap-table.js"></script>		
		<script type="text/javascript" src="../js/jquery.validate.min.js"></script>
	</body>
	<script>
	$('#attachmentModal').on('click', function() {
		$('#attachmentModal').removeData('bs.modal');
	})
	$('#grievanceAssignForm').submit(function(event) {
			event.preventDefault(); // To prevent following the link (optional)
			var grievanceAssignedTo = $('select[name=grievanceAssignedTo]').val();
			var grievanceId = <?php echo $_GET['grievanceId']; ?>;
			//alert(grievanceAssignedTo);
			console.log(grievanceId+' is Grievance Id');
			
			var paramArr = $("#grievanceAssignForm").serializeArray();
			paramArr.push( {'grievanceId':grievanceId} );
			
			var grievanceComments = $("#grievanceComments").val();
			var yearOfCounselling = $("#yearOfCounselling").val();
			var hoId = '<?php echo $_SESSION['hoId']; ?>';
			var assignedTo = '<?php echo $grievance_row['grievanceAssignedTo']; ?>';
			var grievancesCreatedBy = '<?php echo $grievance_row['grievancesCreatedBy']; ?>';
			$('#grievanceMessage').html("Grievance with ID "+grievanceId+" assigned to "+grievanceAssignedTo+" successfully");
			$('#myModal').modal('show'); 
			//alert($('#grievanceAssignForm').serialize() );
			$.ajax({
				url:"operations/updateGrievance.php",
				type:"POST",
				data: $('#grievanceAssignForm').serialize() + "&grievanceId="+grievanceId, /*paramArr,{ 'grievanceId' : grievanceId, 'grievanceAssignedTo' : grievanceAssignedTo ,'grievanceComments': grievanceComments},*/
				beforeSend: function() { 
									$("#submitGrievance").prop("disabled", true); // disable button
									$("#submitGrievance").val('Saving ...');
								},
				success: function(reply){
							//console.log(reply);
							//console.log($('#grievanceStatus').val());
							
							if($.trim(reply)=='Success'){
								$("#submitGrievance").prop("disabled", false);
								$("#submitGrievance").val('Submit');
								setTimeout(function(){
								$('#myModal').modal('hide');
								if(hoId =='EGOVERNANCE'){
								if(assignedTo=='EGOVERNANCE')
								{
								var location='index.php?q=section2InProgressGrievances&q1='+assignedTo;
								}
								else if(grievancesCreatedBy=='Institute')
								{
								var location='index.php?q=section2InProgressGrievances&q1='+grievancesCreatedBy;
								}
								else
								{
								var location='index.php?q=section2InProgressGrievances&q1='+yearOfCounselling;
								}
								}
								else{
									var location='index.php?q=grievances';
								}
								window.location.href= location;
								},1500); 
								

								//$('#myModal').removeClass('show');
								//$('#myModal').modal('bs.close'); 
							}
							}
			});
	});

	</script>
</html>