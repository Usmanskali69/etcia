<?php
	session_start();
    $conn = mysql_connect("192.168.1.101","root","admin123");
    $db = mysql_select_db("jnkcounciling",$conn);
    $hoId=$_SESSION['hoId'];
	
	//$type=$_GET['type'];
    $sql = "select 
    
   s. admissionThroughCCP as AdmissionThroughCCP,
   s. studentUniqueId as Candidate_ID,
   s. studentRank as Rank,
   s.name as Candidate_Name,
    s.fatherName as Father_Name,
    s.BirthDate as Date_Of_Birth,
    s.casteCategory as Caste_Category,
    s.primaryEmailId as Email_Id,

    if(s.admissionThroughCCP = 'Yes',
        if(s.collegeUniqueId != ''
                AND s.collegeUniqueId is not null,
            (select 
                    c.name
                from
                    colleges c,
                    students st
                where
                    c.collegeUniqueId = st.collegeUniqueId
                        and st.studentUniqueId = s.studentUniqueid),
            s.otherStudentCollegeName),
        s.otherStudentCollegeName) as Institute_Name,
    if(admissionThroughCCP = 'Yes',
        if(collegeUniqueId != ''
                AND collegeUniqueId is not null,
            (select 
                    c.address
                from
                    colleges c,
                    students st
                where
                    c.collegeUniqueId = st.collegeUniqueId
                        and st.studentUniqueId = s.studentUniqueid),
            s.instituteAddress),
        s.instituteAddress) as Institute_Address,

    if(s.admissionThroughCCP = 'Yes',
        if(s.collegeUniqueId != ''
                AND s.collegeUniqueId is not null,
            (select 
                    c.state
                from
                    colleges c,
                    students st
                where
                    c.collegeUniqueId = st.collegeUniqueId
                        and st.studentUniqueId = s.studentUniqueid),
            s.instituteState),
        s.instituteState) as Institute_State,
    if(s.admissionThroughCCP = 'Yes',
        if(s.collegeUniqueId != ''
                AND s.collegeUniqueId is not null,
            (select 
                    cr.courseName
                from
                    courses cr,
                    students st
                where
                    cr.courseUniqueid = st.courseUniqueid
                        and st.studentUniqueId = s.studentUniqueid),
            s.otherStudentCourseName),
        s.otherStudentCourseName) as Course_Name,
    if(s.admissionThroughCCP = 'Yes',
        if(s.collegeUniqueId != ''
                AND s.collegeUniqueId is not null,
            s.streamAllottedIn,
            s.otherStudentStreamAppliedFor),
        s.otherStudentStreamAppliedFor) as stream,
   aa.tutionFees as Tution_Fees_Applied,
   aa.hostelFees as Hostel_Mess_Fees_Applied,
    aa.otherCharges as Other_Incidental_Charges_Applied,
    aa.bookNStationaryCharges as Book_Stationary_Charges_Applied,
   aa.approvedTutionFees as Tution_Fees_Approved,
    aa.approvedHostelFees as Hostel_Mess_Fees_Approved,
    aa.approvedBookNStationaryCharges as Book_Stationary_Charges_Approved,
   aa.approvedTotal as Total_A_B,
   s.bankName as Bank_Name,
    s.bankBranchName as Bank_Branch_Name,
    s.branchCode as Branch_Code,
    s.bankAccountNumber as Bank_Account_Number,
   s.bankifscCode as Bank_IFSC_Code,
CONCAT(aa.actualPaymentTill,'-',aa.paymentType) as Payment_Till,
    s.UIDNo as Aadhar_Number
FROM
    students s, approval_audit aa
where
s.studentUniqueId = aa.studentUniqueId 
AND aa.DBTApplicationStatus='Approved'";
	
	/*if($type=="final")
	{
	$sql.="and finalApprovedFlag = 'Y'";
	}
	else
	{
	$sql.=" and finalApprovedFlag = 'N'";
	}*/
	if($hoId!='JKCELL'){
	$yearfromHoId=substr($hoId, -7);
	$sql.="and yearOfCounselling = '".$yearfromHoId."'";
	}
	
    $rec = mysql_query($sql) or die (mysql_error());
    
    $num_fields = mysql_num_fields($rec);
    
    for($i = 0; $i < $num_fields; $i++ )
    {
        $header .= mysql_field_name($rec,$i).",";
    }
    
    while($row = mysql_fetch_assoc($rec))
    {
        $line = '';
	
		//echo var_dump($row);
        foreach($row as $key => $value)
        {    

//echo var_dump($value);
//echo $value."=".$item;

            if((!isset($value)) || ($value == ""))
            {
                $value = ",";
            }
            else
            {
                $value = str_replace( '"' , '""' , $value );
				
                
				if($key=='Bank_Account_Number' || $key=='Adhar_Number')
				{
				$value = '"\'' . $value . '"' . ",";
				
				}
				else
				{
				$value = '"' . $value . '"' . ",";
				}
				
				//echo $row['Bank_Account_Number'];
            }
            $line .= $value;
        }
        $data .= trim( $line ) . "\n";
    }
    
    $data = str_replace("\r" , "" , $data);
    
    if ($data == "")
    {
        $data = "\n No Record Found!\n";                        
    }
    
    header("Content-type: text/csv");
   header("Content-Disposition: attachment; filename=reports.csv");
  header("Pragma: no-cache");
   header("Expires: 0");
   print "$header\n$data";
mysql_close();
exit();
?>