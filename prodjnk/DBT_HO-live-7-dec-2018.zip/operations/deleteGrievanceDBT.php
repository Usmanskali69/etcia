<?php
	include('../../db_connect.php');
	
	$grievanceId = htmlspecialchars($_POST['grievanceId']);
	
	if($grievanceId !='')
	{
		//$grievanceQuery = " DELETE FROM grievance.grievances WHERE grievanceId = '".$grievanceId."'";
		//echo $grievanceQuery;
		//$result=mysqli_query($con,$grievanceQuery);
		
		$grievanceQuery = " DELETE FROM grievance.grievances WHERE grievanceId = ?";
		$stmt1 =mysqli_prepare($con, $grievanceQuery);
				mysqli_stmt_bind_param($stmt1, 'i', $grievanceId);
		$result=mysqli_stmt_execute($stmt1);
		
		if($result){
			echo 'Success';
		}else{
			echo 'Failed';
			echo mysqli_error($con);
		}
	}
	mysqli_close($con);
?>