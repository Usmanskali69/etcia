<?php
	require_once(realpath("./session/session_verify.php"));
?>

<!DOCTYPE html>
<html lang="en">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="SUVOJIT AOWN">

		<title>J&K Scholarships HO</title>

		<!-- Bootstrap Core CSS -->
		<link href="../css/bootstrap.min.css" rel="stylesheet">

		<!-- Bootstrap Table CSS -->
		<link href="../css/bootstrap-table.min.css" rel="stylesheet" >
		
		<!-- Custom Fonts -->
		<link href="../font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		
		<link href="../css/style.css" rel="stylesheet" type="text/css">
		
		
	</head>

	<body>
		<div id="header" class="navbar navbar-default navbar-fixed-top">
			<div class="navbar-header">
				<button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target=".navbar-collapse">
					<i class="fa fa-bars"></i>
				</button>
				<a class="navbar-brand" href="index.php">
					<i class="fa fa-graduation-cap fa-lg"></i> J&K Scholarships
				</a>
			</div>
			<nav class="collapse navbar-collapse">
				
				<ul class="nav navbar-nav pull-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
									<i class="fa fa-user fa-lg"></i> <?php echo $_SESSION['hoId']; ?><b class="caret"></b></a>
						<ul class="dropdown-menu pull-right">
									<li><a href="Profile.php"><i class="fa fa-user fa-fw"></i> Profile</a></li>
									<li class="divider"></li>
									<li><a href="session/auth.php?do=logout"><i class="fa fa-power-off"></i> Logout</a></li>
						</ul>
					</li>
				</ul>

			</nav>
		</div>
		<?php
			include("db_connect.php");

			// fetching Student ID from session
			$studentUniqueId= htmlspecialchars($_GET['candidateID']);
							
			//$query='SELECT * FROM students WHERE studentUniqueId="'.$studentUniqueId.'"';
			//$result = mysqli_query($con,$query);				
			
			$query='SELECT * FROM students WHERE studentUniqueId=?';
			$stmt1 = mysqli_prepare($con, $query);
			mysqli_stmt_bind_param($stmt1, 'i', $studentUniqueId);
			mysqli_stmt_execute($stmt1);
			$result = mysqli_stmt_get_result($stmt1);

			$user_row = mysqli_fetch_array($result, MYSQLI_ASSOC);
			
			/* $query2='SELECT total FROM approval_audit WHERE studentUniqueId="'.$studentUniqueId.'"';
			$result2 = mysqli_query($con,$query2);
			$user_row2 = mysqli_fetch_array($result2, MYSQLI_ASSOC); */
			
			$query2='SELECT total FROM approval_audit WHERE studentUniqueId=?';
			$stmt2 = mysqli_prepare($con, $query2);
			mysqli_stmt_bind_param($stmt2, 'i', $studentUniqueId);
			mysqli_stmt_execute($stmt2);
			$result2 = mysqli_stmt_get_result($stmt2);

			$user_row2 = mysqli_fetch_array($result2, MYSQLI_ASSOC);
				
		?>
		
		<br/>	
		<form id="speciallyApproveOrReject" class="form-horizontal" role="form" method="post" enctype="multipart/form-data">
			<input hidden name="category" id="category" value="<?php echo $college_row['category'];?>"/>
			<input hidden name="stream" id="stream" value="<?php echo $user_row['otherStudentStreamAppliedFor'];?>"/>
			<input hidden name="admissionThroughCCP" id="admissionThroughCCP" value="<?php echo $user_row['admissionThroughCCP'];?>"/>
			<input hidden name="yearOfCounselling" id="yearOfCounselling" value="<?php echo $user_row['yearOfCounselling'];?>"/>
			<div class="container" style="background-color: #FFD6A1">
				
				<div class="panel-body">
							<div class="col-sm-12" role="complementary">
								<div class="panel panel-default">
									<div class="panel-body table-responsive">
									
									<table class="table table-bordered table-condensed f11">
										<tr>
											<td colspan="4" align="center" class="danger" style="background-color: #FFD6A1"><b>Details</b></td>
										</tr>
										
										<tr>
											<td  align="left" width="20%"><b>Candidate Id :</b></td>
											<td  align="left"><input type="hidden" id="candidateID" name="candidateID" value="<?php echo $user_row['studentUniqueId'];?>"/><?php echo $user_row['studentUniqueId'];?></td>
										</tr>										
										<tr>
											<td align="left" width="20%"><b>Candidate Name:</b></td>
											<td align="left"> <?php if($user_row['speciallyAllowedFlag']=='Y'){ echo $user_row['name']; }else{echo $user_row['firstName'];?>&nbsp;<?php echo $user_row['middleName'];?>&nbsp;<?php echo $user_row['lastName'];}?></td>
										</tr>
										<tr>
											<td align="left" width="20%"><b>College Name:</b></td>
											<td align="left"><?php echo $user_row['OtherStudentCollegename'];?></td>
										</tr>
										<tr>
											<td align="left" width="20%"><b>Father Name:</b></td>
											<td align="left"><?php echo $user_row['fatherName'];?></td>
										</tr>
										<tr>
											<td align="left" width="20%"><b>Institute State:</b></td>
											<td align="left"><?php echo $user_row['instituteState'];?></td>
										</tr>
										<tr>
											<td align="left" width="20%"><b>Caste Category:</b></td>
											<td align="left"><?php echo $user_row['casteCategory'];?></td>
										</tr>
					
										<tr>
											<td align="left" width="20%"><b>Category:</b></td>
											<td align="left"><?php echo $user_row['otherStudentStreamAppliedFor'];?></td>
										</tr>
										<tr>
											<td align="left" width="20%"><b>Course:</b></td>
											<td align="left"><?php echo $user_row['OtherStudentCourseName'];?></td>
										</tr>
										<tr>
											<td align="left" width="20%"><b>Amount:</b></td>
											<td align="left"><?php echo $user_row2['total'];?></td>
										</tr>
										<tr>
											<!--<td align="left" width="20%"><b>Attachment:</b></td>
											<td align="left"><?php //echo $user_row['joiningReport'];?></td>-->
											<td align="left" width="20%"><b>Joining Report:</b></td>
											<td align="left"><a href="speciallyAllowedModal.php?type=joiningReport&studentId=<?php echo $user_row['studentUniqueId'];?>" data-toggle="modal" data-target="#attachmenModal"><h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'></span></h4></a></td>
										</tr>
									</table>
									</div>
								</div>								
							</div>
						</div>
						<div  class="col-lg-offset-1 col-lg-6" id="speciallyAllowedApproveOrRejectMessage">
						</div>
						
					<div class="col-lg-2">
						<button class="btn btn-success btn-block" id='speciallyAllowedApprove'> Approve</button>
					</div>
					<div class="col-lg-2">
						<button class="btn btn-danger btn-block" id='speciallyAllowedReject'>Reject</button><br/>
					</div>
			</div>
		</form>
		
		<script type="text/javascript" src="../js/jquery.js"></script>
		<script type="text/javascript" src="../js/jquery.validate.min.js"></script>
		<script type="text/javascript" src="../js/bootstrap.min.js"></script>
		<script type="text/javascript" src="../js/bootstrap-table.js"></script>
		<script type="text/javascript" src="js/validation.js"></script>
		<script type="text/javascript" src="js/custom.js"></script>
		
		<div class="modal fade bs-example-modal-lg" id="attachmenModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" >
		  <div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
			  
			</div>
		  </div>
		</div>	
		
		<?php mysqli_close ($con); ?>
		
	</body>
</html>