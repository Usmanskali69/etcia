<div class="page-header">
	<h3>Approved Application List</h3>
	</br>
	<div align="right">
			<a href="./partials/ajax/getExportedData.php"  class="btn btn-primary">Export Data</a>
			</div>
</div>
<table id="table1" data-toggle="table" data-url="partials/data/ApprovedApplication.php" data-show-export="true" data-cache="false" data-height="420" data-sort-name="Approval_Date" data-sort-order="asc" data-show-columns="true" data-show-refresh="true" data-search="true" data-select-item-name="toolbar1" data-striped="true" data-pagination="true" data-side-pagination="client" data-page-list="[5, 10, 20, 50, 100, 200]">
	<thead>
		<tr>
			<th data-field="Approval_Date" data-visible="true" data-sortable="true" >Approval Date/Time</th>
			<!--<th data-field="Submission_Date" data-visible="true" data-sortable="true" >Submission Date/Time</th>-->
			<th data-field="AdmissionThroughCCP" data-visible="true" data-sortable="true" >Admission Through CCP</th>
			<th data-field="Candidate_Id" data-visible="true" data-sortable="true" >Candidate ID</th>
			<!--<th data-field="Candidate_Rank" data-visible="true" data-sortable="true" >Candidate Rank</th>-->
			<th data-field="yearOfCounselling" data-visible="true" data-sortable="true" >Year Of Counselling</th>
			<th data-field="Candidate_Name" data-sortable="true" data-switchable="false">Candidate Name</th>
			<th data-field="Payment_Till" data-sortable="true" data-switchable="false">Payment Till</th>
			<th data-field="Father_Name" data-sortable="true" data-switchable="false">Father Name</th>
			<th data-field="DOB" data-sortable="true" data-switchable="false">Date of Birth</th>
			<th data-field="Caste_Category" data-sortable="true" data-switchable="false">Caste Category</th>
			<!--<th data-field="EmailId" data-sortable="true" data-switchable="false">Email Id</th>-->
			<th data-field="College_Name" data-sortable="true" data-switchable="false">College Name</th>
			<!--<th data-field="College_Address" data-sortable="true" data-switchable="false">College Address</th>-->
			<th data-field="College_State" data-sortable="true" data-switchable="false">College State</th>
			<th data-field="Course_Name" data-sortable="true" data-switchable="false">Course Name</th>
			<th data-field="Candidate_Category" data-visible="true">Category</th>
			<!--<th data-field="Tution_Applied" data-sortable="true" data-switchable="false">Tution_Fees_Applied</th>
			<th data-field="Hostel_Applied" data-sortable="true" data-switchable="false">Hostel & Mess Fees Applied</th>
			<th data-field="Other_Charges_Applied" data-sortable="true" data-switchable="false">Other Incidental Charges Applied</th>
			<th data-field="Book_Stationary_Applied" data-sortable="true" data-switchable="false">Book & Stationary Charges Applied</th>
			<th data-field="Tution_Approved" data-sortable="true" data-switchable="false">Tution Fees Approved</th>
			<th data-field="Hostel_Approved" data-sortable="true" data-switchable="false">Hostel & Mess Fees Approved</th>
			<th data-field="Other_Charges_Approved" data-sortable="true" data-switchable="false">Other Incidental Charges Approved</th>
			<th data-field="Book_Stationary_Approved" data-sortable="true" data-switchable="false">Book & Stationary Charges Approved</th>
			<th data-field="Total" data-sortable="true" data-switchable="false">Total of (A) & (B)</th>
			<th data-field="Bank_Name" data-sortable="true" data-switchable="false">Bank Name</th>
			<th data-field="Branch_Name" data-sortable="true" data-switchable="false">Bank Branch Name</th>
			<th data-field="Branch_Code" data-sortable="true" data-switchable="false">Branch Code</th>
			<th data-field="Bank_AC_No" data-sortable="true" data-switchable="false">Bank A/c No.</th>
			<th data-field="Bank_IFSC_Code" data-sortable="true" data-switchable="false">Bank IFSC Code</th>
			<th data-field="UID_No" data-sortable="true" data-switchable="false">Aadhar Card No</th>
			<th data-field="Candidate_Status" data-visible="true">Current Status</th>-->
			
			<th data-field="edit_delete" data-formatter="operateFormatterVerified1" data-events="operateEvents">Edit</th>
			
		</tr>
	</thead>
</table>

