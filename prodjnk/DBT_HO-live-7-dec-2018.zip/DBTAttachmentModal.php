<?php
include('db_connect.php');
include("../mpdf60/mpdf.php");
$type=htmlspecialchars($_GET['type']);
$studentId  = htmlspecialchars($_GET['studentId']);

	//$query = "SELECT * FROM students where studentUniqueId = '".$studentId."'";
	//$result = mysqli_query($con,$query);
	
	$query = "SELECT * FROM students where studentUniqueId =?";
	$stmt1 = mysqli_prepare($con, $query);
				mysqli_stmt_bind_param($stmt1, 'i', $studentId);
				mysqli_stmt_execute($stmt1);
				$result = mysqli_stmt_get_result($stmt1);
	$user_row = mysqli_fetch_array($result, MYSQLI_ASSOC);
	
	//$query1="SELECT otherStudentCollegename,otherStudentCourseName,otherStudentUniversity,otherStudenttypeOfInstitute FROM students WHERE studentUniqueId='".$studentId."'";
	//echo $query;
	//$result1 = mysqli_query($con,$query1);
	
	$query1="SELECT otherStudentCollegename,otherStudentCourseName,otherStudentUniversity,otherStudenttypeOfInstitute FROM students WHERE studentUniqueId=?";
	$stmt2 = mysqli_prepare($con, $query1);
				mysqli_stmt_bind_param($stmt2, 'i', $studentId);
				mysqli_stmt_execute($stmt2);
				$result1 = mysqli_stmt_get_result($stmt2);
	$user_row1 = mysqli_fetch_array($result1, MYSQLI_ASSOC);


	//$collegequery="SELECT * FROM colleges where collegeUniqueId='".$user_row['collegeUniqueId']."'";
	//$collegeresult = mysqli_query($con,$collegequery);
	
	$collegequery="SELECT * FROM colleges where collegeUniqueId=?";
	$stmt3 = mysqli_prepare($con, $collegequery);
				mysqli_stmt_bind_param($stmt3, 'i', $user_row['collegeUniqueId']);
				mysqli_stmt_execute($stmt3);
				$collegeresult = mysqli_stmt_get_result($stmt3);
	$college_row = mysqli_fetch_array($collegeresult, MYSQLI_ASSOC);

	//$coursequery="SELECT * FROM courses where courseUniqueId='".$user_row['courseUniqueId']."'";
	//$courseresult = mysqli_query($con,$coursequery);
	
	$coursequery="SELECT * FROM courses where courseUniqueId=?";
	$stmt4 = mysqli_prepare($con, $coursequery);
				mysqli_stmt_bind_param($stmt4, 'i', $user_row['courseUniqueId']);
				mysqli_stmt_execute($stmt4);
				$courseresult = mysqli_stmt_get_result($stmt4);
	$course_row = mysqli_fetch_array($courseresult, MYSQLI_ASSOC);

	$joiningReport=$user_row['joiningReport'];
	$feeReceipt=$user_row['feeReceipt'];
	$bookReceipt=$user_row['bookReceipt'];
	$bankPassBook=$user_row['bankPassBook'];
	$rentReceipt=$user_row['rentReceipt'];
	$aadharCard=$user_row['aadharCard'];
	$collegehostelReceipt=$user_row['collegehostelReceipt'];
	$otherIncidentalCharges=$user_row['otherIncidentalChargesReceipt'];
	$joiningtutionhostelReceipt = $user_row['joiningtutionhostelReceipt'];
	$hscmarksheet = $user_row['hscmarksheetfile'];
	$sscmarksheet = $user_row['sscmarksheetfile'];
echo '<div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
        if($type=='joiningReport')
		{	
		//echo $type;
			echo '<h4 class="modal-title" id="myModalLabel">Joining Report</h4><div class="panel panel-default">
						<div class="panel-body table-responsive">
						<table class="table table-bordered table-condensed f11">
							<tr>
								<td colspan="4" align="center" class="danger"><b>Institute Details:</b></td>
							</tr>
							
							
							<tr>
								<td width="20%" align="left"><font color="Red"><b>Institute ID:</b></font></td>
								<td width="30%" align="left">';
								
								
								if($user_row['admissionThroughCCP']=='Yes')
								{
								if($user_row['yearOfCounselling']=='2015-16')
								{
									echo $user_row['collegeUniqueId'];
								}
								else
								{
									echo $user_row['otherStudentCollegeId'];
								}
								} 
								else 
								{ 
								echo $user_row['otherStudentCollegeId'];
								}
								
								echo'</td>
								<td width="20%" align="left"><font color="Red"><b>Institute Name:</b></font></td>
								<td width="30%" align="left">';
								if($user_row['admissionThroughCCP']=='Yes')
								{ 
								if($user_row['yearOfCounselling']=='2015-16')
								{
									echo $user_row['name'];
								}
								else
								{
									echo $user_row1['otherStudentCollegename'];
								}
								} 
								else 
								{ 
								echo $user_row1['otherStudentCollegename'];
								}
								echo'</td>
							</tr>
							
							<tr>
								<td width="20%" align="left"><font color="Red"><b>Course Name:</b></font></td>
								<td width="30%" align="left">';
								if($user_row['admissionThroughCCP']=='Yes')
								{ 
								
								if($user_row['yearOfCounselling']=='2015-16')
								{
									echo $course_row['courseName'];
								}
								else
								{
									echo $user_row1['otherStudentCourseName'];
								}
								}
								else 
								{ 
								echo $user_row1['otherStudentCourseName'];
								}
								echo'</td>
								
								<td width="20%" align="left"><b>Affiliating University:</b></td>
								<td width="30%" align="left">';
								if($user_row['admissionThroughCCP']=='Yes')
								{ 
								if($user_row['yearOfCounselling']=='2015-16')
								{
									echo $course_row['university'];
								}
								else
								{
									echo $user_row1['otherStudentUniversity'];
								}
								
								} 
								else { echo $user_row1['otherStudentUniversity'];}
								echo'</td>
								
								
							</tr>
							
							
							
							
						</table>					
						</div>
						</div>';
		}
		if($type=='feeReceipt')
		{
			//echo $type;
			echo '<h4 class="modal-title" id="myModalLabel">Fee Receipt</h4><div class="panel panel-default">
						<div class="panel-body table-responsive">
							<table class="table table-bordered table-condensed f11"><tr>
									<td  colspan="2" align="center" class="danger"><b>Fee Details:</b></td>
								</tr><tr>
								<td width="20%" align="left"><font color="Red"><b>Tution Fee:</b></font></td>
								<td width="15%" align="left">'.$user_row['tutionFees'].'</td></tr></table>								
						</div>	
					</div>';
		}if($type=='bookReceipt')
		{
			//echo $type;
			echo '<h4 class="modal-title" id="myModalLabel">Book Receipt</h4><div class="panel panel-default">
						<div class="panel-body table-responsive">
							<table class="table table-bordered table-condensed f11"><tr>
									<td  colspan="2" align="center" class="danger"><b>Book Fee Details:</b></td>
								</tr><tr>
								<td width="20%" align="left"><font color="Red"><b>Books & Stationary:</b></font></td>
								<td width="15%" align="left">'.$user_row['bookNStationaryCharges'].'</td></tr></table>								
						</div>	
					</div>';
		}if($type=='rentReceipt')
		{
			//echo $type;
			echo '<h4 class="modal-title" id="myModalLabel">Rent Receipt</h4><div class="panel panel-default">
						<div class="panel-body table-responsive">
							<table class="table table-bordered table-condensed f11"><tr>
									<td colspan="2" align="center" class="danger"><b>Hostel/Rent Charges</b></td>
								</tr><tr>
								<td width="20%" align="left"><font color="Red"><b>Hostel/Rent Charges:</font></b></td>
								<td width="15%" align="left">'.$user_row['hostelFees'].'</td></tr></table>								
						</div>	
					</div>';
		}if($type=='bankPassBook')
		{
			//echo $type;
			echo '<h4 class="modal-title" id="myModalLabel">Bank Pass Book</h4><div class="panel panel-default">
						<div class="panel-body table-responsive">
							<table class="table table-bordered table-condensed f11">
								<tr>
									<td colspan="4" align="center" class="danger"><b>Bank Details:</b></td>
								</tr>
								
								<tr>
									<td width="20%" align="left"><font color="Red"><b>Account Holder Name(Candidate):</b></font></td>
									<td width="30%" align="left">'.$user_row['accountHolderName'].'</td>
									<td width="20%" align="left"><font color="Red"><b>Bank Name:</b></font></td>
									<td width="30%" align="left">'.$user_row['bankName'].'</td>
								</tr>
								
									<td width="20%" align="left"><font color="Red"><b>Bank IFSC Code:</b></font></td>
									<td width="30%" align="left">'.$user_row['bankifscCode'].'</td>
									<td width="20%" align="left"><font color="Red"><b>Bank Account Number:</b></font></td>
									<td width="30%" align="left">'.$user_row['bankAccountNumber'].'</td>
								</tr>
												
								
								
								
							</table>								
						</div>	
					</div>';
		}if($type=='aadharCard')
		{
			//echo $type;
			echo '<h4 class="modal-title" id="myModalLabel">Aadhar Card</h4><div class="panel panel-default">
						<div class="panel-body table-responsive">
							<table class="table table-bordered table-condensed f11"><tr>
									<td align="center" colspan="2" class="danger"><b>Aadhar Card Details:</b></td>
								</tr><tr>
								<td width="20%" align="left"><font color="Red"><b>Aadhar Card Number:</b></font></td>
								<td width="15%" align="left">'.$user_row['UIDNo'].'</td></tr></table>								
						</div>	
					</div>';
		}
		if($type=='collegehostelReceipt')
		{
			//echo $type;
			echo '<h4 class="modal-title" id="myModalLabel">Hostel Receipt</h4><div class="panel panel-default">
						<div class="panel-body table-responsive">
							<table class="table table-bordered table-condensed f11"><tr>
									<td colspan="2" align="center" class="danger"><b>Hostel/Rent Charges</b></td>
								</tr><tr>
								<td width="20%" align="left"><font color="Red"><b>Hostel/Rent Charges:</font></b></td>
								<td width="15%" align="left">'.$user_row['hostelFees'].'</td></tr></table>								
						</div>	
					</div>';
		}
		if($type=='otherIncidentalCharges')
		{
			//echo $type;
			echo '<h4 class="modal-title" id="myModalLabel">Other Incidental Charges Receipt</h4><div class="panel panel-default">
						<div class="panel-body table-responsive">
							<table class="table table-bordered table-condensed f11"><tr>
									<td colspan="2" align="center" class="danger"><b>Other Incidental Charges</b></td>
								</tr><tr>
								<td width="20%" align="left"><font color="Red"><b>Other Incidental Charges:</font></b></td>
								<td width="15%" align="left">'.$user_row['otherCharges'].'</td></tr></table>								
						</div>	
					</div>';
		}
		if($type=='JoiningTutionHostelReceipt')
		{
			echo '<h4 class="modal-title" id="myModalLabel">Joining Report/Tuition Fee Receipt/Hostel Fee Receipt</h4>';
			/*<div class="panel panel-default">
						/*<div class="panel-body table-responsive">
							<table class="table table-bordered table-condensed f11"><tr>
									<td colspan="2" align="center" class="danger"><b>Joining Report/Tuition Fee Receipt/Hostel Fee Receipt</b></td>
								</tr><tr>
								<td width="20%" align="left"><font color="Red"><b>Joining Report/Tuition Fee Receipt/Hostel Fee Receipt:</font></b></td>
								<td width="15%" align="left">'.$user_row['joiningtutionhostelReceipts'].'</td></tr></table>								
						</div>	
					</div>'*/
		}
		if($type=='HscMarksheet')
		{
			echo '<h4 class="modal-title" id="myModalLabel">HSC Marksheet</h4>';
			/*<div class="panel panel-default">
						<div class="panel-body table-responsive">
							<table class="table table-bordered table-condensed f11"><tr>
									<td colspan="2" align="center" class="danger"><b>HSC Marksheet</b></td>
								</tr><tr>
								<td width="20%" align="left"><font color="Red"><b>HSC Marksheet:</font></b></td>
								<td width="15%" align="left">'.$user_row['hscmarksheetfile'].'</td></tr></table>								
						</div>	
					</div>';*/
		}
		if($type=='SscMarksheet')
		{
			echo '<h4 class="modal-title" id="myModalLabel">SSC Marksheet</h4>';
			/*<div class="panel panel-default">
						<div class="panel-body table-responsive">
							<table class="table table-bordered table-condensed f11"><tr>
									<td colspan="2" align="center" class="danger"><b>SSC Marksheet</b></td>
								</tr><tr>
								<td width="20%" align="left"><font color="Red"><b>SSC Marksheet:</font></b></td>
								<td width="15%" align="left">'.$user_row['sscmarksheetfile'].'</td></tr></table>								
						</div>	
					</div> */
		}
     echo'</div>
			<div class="modal-body" style="height:400px;overflow-y: auto;">';
	
		if($type=='joiningReport' &&($joiningReport!=null && $joiningReport!=''))
		{	//echo $type;
			$imageFileType = pathinfo($joiningReport,PATHINFO_EXTENSION);
		 
			if($imageFileType=='pdf' || $imageFileType=='PDF' || $imageFileType=='Pdf')
			{		
					echo "<object height='400' data='../jk_media/".$joiningReport."' type='application/pdf' width='860'></object>";
					echo "<br>";
					}
					else
					{
					echo "<img src='../jk_media/".$joiningReport."' style='width:850px'>";
					
		
					echo "<br>";
					}
		}
		else if($type=='feeReceipt' && ($feeReceipt!=null && $feeReceipt!=''))
		{	//echo $type;
			$imageFileType = pathinfo($feeReceipt,PATHINFO_EXTENSION);
			if($imageFileType=='pdf' || $imageFileType=='PDF' || $imageFileType=='Pdf')
			{
					echo "<object height='400' data='../jk_media/".$feeReceipt."' type='application/pdf' width='860'></object>";
					echo "<br>";
					}
					else{
			echo "<img src='../jk_media/".$feeReceipt."' style='width:850px'>";
					echo "<br>";
					}
		}
		else if($type=='bookReceipt' && ($bookReceipt!=null && $bookReceipt!=''))
		{//echo $type;
		$imageFileType = pathinfo($bookReceipt,PATHINFO_EXTENSION);
			if($imageFileType=='pdf' || $imageFileType=='PDF' || $imageFileType=='Pdf')
			{
					echo "<object height='400' data='../jk_media/".$bookReceipt."' type='application/pdf' width='860'></object>";
					echo "<br>";
					}
					else{
			echo "<img src='../jk_media/".$bookReceipt."' style='width:850px'>";
					echo "<br>";
					}
		}
		else if($type=='rentReceipt' && ($rentReceipt!=null && $rentReceipt!=''))
		{//echo $type;
		$imageFileType = pathinfo($rentReceipt,PATHINFO_EXTENSION);
			if($imageFileType=='pdf' || $imageFileType=='PDF' || $imageFileType=='Pdf')
			{
					echo "<object height='400' data='../jk_media/".$rentReceipt."' type='application/pdf' width='860'></object>";
					echo "<br>";
					}
					{
			echo "<img src='../jk_media/".$rentReceipt."' style='width:850px'>";
					echo "<br>";
					}
		}
		else if($type=='bankPassBook' && ($bankPassBook!=null && $bankPassBook!=''))
		{//echo $type;
		$imageFileType = pathinfo($bankPassBook,PATHINFO_EXTENSION);
			if($imageFileType=='pdf' || $imageFileType=='PDF' || $imageFileType=='Pdf')
			{
					echo "<object height='400' data='../jk_media/".$bankPassBook."' type='application/pdf' width='860'></object>";
					echo "<br>";
					}
					else{
			echo "<img src='../jk_media/".$bankPassBook."' style='width:850px'>";
					echo "<br>";
					}
		}
		else if($type=='aadharCard' && ($aadharCard!=null && $aadharCard!=''))
		{//echo $type;
		$imageFileType = pathinfo($aadharCard,PATHINFO_EXTENSION);
			if($imageFileType=='pdf' || $imageFileType=='PDF' || $imageFileType=='Pdf')
			{
					echo "<object height='400' data='../jk_media/".$aadharCard."' type='application/pdf' width='860'></object>";
					echo "<br>";
					}
					else{
			echo "<img src='../jk_media/".$aadharCard."' style='width:850px'>";
					echo "<br>";}
		}
		else if($type=='collegehostelReceipt' && ($collegehostelReceipt!=null && $collegehostelReceipt!=''))
		{
			//echo $type;
			$imageFileType = pathinfo($collegehostelReceipt,PATHINFO_EXTENSION);
			if($imageFileType=='pdf' || $imageFileType=='PDF' || $imageFileType=='Pdf')
			{
					echo "<object height='400' data='../jk_media/".$collegehostelReceipt."' type='application/pdf' width='860'></object>";
					echo "<br>";
					}
					else{
			echo "<img src='../jk_media/".$collegehostelReceipt."' style='width:850px'>";
					echo "<br>";}
		}
		else if($type=='otherIncidentalCharges' && ($otherIncidentalCharges!=null && $otherIncidentalCharges!=''))
		{
			//echo $type;
			$imageFileType = pathinfo($otherIncidentalCharges,PATHINFO_EXTENSION);
			if($imageFileType=='pdf' || $imageFileType=='PDF' || $imageFileType=='Pdf')
			{
					echo "<object height='400' data='../jk_media/".$otherIncidentalCharges."' type='application/pdf' width='860'></object>";
					echo "<br>";
					}
					else{
			echo "<img src='../jk_media/".$otherIncidentalCharges."' style='width:850px'>";
					echo "<br>";
					}
		}elseif($type=='JoiningTutionHostelReceipt' && ($joiningtutionhostelReceipt!=null && $joiningtutionhostelReceipt!='')){
			$imageFileType = pathinfo($joiningtutionhostelReceipt,PATHINFO_EXTENSION);
			if($imageFileType=='pdf' || $imageFileType=='PDF' || $imageFileType=='Pdf'){
				echo "<object height='400' data='../jk_media/".$joiningtutionhostelReceipt."' type='application/pdf' width='860'></object>";
				echo "<br/>";
			}else{
				echo "<img src='../jk_media/".$joiningtutionhostelReceipt."' style='width:850px'>";
				echo "<br/>";
			}
		}elseif($type=='HscMarksheet' && ($hscmarksheet!=null && $hscmarksheet!='')){
			$imageFileType = pathinfo($hscmarksheet,PATHINFO_EXTENSION);
			if($imageFileType=='pdf' || $imageFileType=='PDF' || $imageFileType=='Pdf'){
				echo "<object height='400' data='../jk_media/".$hscmarksheet."' type='application/pdf' width='860'></object>";
				echo "<br/>";
			}else{
				echo "<img src='../jk_media/".$hscmarksheet."' style='width:850px'>";
				echo "<br/>";
			}
		}elseif($type=='SscMarksheet' && ($sscmarksheet!=null && $sscmarksheet!='')){
			$imageFileType = pathinfo($sscmarksheet,PATHINFO_EXTENSION);
			if($imageFileType=='pdf' || $imageFileType=='PDF' || $imageFileType=='Pdf'){
				echo "<object height='400' data='../jk_media/".$sscmarksheet."' type='application/pdf' width='860'></object>";
				echo "<br/>";
			}else{
				echo "<img src='../jk_media/".$sscmarksheet."' style='width:850px'>";
				echo "<br/>";
			}
		}
		else
		{
			echo "<b><font size='5' color='Red'>File not uploaded</font></b>";
		}
		
echo '</div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
      </div>';
?>