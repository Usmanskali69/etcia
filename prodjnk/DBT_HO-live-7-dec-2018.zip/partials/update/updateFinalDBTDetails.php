<?php
session_start();
include('../../db_connect.php');
include('../../../mailer.php');
$type =$_GET["type"];
$disclaimer =$_GET["disclaimer"];
$comments =$_GET["comments"];
$declaration =$_GET["declaration"];
$candidateID		=$_GET["candidateID"];
$paymentType =$_GET["paymentType"];
$approvedTutionFees =$_GET["approvedTutionFees"];
$approvedHostelFees =$_GET["approvedHostelFees"];
$approvedBookNStationaryCharges =$_GET["approvedBookNStationaryCharges"];
$approvedOtherCharges =$_GET["approvedOtherCharges"];
$approvedTotalB =$_GET["approvedTotalB"];
$approvedTotal =$_GET["approvedTotal"];
$newPaymentType =$_GET["newPaymentType"];
$approvalOrRejectionComment =mysqli_real_escape_string($con, $_GET["approvalOrRejectionComment"]);
$now = new DateTime();
$now = $now->format('Y-m-d H:i:s');
$studentQuery="SELECT * from students where studentUniqueId=".$candidateID;
//echo $studentQuery;
$studentResult = mysqli_query($con, $studentQuery)or die("Query Failed");
$student_row = mysqli_fetch_array($studentResult);
if($student_row['approvalFlag']=='Y' && $student_row['isScholarshipCompleted']!='Y')
{
	if($student_row['DBTApplicationStatus']=='Submitted' && $type=='finalApprove' ){
		
		$query="UPDATE students 
					SET disclaimer='".$disclaimer."',
						approvedTutionFees='".$approvedTutionFees."',
						approvedHostelFees='".$approvedHostelFees."',
						approvedBookNStationaryCharges='".$approvedBookNStationaryCharges."',
						approvedOtherCharges='".$approvedOtherCharges."',
						approvedTotalB='".$approvedTotalB."',
						approvedTotal='".$approvedTotal."',
						approvalOrRejectionComment='".$approvalOrRejectionComment."',
						DBTApplicationStatus='Approved',
						DBTStatusChangedBy='".$_SESSION['hoId']."',
						approvalFlag='Y',
						finalApprovedFlag='Y',
						isXIIMarksheetVerified='".$newPaymentType."',
						finalApprovalDate='".$now."'
					WHERE
						studentUniqueId='".$candidateID."'";
						$result = mysqli_query($con, $query) or die("Query Failed");
		//echo $query;
		
	}
	else if(($student_row['DBTApplicationStatus']=='Submitted' || $student_row['DBTApplicationStatus']=='Approved')  && $type=='ApproveAndCompleteScholarship')
	{
	          $query="UPDATE students 
					SET disclaimer='".$disclaimer."',
						approvedTutionFees='".$approvedTutionFees."',
						approvedHostelFees='".$approvedHostelFees."',
						approvedBookNStationaryCharges='".$approvedBookNStationaryCharges."',
						approvedOtherCharges='".$approvedOtherCharges."',
						approvedTotalB='".$approvedTotalB."',
						approvedTotal='".$approvedTotal."',
						approvalOrRejectionComment='".$approvalOrRejectionComment."',
						DBTApplicationStatus='Approved',
						DBTStatusChangedBy='".$_SESSION['hoId']."',
						approvalFlag='Y',
						finalApprovedFlag='Y',
						isXIIMarksheetVerified='".$newPaymentType."',
						finalApprovalDate='".$now."',
						isScholarshipCompleted='".$declaration."',
						completedScholarshipComments='".$comments."',
						scholarshipCompletionDate='".$now."'
					WHERE
						studentUniqueId='".$candidateID."'";
					$result = mysqli_query($con, $query) or die("Query Failed");
					//echo $query;
	    
	}
	
	if($result)
	{
		$recipients = $student_row['primaryEmailId'];
			
			$subject = "J&K Scholarship Application for DBT has been submitted successfully";
			$body ="Hello ".$student_row['firstName']." ".$student_row['lastName'].", <br/> <br/>
			
			Your Application for J&K Scholarship scheme for Direct Benefit Transfer (DBT) has been approved successfully. <br/> <br/>
			
			Regards,<br/>
			J&K Scholarship Support Team<br/>
			jkadmission2015@aicte-india.org
			<br/><br/>
			<hr/>
			This is an auto-generated email message, please do not reply directly as we will not be able to answer. If you need to contact us, please send us an e-mail to jkadmission2015@aicte-india.org.";
			$altBody= "";
			$s=true;
			//$s= sendMail($recipients, $subject, $body, $altBody,5);
			if($s)
			{	//echo $recipients;
				echo "success";
			}
	}
	else
	{
		echo "failure";
	}
	}
	else
	{
		echo $student_row['DBTApplicationStatus'];
	}
?>