<?php
include('db_connect.php');
$semPass=$_GET['semPass'];
$studentId  = $_GET['studentId'];
$semPass1= str_split($semPass);
$semPass2= $semPass1[0].$semPass1[1].$semPass1[2].' '.$semPass1[3].$semPass1[4].$semPass1[5].$semPass1[6].$semPass1[7].$semPass1[8];
$semPass3=trim($semPass2,"");
echo '<div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
       echo '<h4 class="modal-title">'.$semPass3.' MarkSheet</h4>';
     echo'</div>
			<div class="modal-body" style="height:400px;overflow-y: auto;">';
	$AYquery="select * from academic_year_record where studentUniqueId='".$studentId."' and semester='".$semPass3."'";
	//echo $AYquery;
	$AYresult = mysqli_query($con, $AYquery) or die('Query Failed');
	$AY_row=mysqli_fetch_array($AYresult);
	//echo mysqli_num_rows($AYresult);
	$attachment=$AY_row['attachment'];
	//echo $percentage.'avc';
	$imageFileType = pathinfo($attachment,PATHINFO_EXTENSION);
			if($attachment!='' && $attachment!=null)
			{
			if($imageFileType=='pdf' || $imageFileType=='PDF' || $imageFileType=='Pdf')
			{
					echo "<object height='400' data='../jk_media/".$attachment."' type='application/pdf' width='100%'></object>";
					echo "<br>";
					}
					else
					{
					echo "<img src='../jk_media/".$attachment."' style='width:100%;height:100%'>";
					
					echo "<br>";
					}
					}
					else
					{
						echo "<b><font size='5' color='Red'>File not uploaded</font></b>";
					}
echo '</div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
      </div>';
?>