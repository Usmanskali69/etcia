$(document).ready(function() {

$('#markLeftForm').submit(function(event) {
		$("#personalSaveMessage1").html('');
		$("#personalSaveMessage1").css({"display":"inline","opacity":"100"});
        // process the form
		$.ajax({
				type: 'GET', // define the type of HTTP verb we want to use (POST for our form)
				url: 'partials/update/updateStudentLeftCounsellingDetail.php', // the url where we want to POST
				data: $("#markLeftForm").serialize(), // our data object
				//encode: true
				beforeSend: function() { 
								$("#SaveButton").prop("disabled", true); // disable button
								$("#SaveButton").val('Saving ...');
								
			},
			success:function(data) {
			
				var reply = data.replace(/\s+/, ""); 
				// log data to the console so we can see
				console.log(data);
				if (reply == 'Success'){
				$("#SaveButton").val('Save');
				$("#SaveButton").prop("disabled", false); // enable button
				$("#personalSaveMessage1").html("Successfully Saved Details").fadeTo(4000,0);
				// here we will handle errors and validation messages
				$("#table1").bootstrapTable('refresh', {
    			url: 'partials/data/presentStudent.php'});
				return false;
								}
			}
			
			});
			event.preventDefault();

		// stop the form from submitting the normal way and refreshing the page
		event.preventDefault();
        
    });


});