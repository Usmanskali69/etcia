<?php
    session_start();
	include('../../db_connect.php');
	$grievanceCreatedById=htmlspecialchars($_GET['id']);
	if(isset($_SESSION['hoId']) && !empty($_SESSION['hoId']))
    {
	//$query="Select grievanceId,grievanceStatus,grievanceNature,grievanceSubject,grievanceDescription,grievanceCreatedOn,grievancesCreatedBy from grievance.grievances WHERE grievanceCreatedById = '".$grievanceCreatedById."' ORDER BY grievanceId DESC  ";
	//echo $query;
	//$result=mysqli_query($con,$query);
	
	$query="Select grievanceId,grievanceStatus,grievanceNature,grievanceSubject,grievanceDescription,grievanceCreatedOn,grievancesCreatedBy from grievance.grievances WHERE grievanceCreatedById = ? ORDER BY grievanceId DESC  ";
	$stmt1 = mysqli_prepare($con, $query);
	mysqli_stmt_bind_param($stmt1, 's', $grievanceCreatedById);
	mysqli_stmt_execute($stmt1);
	$result = mysqli_stmt_get_result($stmt1);
	
	$rows = array();
	$grievanceData = array();
	while($data = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
	
		$rows['grievanceId']=$data['grievanceId'];
		$rows['grievanceNature']=$data['grievanceNature'];
		$rows['grievanceSubject']=$data['grievanceSubject'];
		$rows['grievancesCreatedBy']=$data['grievancesCreatedBy'];
		$rows['grievanceCreatedOn']=$data['grievanceCreatedOn'];
		$rows['grievanceDescription']=$data['grievanceDescription'];
		//$rows['grievanceDescription']=$data['grievanceDescription'];
		
		//$commentQuery="SELECT comments,commentedOn from grievance.comments where grievanceId = '".$data['grievanceId']."' ORDER BY commentedOn DESC LIMIT 1 ";
		//$commentResult=mysqli_query($con,$commentQuery);
		
		$commentQuery="SELECT comments,commentedOn from grievance.comments where grievanceId = ? ORDER BY commentedOn DESC LIMIT 1 ";
		$stmt1 = mysqli_prepare($con, $commentQuery);
		mysqli_stmt_bind_param($stmt1, 'i', $data['grievanceId']);
		mysqli_stmt_execute($stmt1);
		$commentResult = mysqli_stmt_get_result($stmt1);
		$count= mysqli_num_rows($commentResult);
		if($count==1){
		$commentsData=mysqli_fetch_array($commentResult, MYSQLI_ASSOC);
			$rows['grievanceComments']=$commentsData['comments'];
			$rows['grievanceCommentedOn']=date("d-m-Y", strtotime($commentsData['commentedOn']));
		}
		else{
			$rows['grievanceComments']='';
			$rows['grievanceCommentedOn']='';
		}
		$rows['grievanceStatus']=$data['grievanceStatus'];
		/*$grievanceStatus_dropdown="<select name ='".$data['grievanceId']."'  id='".$data['grievanceId']."'  class='form-control' required='required'>";
		if($data['grievanceStatus']=='New'){					
		$grievanceStatus_dropdown = $grievanceStatus_dropdown."<option value='New' selected >New</option><option value='In Progress'>In Progress</option>";
		}
		else{
		$grievanceStatus_dropdown = $grievanceStatus_dropdown."<option value='New'>New</option><option value='In Progress' selected>In Progress</option>";
		}
		$rows['grievanceStatus']=$grievanceStatus_dropdown;*/
		array_push($grievanceData,$rows);
	}
	echo json_encode($grievanceData);
	}else{
		header('Location: ../../../../jnkqa/DBT_HO/login.php');
	}
?>