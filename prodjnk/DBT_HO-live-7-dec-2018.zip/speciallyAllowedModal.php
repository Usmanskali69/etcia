<?php
	include('db_connect.php');
	$type=htmlspecialchars($_GET['type']);
	$studentId  = htmlspecialchars($_GET['studentId']);
	echo '<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button><h4 class="modal-title" id="myModalLabel">Joining Report</h4></div>';
	if(file_exists("F:/jk_media/img/uploads/speciallyAllowed/$studentId.pdf")){
		
				echo '<div class="modal-body"><object height="400" data="../jk_media/img/uploads/speciallyAllowed/'.$studentId.'.pdf" type="application/pdf" width="100%"></object><br>';
	}
		
	else
	{
		echo "<div class='modal-body'><b><font size='5' color='Red'>File not uploaded</font></b><br>";
	} 
echo '</div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
      </div>';
?>