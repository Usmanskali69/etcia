$(document).ready(function(){
	
	$('#changePasswordForm').validate({
		ignore: [],
		rules: {
			changedLoginName: {
				required: true
			},
			changedPassword: {
				required: true,
				minlength: 6,
				maxlength: 15,
			},
		},
		messages: {
			email1: {required:'This field is required. Please enter valid E-mail'
			},
			email2: {required:'This field is required. Please enter valid Alternate E-mail'
			},
		},
			
		highlight: function(element) {
			$(element).closest('.form-group').addClass('has-error');
		},
		unhighlight: function(element) {
			$(element).closest('.form-group').removeClass('has-error');
		},
		errorElement: 'span',
		errorClass: 'help-block',
		errorPlacement: function(error, element) 
		{
			if(element.parent('.input-group').length) 
				{
				error.insertAfter(element.parent());
				} 
			else  if ( element.is(":radio") ) 
				{
					error.appendTo( element.parents('.form-group') );
				}
			else 
				{
				error.insertAfter(element);
				}
		}

});
});
