<?php
	session_start();
	if(isset($_SESSION['hoId']) && !empty($_SESSION['hoId']))
{
    $conn = mysql_connect("192.168.1.101","root","admin123");
    $db = mysql_select_db("jnkcounciling",$conn);
   $hoId	= htmlspecialchars($_SESSION['hoId']);
	$type 	= htmlspecialchars($_GET['type']);
    $sql = "select 
    approvalDate as Approval_Date,
    DBTApplicationSubmittedDate as Submission_Date,
    admissionThroughCCP as AdmissionThroughCCP,
    studentUniqueId as Candidate_ID,
	disclaimer as Beneficiary_Code,
    studentRank as Rank,
	yearOfCounselling as Year_Of_Counselling,
	speciallyAllowedFlag as IMC,
    name as Candidate_Name,
    fatherName as Father_Name,
    BirthDate as Date_Of_Birth,
    casteCategory as Caste_Category,
    primaryEmailId as Email_Id,
    if(admissionThroughCCP = 'Yes',
        if(collegeUniqueId != ''
                AND collegeUniqueId is not null,
            (select 
                    c.name
                from
                    colleges c,
                    students s
                where
                    c.collegeUniqueId = s.collegeUniqueId
                        and s.studentUniqueId = students.studentUniqueid),
            otherStudentCollegeName),
        otherStudentCollegeName) as Institute_Name,
    if(admissionThroughCCP = 'Yes',
        if(collegeUniqueId != ''
                AND collegeUniqueId is not null,
            (select 
                    c.address
                from
                    colleges c,
                    students s
                where
                    c.collegeUniqueId = s.collegeUniqueId
                        and s.studentUniqueId = students.studentUniqueid),
            instituteAddress),
        instituteAddress) as Institute_Address,
    if(admissionThroughCCP = 'Yes',
        if(collegeUniqueId != ''
                AND collegeUniqueId is not null,
            (select 
                    c.state
                from
                    colleges c,
                    students s
                where
                    c.collegeUniqueId = s.collegeUniqueId
                        and s.studentUniqueId = students.studentUniqueid),
            instituteState),
        instituteState) as Institute_State,
    if(admissionThroughCCP = 'Yes',
        if(collegeUniqueId != ''
                AND collegeUniqueId is not null,
            (select 
                    cr.courseName
                from
                    courses cr,
                    students s
                where
                    cr.courseUniqueid = s.courseUniqueid
                        and s.studentUniqueId = students.studentUniqueid),
            otherStudentCourseName),
        otherStudentCourseName) as Course_Name,
    if(admissionThroughCCP = 'Yes',
        if(collegeUniqueId != ''
                AND collegeUniqueId is not null,
            streamAllottedIn,
            otherStudentStreamAppliedFor),
        otherStudentStreamAppliedFor) as stream,
    tutionFees as Tution_Fees_Applied,
    hostelFees as Hostel_Mess_Fees_Applied,
    otherCharges as Other_Incidental_Charges_Applied,
    bookNStationaryCharges as Book_Stationary_Charges_Applied,
    approvedTutionFees as Tution_Fees_Approved,
    approvedHostelFees as Hostel_Mess_Fees_Approved,
    approvedBookNStationaryCharges as Book_Stationary_Charges_Approved,
	approvedOtherCharges as Other_Incidental_Charges_Approved,
    approvedTotal as Total_A_B,
    bankName as Bank_Name,
    bankBranchName as Bank_Branch_Name,
    branchCode as Branch_Code,
    bankAccountNumber as Bank_Account_Number,
    bankifscCode as Bank_IFSC_Code,
    UIDNo as Adhar_Number
FROM
    students
where
    DBTApplicationFormSubmitted = 'Y'
        and approvalFlag = 'Y'
        ";
	if($type=="final")
	{
	$sql.="and finalApprovedFlag = 'Y'";
	}
	else
	{
	$sql.=" and finalApprovedFlag = 'N'";
	}
	if($hoId!='JKCELL' && $hoId!='JKFINANCE1' && $hoId!='JKFINANCE2' && $hoId!='JKGOV'){
	$yearfromHoId=substr($hoId, -7);
	$sql.="and yearOfCounselling = '".$yearfromHoId."'";
	}
	
    $rec = mysql_query($sql) or die (mysql_error());
    
    $num_fields = mysql_num_fields($rec);
    
    for($i = 0; $i < $num_fields; $i++ )
    {
        $header .= mysql_field_name($rec,$i).",";
    }
    
    while($row = mysql_fetch_assoc($rec))
    {
        $line = '';
	
		//echo var_dump($row);
        foreach($row as $key => $value)
        {    

//echo var_dump($value);
//echo $value."=".$item;

            if((!isset($value)) || ($value == ""))
            {
                $value = ",";
            }
            else
            {
                $value = str_replace( '"' , '""' , $value );
				
                
				if($key=='Bank_Account_Number' || $key=='Adhar_Number')
				{
				$value = '"\'' . $value . '"' . ",";
				
				}
				else
				{
				$value = '"' . $value . '"' . ",";
				}
				
				//echo $row['Bank_Account_Number'];
            }
            $line .= $value;
        }
        $data .= trim( $line ) . "\n";
    }
    
    $data = str_replace("\r" , "" , $data);
    
    if ($data == "")
    {
        $data = "\n No Record Found!\n";                        
    }
    
    header("Content-type: text/csv");
   header("Content-Disposition: attachment; filename=reports.csv");
  header("Pragma: no-cache");
   header("Expires: 0");
   print "$header\n$data";
mysql_close();
exit();
}else{
		header('Location: ../../../../jnkqa/DBT_HO/login.php');
	}
?>