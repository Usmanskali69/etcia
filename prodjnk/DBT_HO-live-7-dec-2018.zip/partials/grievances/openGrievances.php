<br>
<div class="content"><br>
		<div class="container-fluid"><br>
			<table id="table-methods-table" data-height="500" data-toggle="table" data-url="operations/showTable.php" data-pagination="true" data-search="true" data-sort-name="id" data-sort-order="desc" data-show-refresh="true" >
				<thead>
					<tr>
						<div class="row" id="insideTable">
							<th data-field="grievanceId" data-sortable="true">Grievance ID</th>
							<th data-field="grievanceNature">Grievance Nature</th>
							<th data-field="grievanceCreatedById">Grievance Created By</th>
							<!--<th data-field="grievanceStatus" >Grievance Status</th>							
							<th data-field="grievanceSubject">Grievance Subject</th>
							<th data-field="grievanceComments">Grievance Comments</th>
							<th data-field="grievanceDescription">Grievance Description</th>
							<th data-field="grievanceCreatedOn"> Grievance Created On</th>-->
							<th data-field="edit_delete" data-formatter="operateSave" data-events="operateEvents">Edit</th>										
						</div>
					</tr>
				</thead>
			</table>
	</div>
</div>