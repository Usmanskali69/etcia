<?php
	require_once(realpath("./session/session_verify.php"));
?>

	<fieldset>
		<div class="panel-body" >
		
			<div class=" col-md-offset-1 col-md-10"   role="complementary">
<h3> Details of the Grievance</h3>
				
				
				<div class="panel panel-default">
					<div class="panel-body table-responsive">
					<table class="table table-bordered table-condensed f11">
						<tr>
							<td colspan="2" align="left" class="danger"><b>Grievance Details:</b></td>
						</tr>
												
						<tr>
							<td width="20%" align="left"><b>Grievance Id:</b></td>
							<td width="30%" align="left"><?php echo $grievance_row['grievanceId'];?></td>
							
							</tr>
							<tr>
							<td width="20%" align="left"><b>Status:</b></td>
							<td width="30%" align="left"><?php echo $grievance_row['grievanceStatus'];?></td>
						</tr>
						<!--<tr>
							<td width="20%" align="left"><b>Nature:</b></td>
							<td width="30%" align="left"><?php echo $grievance_row['grievanceNature'];?></td>
							</tr>-->
							<tr>
							<td width="20%" align="left"><b>Subject:</b></td>
							<td width="30%" align="left"><?php echo $grievance_row['grievanceSubject'];?></td>
						</tr>
						<tr>
							<td width="20%" align="left"><b>Description:</b></td>
							<td width="20%" align="left"><?php echo $grievance_row['grievanceDescription'];?></td>
							
						</tr>
						
					<tr>
							<td width="20%" align="left"><b>Created on:</b></td>
							<td width="20%" align="left"><?php echo $grievance_row['grievanceCreatedOn'];?></td>
							
						</tr>
						
                         
						
					</table>
					</div>	
				</div>
				<div class="panel panel-default">
					<div class="panel-body table-responsive">
					<table class="table table-bordered table-condensed f11">
						<tr>
							<td colspan="4" align="left" class="danger"><b>Attachments:</b></td>
						</tr>
						<?php if($attachments_num>0)
						{
						?>
						
								
						
						<?php while($attachments_row = mysqli_fetch_assoc($attachmentsResult))
						{
						$imageFileType = pathinfo($attachments_row["attachmentPath"],PATHINFO_EXTENSION);
							if($imageFileType =='doc' || $imageFileType == 'docx'){
							$href='../'.$attachments_row["attachmentPath"];
							$modal='';
							}else{
							$href="griModalDBT.php?attachmentId=".$attachments_row["attachmentId"];
							$modal='data-toggle="modal" data-target="#attachmentModal"';
							}
						?>
							<tr>
											
												<tr>
							
							<td width="80%" align="left"><?php echo $attachments_row['attachmentType']; ?></td>	
                             <td width="15%" align="center">
													<a href="<?php echo $href; ?>" <?php echo $modal; ?>>
													<h4><span class='glyphicon glyphicon-eye-open' aria-hidden='true'>
													</span></h4>
													</a>
												</td>							
						</tr>
												
												<!-- Attachment Modal (One modal for all attachments)-->
												<div class="modal fade bs-example-modal-lg" id="attachmentModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" >
												  <div class="modal-dialog modal-lg" role="document">
													<div class="modal-content">
													  
													</div>
												  </div>
												</div>
											</tr>
						<!--<tr>
							<td width="80%" align="left"><?php echo $attachments_row['attachmentComments']; ?></td>
							<td width="20%" align="left">
								<a href = "#" class = "thumbnail"><!--<i class="fa fa-x fa fa-eye" aria-hidden="true"></i> 
									<img src = "..\<?php echo $attachments_row['attachmentPath']; ?>" alt = "Grievance Attachment">
								</a>
							</td>					
						</tr>-->		
						<?php
						}
						?>
						<!--<div class="modal fade" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
							<div class="modal-dialog">
								<div class="modal-content">              
								  <div class="modal-body">
									<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
									<img src="" class="imagepreview" style="width: 100%;" >
								  </div>
								</div>
							</div>
						</div>-->
						<?php 
						}else
						{
						?>	
						<tr>
							<td colspan="4" align="left"><i>No attachments found.</i></td>
						</tr>
						<?php 
						}
						?>					
					</table>
					</div>	
				</div>
				
				<div class="panel panel-default">
					<div class="panel-body table-responsive">
					<table class="table table-bordered table-condensed f11">
						<tr>
							<td colspan="5" align="left" class="danger"><b>Comments:</b></td>
						</tr>
						
						<?php
						$i=1;
						if($comments_num>0)
						{
						?>
						<tr>	
							<td width="7%" align="left"><b>Sr. No.</b></td>		
                            <td width="35%" align="left"><b>Grievance Status</b></td>								
							<td width="21%" align="left"><b>Comments</b></td>	
							<td  width="20%" align="left"><b>Commented By</b></td>		
                            <td  width="20%" align="left"><b>Commented On</b></td>									
						</tr>
						
						<?php while($comments_row = mysqli_fetch_assoc($commentsResult))
						{
						?>
						<tr>	
							<td width="7%"  align="left"><?php echo $i.'.';$i++; ?></td>
							<td width="35%"  align="left"><?php echo $comments_row['grievanceStatusChangedTo']; ?></td>	
							<td width="21%"  align="left"><?php echo $comments_row['comments']; ?></td>	
							<td width="20%"  align="left"><?php echo $comments_row['commentedBy']; ?></td>		
                            <td width="20%"  align="left"><?php echo date("d-m-Y", strtotime($comments_row['commentedOn'])); ?></td>								
						</tr>
						<?php
						}//End of comments_row if
						?>
						<?php 
						}//End of comments_num if
						else
						{
						?>
						<tr>
							<td colspan="4" align="left"><i>No comments found.</i></td>
						</tr>
						<?php
						}
						?>					
					</table>
					</div>	
				</div>
				
				
					

<button onclick="window.location.href='index.php?q=grievances&q1=addgrievance'" class="btn  btn-success col-lg-2 pull-right" style="margin-left:10px;">OK</button>
<?php if($grievance_row['grievanceEditFlag'] == 'Y') 
	  {
?>
<button onclick="window.location.href='editGrievance.php?grievanceId=<?php echo $grievanceId; ?>'" class="btn  btn-success col-lg-2 pull-right" style="margin-left:10px;">Edit</button>
<?php }
?>


	<div id="myModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
	<div class="modal-content">
	  <div class="modal-header">
		<button type="button" class="close" data-dismiss="modal">&times;</button>
		<h4 class="modal-title">Modal Header</h4>
	  </div>
	  <div class="modal-body">
		<p id="grievanceMessage">Some text in the modal.</p>
	  </div>
	  <div class="modal-footer">
		<a class="btn  btn-success " data-dismiss="modal" onclick="javascript:window.location.href='index.php?q=inProgressGrievances';">OK</a>
	  </div>
	</div>

	</div>
	</div>	
		
</form>			
</div>	
			
		</div>
		
	</fieldset>
				
