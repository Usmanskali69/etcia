<?php
	session_start();
	include('db_connect.php');
	
	if(isset($_GET['studentUniqueId'])){
		$studentUniqueId=$_GET['studentUniqueId'];
	}else{
		$studentUniqueId=$_SESSION['studentUniqueId'];
	}
	
	$query="SELECT * FROM students WHERE studentUniqueId='".$studentUniqueId."'";
	$result = mysqli_query($con,$query);
	$user_row = mysqli_fetch_array($result);
	$query1="SELECT otherStudentCollegename,otherStudentCourseName,otherStudentUniversity,otherStudenttypeOfInstitute,streamAppliedFor FROM students WHERE studentUniqueId='".$studentUniqueId."'";
	//echo $query;
	$result1 = mysqli_query($con,$query1);
	$user_row1 = mysqli_fetch_array($result1);
	
	$collegequery='SELECT * FROM colleges WHERE collegeUniqueId='.$user_row['collegeUniqueId'];	
	//echo $collegequery;
	$collegeresult = $result = mysqli_query($con,$collegequery);
	$college_row = mysqli_fetch_array($collegeresult);
	
	$coursesquery='SELECT * FROM courses WHERE courseUniqueId='.$user_row['courseUniqueId'];	$coursesresult = $result = mysqli_query($con,$coursesquery);
	$course_row = mysqli_fetch_array($coursesresult);
	
	/* $joiningReport=$user_row['joiningReport'];
	$feeReceipt=$user_row['feeReceipt'];
	$bookReceipt=$user_row['bookReceipt'];
	$bankPassBook=$user_row['bankPassBook'];
	$rentReceipt=$user_row['rentReceipt'];
	$aadharCard=$user_row['aadharCard'];
	$collegehostelReceipt=$user_row['collegehostelReceipt'];
	$otherIncidentalCharges=$user_row['otherIncidentalChargesReceipt'];
	$joiningtutionhostelReceipt = $user_row['joiningtutionhostelReceipt'];
	$hscmarksheet = $user_row['hscmarksheetfile'];
	$sscmarksheet = $user_row['sscmarksheetfile']; */
	
	$html = '
	<!DOCTYPE html>
	<head>
	<link rel="stylesheet" type="text/css" href="css/style_applicationForm.css">
	</head>
	<body style="background-image: url(img/bckimg.jpg);background-image-resize:4;background-repeat:no-repeat;">
	<htmlpagefooter name="footer">
	<table width="100%" style="vertical-align:bottom;font-family:serif;font-size:8pt;color:#000000;font-weight:bold;font-style:italic;">
	<tr><td width="33%"><span style="font-weight:bold;font-style:italic;"> </span></td>
	<td width="33%" align="right" style="font-weight:bold;font-style:italic;">{PAGENO}/{nbpg}</td>
	</tr>
	</table>
	</htmlpagefooter>
	
	<sethtmlpagefooter name="footer" value="on" />
	
	
	
	<htmlpageheader name="header">
	<table border="0" cellspacing="0" cellpadding="0" width="100%" bgcolor="#D7E1EF">
		<tbody>
			<tr>
				<td valign="top" width="5%">
					<img src="img/emblem.jpg" alt="Aicte Logo" class="image" align="left">
					</image>
				</td>
				<td valign="top" width="90%" align="center">
					<font face="Times New Roman">
						<p align="center" style="font-size:12px">
							<strong>
								SCHOLARSHIP FOR GIRLS UNDER PRAGATI SCHEME AND SCHOLARSHIP FOR DIFFERENTLY ABLED STUDENTS UNDER SAKSHAM for 2015-2016
							</strong>
						</p>
						<p align="center" style="font-size:12px">					  
							<strong>
								IMPLEMENTED BY ALL INDIA COUNCIL FOR TECHNICAL EDUCATION, NEW DELHI
							</strong>
						</p>
					</font>
				</td>
				<td valign="top" width="5%">
					<img src="img/logo_doc.jpg" alt="Aicte Logo" class="image" align="right">
					</image>
				</td>
			</tr>
		</tbody>
	</table>
	<br/><br/>
	
	<br/><br/>
	</htmlpageheader>
	
	
	
	<sethtmlpageheader name="header" page="O" value="on" show-this-page="1" />
	<sethtmlpageheader name="header" page="E" value="on" />

	
	<br></br>
	<br></br>
	
	
	<table cellspacing="1" cellpadding="2" border="1" width="20%" align="center">
		<tbody>
			<tr>
				<td align="center" width="100%">
					<div class="box">
						<p>
							<strong><u>'.$user_row['applicationStatus'].' Application Form</u></strong>
						</p>
					</div>
				</td>
			</tr>
		</tbody>
	</table>
	
	
	
	
	
	
	
	
	
	
	
	<br/><br/>
	
	
	
	<div class="applicationStatus">
	
	
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>Application Status: </label><b>'.$user_row['applicationStatus'].'</b>
	
	</div>
	
	<br/><br/>
	
	
	<div class="tableheading">
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Basic Details:

	</div>
	
	<table border="1" cellspacing="5" cellpadding="3" width="88%" align="center">
			<tr>
				<td valign="top" width="20%" bgcolor="#99CCFF">
					<p>
						<strong>Candidate Id:</strong>
					</p>
				</td>
				<td valign="top" colspan="3">
					<p>
						'.$user_row['studentUniqueId'].'
					</p>
				</td>
				<td valign="top" rowspan="6"  width="20%">
					<img src="'.$user_row['photo'].'" width="200" height="150" style="background: 10px solid black" >
				</td>
				
			</tr>
			
			<tr>
				<td valign="top" width="20%" bgcolor="#99CCFF">
					<p>
						<strong>Candidate Name:</strong>
					</p>
				</td>
				<td align="left" colspan="3">
					<p>';
						if($user_row['speciallyAllowedFlag']=='Y'){ $html .= $user_row['name']; }else{ $html .= $user_row['firstName'].'&nbsp;'.$user_row['middleName'].'&nbsp;'.$user_row['lastName'];}
					$html .= '</p>
					
				</td>
			</tr>
			
			<tr>
				<td valign="top" width="20%" bgcolor="#99CCFF">
					<p>
						<strong>Mobile No:</strong>
					</p>
				</td>
				<td valign="top" colspan="3">
					<p>
					   '.$user_row['mobileNo'].'
					</p>
				</td>
			</tr>
			<tr>
				<td valign="top" width="20%" bgcolor="#99CCFF">
					<p>
						<strong>Alternate Email Id (if any):</strong>
					</p>
				</td>
				<td valign="top" colspan="3">
					<p>
						'.$user_row['alternateEmailId'].'
					</p>
				</td>
			</tr>
			<tr>
				<td valign="top" width="20%" bgcolor="#99CCFF">
					<p>
						<strong>Aadhaar Card Number:</strong>
					</p>
				</td>
				<td valign="top"  colspan="3">
					<p>'.$user_row['UIDNo'].'</p>
				</td>
			</tr>
	</table>
	
	<br/>
	<div class="tableheading">

		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Institute Details:

	</div>
	<table border="1" cellspacing="5" cellpadding="3" width="84%" align="center">
		<tbody>
			<tr>
				<td valign="top" width="24%" colspan="4">
					<p>
						<strong>(II) Basic Institute Details:</strong>
					</p>
				</td>
			</tr>
			<tr>
				<td width="19%" valign="top" bgcolor="#99CCFF">
					<p>
						<strong>Admission through Centralized Counselling Process:</strong>
					</p>
				</td>
				<td valign="top">
					<p>
						'.$user_row['admissionThroughCCP'].'
					</p>
				</td>
				<td width="19%" valign="top" bgcolor="#99CCFF">
					<p><strong>Year of Admission:</strong></p>
				</td>
				<td valign="top">
					<p>';
						if($user_row['speciallyAllowedFlag']=='Y'){$html .= $user_row['yearOfCounselling'].' <font color="Red"><b>IMC</b></font>';} else{$html.= $user_row['yearOfCounselling'];}
					$html .='</p>
				</td>
				
			</tr>
			<tr>
				<td width="19%" valign="top" bgcolor="#99CCFF">
					<p><strong>Institute ID:</strong></p>
				</td>
				<td valign="top">
					<p>';
						if($user_row['collegeUniqueId']!='' && $user_row['collegeUniqueId']!=null){ $html .= $user_row['collegeUniqueId'];} else { $html .= $user_row['otherStudentCollegeId'];}
					$html .='</p>
				</td>
				<td width="19%" valign="top" bgcolor="#99CCFF">
					<p>
						<strong>Institute Name:</strong>
					</p>
				</td>
				<td valign="top">
					<p>';
						if($user_row['collegeUniqueId']!='' && $user_row['collegeUniqueId']!=null){ $html .= $college_row['name'];} else { $html .= $user_row1['otherStudentCollegename'];}
					$html .='</p>
				</td>
				
			</tr>
			<tr>
				<td width="20%" valign="top" bgcolor="#99CCFF"><p><strong>Course Name:</strong></p></td>
				<td width="30%" valign="top">
					<p>';
						if($user_row['collegeUniqueId']!='' && $user_row['collegeUniqueId']!=null){ $html .= $course_row['courseName'];} else { $html .= $user_row1['otherStudentCourseName']; }
					$html .='</p>
				</td>
				<td width="20%" valign="top" bgcolor="#99CCFF"><p><strong>Affiliating University:</strong></p></td>
				<td width="30%" valign="top"><p>';
					if($user_row['collegeUniqueId']!='' && $user_row['collegeUniqueId']!=null){ $html .= $course_row['university'];} else { $html.= $user_row1['otherStudentUniversity'];}
				$html .='</p></td>
			</tr>
			<tr>
				<td width="20%" valign="top" bgcolor="#99CCFF"><p><strong>Institute Category:</strong></p></td>
				<td width="30%" valign="top"><p>'.$user_row['instituteCategory'].'</p></td>
				<td width="20%" valign="top" bgcolor="#99CCFF"><p><strong>Other Institute Category:</strong></p></td>
				<td width="30%" valign="top"><p>';
				if($user_row['instituteCategory']=='Any Other'){$html .= $user_row['otherInstituteCategory'];}else {$html .= "-";}
				$html .='</p></td>
			</tr>
			<tr>
				<td width="20%" valign="top" bgcolor="#99CCFF"><p><strong>Institute Stream:</strong></p></td>
				<td colspan="3" valign="top"><p>';
					if($user_row['collegeUniqueId']!='' && $user_row['collegeUniqueId']!=null){ $html .= $college_row['category'];} else { $html .= $user_row['otherStudentStreamAppliedFor'];}
				$html .='</p></td>
			</tr>
			<tr>
				<td width="20%" valign="top" bgcolor="#99CCFF"><p><strong>Institute Website:</strong></p></td>
				<td colspan="3" valign="top"><p>'.$user_row['instituteWebsite'].'</p></td>
			</tr>
			<tr>
				<td valign="top" width="24%" colspan="8">
					<p>
						<strong>(III) Contact Person Details:</strong>
					</p>
				</td>
				
			</tr>
			<tr>
				<td valign="top" width="20%" bgcolor="#99CCFF">
					<p>
						<strong>Contact Person Name:</strong>
					</p>
				</td>
				<td valign="top"  width="30%">
					<p>
						'.$user_row['contactPerson'].'
					</p>
				</td>
				<td valign="top" width="20%" bgcolor="#99CCFF">
					<p>
						<strong>Designation of Contact Person:</strong>
					</p>
				</td>
				<td valign="top"  width="30%">
				   
						'.$user_row['designationOfContactPerson'].'
				  
				</td>
			</tr>
			<tr>
				<td valign="top" width="24%" bgcolor="#99CCFF">
					<p>
						<strong>Contact No. of Principal/Director:</strong>
					</p>
				</td>
				<td valign="top" colspan="3">
					<p>
						'.$user_row['contactPersonNumber'].'
					</p>
				</td>
				
			</tr>
		</tbody>
	</table>
	<br/>';
	if($user_row['applicationStatus']=='Previously Allotted'){
	$html .='
	<div class="tableheading">

		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Academic Record:

	</div>
	<table border="1" cellspacing="5" cellpadding="3" width="84%" align="center">
		<tbody>
			<tr>
				<td valign="top" width="24%" bgcolor="#99CCFF"><b>Examination Type:</b></td>
				<td valign="top" width="26%"><p>'.$user_row['examType'].'</p></td>
				<td valign="top" width="24%" bgcolor="#99CCFF"><b>Examination pattern:</b></td>
				<td valign="top" width="26%" colspan="2"><p>'.$user_row['examPattern'].'</p></td>
			</tr>
			<tr>
				<td valign="top" width="24%" bgcolor="#99CCFF"><b>Enrollment No:</b></td>
				<td valign="top" width="26%"><p>'.$user_row['enrollmentNo'].'</p></td>
				<td valign="top" width="24%" bgcolor="#99CCFF"><b>University Name:</b></td>
				<td valign="top" width="26%" colspan="2"><p>'.$user_row['UniversityName'].'</p></td>
			</tr>';
			$query_year='SELECT year(DBTApplicationSubmittedDate) as yearSubmitted FROM students WHERE studentUniqueId="'.$studentUniqueId.'"';
			//ho $query_year;
			$result_year = mysqli_query($con,$query_year) or die('Query Failed');
			$user_row_year = mysqli_fetch_array($result_year);
			$yearOfCounselling= substr($user_row['yearOfCounselling'], 0, 4);
			$current_year = $user_row_year['yearSubmitted'];
			$yeardiff=intval($current_year)-intval($yearOfCounselling);
			$j=0;
			$examType=$user_row['examType'];
			if($examType=='Yearly')
			{
				$j=$yeardiff;
			}
			if($examType=='Semester')
			{
				$j=$yeardiff*2;
				if($current_year=='2016')
				{
					$j=$j-1;
				}
			}
			$html .='
			<br/>
			<tr>
				<td width="20%" valign="top"><b>Sr no.</b></td>
				<td width="10%" valign="top"><b>Semester/Year</b></td>
				<td width="10%" valign="top"><b>Percentage/SGPA Obtained</b></td>
				<td width="20%" valign="top"><b>Roll Number</b></td>
				<td width="10%" valign="top"><b>Result</b></td>
				
				
			</tr>';
			for($i=1;$i<=$j;$i++){
				$sem="";
					
				if($i==1 && $examType=='Semester'){ $sem=$i.'st Sem';}
				else if($i==1 && $examType=='Yearly'){ $sem=$i.'st Year';}
				else if($i==2 && $examType=='Semester'){ $sem=$i.'nd Sem';} 
				else if($i==2 && $examType=='Yearly'){ $sem=$i.'nd Year';} 
				else if($i==3 && $examType=='Semester'){ $sem=$i.'rd Sem';} 
				else if($i==3 && $examType=='Yearly'){ $sem=$i.'rd Year';}
				else{
					if($examType=='Semester'){ $sem=$i.'th Sem';}
					if($examType=='Yearly'){$sem=$i.'th Year';}
				}
				//include("db_connect.php");
				$AYquery="select * from academic_year_record where studentUniqueId='".$user_row['studentUniqueId']."' and semester='".$sem."'";
				//echo $AYquery;
				$AYresult = mysqli_query($con, $AYquery);
				$AY_row=mysqli_fetch_array($AYresult);
				mysqli_close();
				$semester=$AY_row['semester'];
				$percentage=$AY_row['percentageOrGPA'];
				$rollNo=$AY_row['rollNo'];
				$result=$AY_row['result'];
			
				$html .='<tr>
					<td>'.$i.'</td>
					<td>'.$semester.'</td>
					<td>'.$percentage.'</td>
					<td>'.$rollNo.'</td>
					<td>'.$result.'</td>
					
			</tr>';
			}
		$html .='</tbody>
	</table>
	<br>';
	}
	$html .='
	<div class="tableheading">

		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bank Details:

	</div>
	<table border="1" cellspacing="5" cellpadding="3" width="88%" align="center">
		<tbody>
			<tr>
				<td valign="top" width="24%" colspan="4">
					<p>
						<strong>Saving Bank Account Details</strong>
					</p>
				</td>
			</tr>
			<tr>
				<td valign="top" width="24%" bgcolor="#99CCFF">
					<p>
						<strong>Account Holder Name(Candidate):</strong>
					</p>
				</td>
				<td valign="top" width="26%">
					<p>
					   '.$user_row['accountHolderName'].'
					</p>
				</td>
				<td valign="top" width="19%" bgcolor="#99CCFF">
					<p>
						<strong>Bank Name:</strong>
					</p>
				</td>
				<td valign="top" width="28%">
					<p>
						'.$user_row['bankName'].'
					</p>
				</td>
			</tr>
			<tr>
				<td valign="top" width="24%" bgcolor="#99CCFF">
					<p>
						<strong>Bank Branch Name:</strong>
					</p>
				</td>
				<td valign="top" width="26%">
					<p>
					  '.$user_row['bankBranchName'].'
					</p>
				</td>
				<td valign="top" width="19%" bgcolor="#99CCFF">
					<p>
						<strong>Branch Code:</strong>
					</p>
				</td>
				<td valign="top" width="28%">
					<p>
						'.$user_row['branchCode'].'
					</p>
				</td>
			</tr>
			<tr>
				<td valign="top" width="24%" bgcolor="#99CCFF">
					<p>
						<strong>Bank IFSC Code:</strong>
					</p>
				</td>
				<td valign="top" width="26%">
					<p>
					   '.$user_row['bankifscCode'].'
					</p>
				</td>
				<td valign="top" width="19%" bgcolor="#99CCFF">
					<p>
						<strong>Bank Account Number:</strong>
					</p>
				</td>
				<td valign="top" width="28%">
					<p>
						'.$user_row['bankAccountNumber'].'
					</p>
				</td>
			</tr>
	 
		  
			<tr>
				<td valign="top" width="24%" bgcolor="#99CCFF">
					<p>
						<strong>Bank Address:</strong>
					</p>
				</td>
				<td valign="top" width="26%" colspan="3">
					<p>
						 '.$user_row['bankAddress'].'
					</p>
				</td>
				
			</tr>
			
			
		
		</tbody>
	</table>
	<br>
	
	<div class="tableheading">

		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fee Details:

	</div>
	<table border="1" cellspacing="5" cellpadding="3" width="84%" align="center">
		<tbody>
			<tr>
				<td width="25%" valign="top" bgcolor="#99CCFF"><b>Payment Type:</b></td>
				<td width="80%" valign="top" colspan="5"><p>';
					if($user_row['approvalFlag']!='Y' && $user_row['DBTApplicationStatus']=='Submitted'){
						if ($user_row['paymentType']=='Semester'){$html .='Semester';}
						if ($user_row['paymentType']=='Yearly'){$html .= 'Yearly';}else{$html .= $user_row['paymentType'];}
						}
					$html .='</p>
				</td>
			</tr>
			<tr>
				<td width="50%" colspan="3" align="center"><p><strong>(A)</strong></p></td>
				<td width="50%" colspan="3" align="center"><p><strong>(B)</strong></p></td>
			</tr>
			<tr>
				<td width="20%" align="center"></td>
				<td width="15%" align="center"><p><strong>Applied</strong></p></td>
				<td width="15%" align="center"><p><strong>Approved</strong></p></td>
				<td width="20%" align="center"></td>
				<td width="15%" align="center"><p><strong>Applied</strong></p></td>
				<td width="15%" align="center"><p><strong>Approved</strong></p></td>
			</tr>
			<tr>
				<td width="20%" align="left" bgcolor="#99CCFF"><b>Tution Fee:</b></td>
				<td width="15%" align="left"><p>'.$user_row['tutionFees'].'</p></td>
				<td width="15%" align="left" id="tutionFeesError"><p>';
					if($user_row['approvalFlag']!='Y' && $user_row['DBTApplicationStatus']=='Submitted'){
					$html .= $user_row['approvedTutionFees'];
					}else{$html .= $user_row['approvedTutionFees'];}
					$html .='<div id="tutionFeesErrorMsg"></div>
				</td>
				<td width="20%" align="left" bgcolor="#99CCFF"><b>Hostel and Mess Fee:</b></td>
				<td width="15%" align="left"><p>'.$user_row['hostelFees'].'</p></td>
				<td width="15%" align="left"><p>';
					if($user_row['approvalFlag']!='Y' && $user_row['DBTApplicationStatus']=='Submitted'){
							$html .=$user_row['approvedHostelFees'];
					}else{$html .= $user_row['approvedHostelFees'];}
				$html .='</td>
			</tr>
			<tr>
				<td colspan="3" align="left" rowspan="2"></td>
				<td width="20%" align="left" bgcolor="#99CCFF"><b>Books & Stationary:</b></td>
				<td width="15%" align="left"><p>'.$user_row['bookNStationaryCharges'].'</p></td>
				<td width="15%" align="left"><p>';
					if($user_row['approvalFlag']!='Y' && $user_row['DBTApplicationStatus']=='Submitted'){
						$html .= $user_row['approvedBookNStationaryCharges'];
					}else{$html .= $user_row['approvedBookNStationaryCharges'];}
				$html .='</td>
			</tr>
			<tr>
				<td width="20%" align="left" bgcolor="#99CCFF"><b>Other Incidental Charges :</b></td>
				<td width="15%" align="left"><p>'.$user_row['otherCharges'].'</p></td>
				<td width="15%" align="left"><p>';
					if($user_row['approvalFlag']!='Y' && $user_row['DBTApplicationStatus']=='Submitted'){
						$html .=$user_row['approvedOtherCharges'];
					}else{$html .=$user_row['approvedOtherCharges'];}
				$html .='</td>
			</tr>
			<tr>
				<td width="20%" align="left" bgcolor="#99CCFF"><p><strong>Total (A) :</strong></p></td>
				<td width="15%" align="left"><p>'.$user_row['tutionFees'].'</p></td>
				<td width="15%" align="left">
					<p>'.$user_row['approvedTutionFees'].'</p></td>
				<td width="20%" align="left" bgcolor="#99CCFF"><p><strong>Total (B) :</strong></p></td>
				<td width="15%" align="left"><p>'.$user_row['total'].'</p></td>
				<td width="15%" align="left" id="totalBError"><p>'.$user_row['approvedTotalB'].'</p></td>
			</tr>
			<tr>
				<td width="20%" align="left" bgcolor="#99CCFF"><p><strong>Total :</strong></p></td>
				<td colspan="5" align="left"><p>'.$user_row['approvedTotal'].'</p></td>
			</tr>
		</tbody>
	</table>
	<br>
	<div class="tableheading">

		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Approval/Rejection Comments:

	</div>
	<table border="1" cellspacing="5" cellpadding="3" width="88%" align="center">
		<tbody>
			<tr>
				<td width="20%" align="left" bgcolor="#99CCFF"><b>Approval/Rejection Comment:</b></td>
				<td width="80%" align="left" id="commentError">
					<p>'.$user_row['approvalOrRejectionComment'].'</p>
				</td>
			</tr>
		</tbody>
	</table>
	
	</body>
	</html>
	';
	$html;
	mysqli_close ($con);
		//echo $html;
		include("../mpdf60/mpdf.php");
		$mpdf=new mPDF();
		$mpdf->setAutoTopMargin = 'stretch';
		$mpdf->setAutoBottomMargin = 'stretch';
		$mpdf->SetHTMLHeaderByName('header');
		$mpdf->WriteHTML($html);
		$mpdf->SetHTMLFooterByName('footer');
		//$mpdf->Output();
		if(isset($_GET['studentUniqueId'])){
			$mpdf->Output('Application Form.pdf','I');
		}
?>