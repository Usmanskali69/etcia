<?php

	session_start();
	if(isset($_SESSION['hoId']) && !empty($_SESSION['hoId']))
		{
	include("../../../db_connect.php");
	$hoId=$_SESSION['hoId'];
	$hoId=substr($hoId, -7);
//	$studentQuery	=	"select approvalDate, DBTApplicationSubmittedDate, admissionThroughCCP, studentUniqueId,disclaimer, studentRank,name, DBTApplicationStatus, collegeUniqueId, streamAllottedIn, otherStudentStreamAppliedFor, otherStudentCollegeName
//FROM
   // students 
   
//where
   // DBTApplicationStatus='Rejected' and yearOfCounselling='".$hoId."'";
	
	
//	$result = mysqli_query($con, $studentQuery) or die("Could not execute query");

$studentQuery	="select approvalDate, DBTApplicationSubmittedDate, admissionThroughCCP, studentUniqueId,disclaimer, studentRank,name, DBTApplicationStatus, collegeUniqueId, streamAllottedIn, otherStudentStreamAppliedFor, otherStudentCollegeName
FROM students whereDBTApplicationStatus='Rejected' and yearOfCounselling=?";

$stmt = mysqli_prepare($con, $studentQuery);
	mysqli_stmt_bind_param($stmt, 's', $hoId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	$studentData=array();
	
	while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
		$row_array['Rejection_Date'] = $row['approvalDate'];
		$row_array['Submission_Date'] = $row['DBTApplicationSubmittedDate'];
		$row_array['AdmissionThroughCCP'] = $row['admissionThroughCCP'];
		$row_array['Candidate_Id'] = $row['studentUniqueId'];
		$row_array['Beneficiary_Code'] = $row['disclaimer'];
		$row_array['Candidate_Rank'] = $row['studentRank'];
		$row_array['Candidate_Name'] = $row['name'];
		$row_array['Candidate_Status'] = $row['DBTApplicationStatus'];
		if($row['admissionThroughCCP']=='Yes')
		{
		if($row['collegeUniqueId']!='' && $row['collegeUniqueId']!=null){
		if($row['streamAllottedIn']=='Engineering and Technology')
		{
		$row['streamAllottedIn']='Engineering';
		}
		$row_array['Candidate_Category'] = $row['streamAllottedIn'];
		$collegeQuery	=	"select 
    name,address,state
FROM
    colleges 
   
where
    
       collegeUniqueId='".$row['collegeUniqueId']."'";
	
	
	$collegeresult = mysqli_query($con, $collegeQuery) or die("Could not execute query");
	$college_row=mysqli_fetch_array($collegeresult);
	$row_array['College_Name'] = $college_row['name'];
	}else
		{
		if($row['otherStudentStreamAppliedFor']=='Engineering and Technology')
		{
		$row['otherStudentStreamAppliedFor']='Engineering';
		}
		$row_array['Candidate_Category'] = $row['otherStudentStreamAppliedFor'];
		$row_array['College_Name'] = $row['otherStudentCollegeName'];
		}
		}
		if($row['admissionThroughCCP']=='No')
		{
		$row_array['Candidate_Category'] = $row['otherStudentStreamAppliedFor'];
		$row_array['College_Name'] = $row['otherStudentCollegeName'];
		}
	
		array_push($studentData,$row_array);
	}
	
	echo json_encode($studentData);
	}else{
		header('Location: ../../../../jnkqa/DBT_HO/login.php');
	}
?>