<?php
	include('config.php');
	$grievanceStatus=$_GET['status'];
	$hoId=$_GET['hoId'];
	$year=$_GET['year'];
	if($grievanceStatus=='In Progress' && $year!='' && $year!='Not Yet Admitted' && $year!='EGOVERNANCE' && $year!='Institute' && $year!='Facilitator')
	{	
	$subQuery="and yearOfCounselling='$year' and (grievancesCreatedBy = 'Student' OR (grievancesCreatedBy = 'Ho' AND grievanceAssignedTo = '".$hoId."'))";
	}
	else if($grievanceStatus=='In Progress' && $year=='Not Yet Admitted' )
	{	
	$subQuery="and yearOfCounselling in ('$year','2017-18') and (grievancesCreatedBy = 'Student' OR (grievancesCreatedBy = 'Ho' AND grievanceAssignedTo = '".$hoId."'))";
	}
	else if($grievanceStatus=='In Progress' && $year=='EGOVERNANCE' )
	{	
	$subQuery="and grievanceAssignedTo = '".$hoId."'";
	}
	else if($grievanceStatus=='In Progress' && $year=='Institute' )
	{	
	$subQuery="and grievancesCreatedBy = 'Institute'";
	}
	else if($grievanceStatus=='In Progress' && $year=='Facilitator' )
	{	
	$subQuery="and grievancesCreatedBy = 'Facilitator'";
	}
	else if($hoId=='EGOVERNANCE' && $grievanceStatus=='Closed')
	{
	$subQuery="and (grievancesCreatedBy = 'Student' OR grievancesCreatedBy = 'Institute' OR grievancesCreatedBy = 'Facilitator' OR (grievancesCreatedBy = 'Ho' AND grievanceAssignedTo = '".$hoId."'))";
	}
	else
	{
	$subQuery="and (grievancesCreatedBy = 'Student' OR (grievancesCreatedBy = 'Ho' AND grievanceAssignedTo = '".$hoId."'))";
	}
	if($hoId !='EGOVERNANCE' || $hoId !='JKCELL')
	{
	$yearOfCounselling=substr($hoId,6);
	}
	if($hoId == 'LNT')
	{
	$query="Select grievanceId,grievanceNature,grievanceSubject,grievanceCreatedById,grievanceEmailId,grievanceCreatedOn,grievanceDescription,grievanceStatus,grievanceAssignedTo,yearOfCounselling from grievance.grievances where grievanceStatus='".$grievanceStatus."' AND grievanceAssignedTo='".$hoId."' ORDER BY grievanceId ASC";
	$result=mysqli_query($con,$query);
	}
    else if($hoId =='EGOVERNANCE'){
	$query="Select grievanceId,grievanceNature,grievanceSubject,grievanceCreatedById,grievanceEmailId,grievanceCreatedOn,grievanceDescription,grievanceStatus,grievanceAssignedTo,yearOfCounselling from grievance.grievances where grievanceStatus='".$grievanceStatus."' $subQuery  ORDER BY grievanceId ASC";
	$result=mysqli_query($con,$query);
	}
	else if($hoId =='JKCELL'){
	$query="Select grievanceId,grievanceNature,grievanceSubject,grievanceCreatedById,grievanceEmailId,grievanceCreatedOn,grievanceDescription,grievanceStatus,grievanceAssignedTo,yearOfCounselling from grievance.grievances where grievanceStatus='".$grievanceStatus."' AND (grievancesCreatedBy = 'Student' OR (grievancesCreatedBy = 'Ho' AND grievanceAssignedTo = '".$hoId."')) AND yearOfCounselling in ('2012-13','2013-14','2014-15') ORDER BY grievanceId ASC";
	$result=mysqli_query($con,$query);
	}
	else{
	$query="Select grievanceId,grievanceNature,grievanceSubject,grievanceCreatedById,grievanceEmailId,grievanceCreatedOn,grievanceDescription,grievanceStatus,grievanceAssignedTo,yearOfCounselling from grievance.grievances where grievanceStatus='".$grievanceStatus."' AND (grievancesCreatedBy = 'Student' OR (grievancesCreatedBy = 'Ho' AND grievanceAssignedTo = '".$hoId."')) AND yearOfCounselling='$yearOfCounselling' ORDER BY grievanceId ASC";
	$result=mysqli_query($con,$query);
	}
	$rows = array();
	$grievanceData = array();
	while($data = mysqli_fetch_assoc($result)) {
	
		$rows['grievanceId']=$data['grievanceId'];
		$rows['grievanceNature']=$data['grievanceNature'];
		$rows['grievanceSubject']=$data['grievanceSubject'];
		$rows['grievanceCreatedById']=$data['grievanceCreatedById'];
		if($data['grievanceCreatedById']!='Not yet registered'){
		$rows['grievancelink']="<a href='partials/ajax/getAllGrievances.php?Id=".$data['grievanceCreatedById']."' data-toggle='modal' data-target='#track'>".$data['grievanceCreatedById']."</a>";
		$rows['grievanceEmailId']=$data['grievanceEmailId'];}
		else{$rows['grievancelink']=$data['grievanceCreatedById'];
		$rows['grievanceEmailId']="<a href='partials/ajax/getAllGrievances.php?Id=".$data['grievanceEmailId']."' data-toggle='modal' data-target='#track'>".$data['grievanceEmailId']."</a>";}
		$rows['grievanceCreatedOn']=$data['grievanceCreatedOn'];
		$rows['grievanceDescription']=$data['grievanceDescription'];		
		$rows['grievanceStatus']=$data['grievanceStatus'];
		$rows['grievanceAssignedTo']=$data['grievanceAssignedTo'];
		$rows['yearOfCounselling']=$data['yearOfCounselling'];
		
		$streamQuery="select a.otherStudentCollegeName as CollegeName,a.otherStudentStreamAppliedFor as stream  from jnkcounciling.students a where a.studentUniqueid='".$data['grievanceCreatedById']."'";
		$streamResult=mysqli_query($con,$streamQuery);
		$streamRow=mysqli_fetch_assoc($streamResult);
		$rows['studentCollege']=$streamRow['CollegeName'];
		$rows['studentStream']=$streamRow['stream'];	
		
		$commentQuery="SELECT comments,commentedOn from grievance.comments where grievanceId = '".$data['grievanceId']."' ORDER BY commentedOn DESC LIMIT 1 ";
		$commentResult=mysqli_query($con,$commentQuery);
		$count= mysqli_num_rows($commentResult);
		if($count==1){
		$commentsData=mysqli_fetch_assoc($commentResult);
			$rows['grievanceComments']=$commentsData['comments'];
			$rows['grievanceCommentedOn']=date("d-m-Y", strtotime($commentsData['commentedOn']));
		}
		else{
			$rows['grievanceComments']='';
			$rows['grievanceCommentedOn']='';
		}
		array_push($grievanceData,$rows);
	}
	echo json_encode($grievanceData);
	mysqli_close($con);
?>