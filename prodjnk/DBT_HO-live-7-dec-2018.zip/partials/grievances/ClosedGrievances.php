<br><div class="container-fluid"><br>
			<table id="table-methods-table" data-height="450" data-toggle="table" data-url="operations/showTable.php?status=Closed&hoId=<?php echo $_SESSION['hoId'];?>" data-pagination="true" data-search="true" data-sort-name="id" data-sort-order="desc" data-show-refresh="true" >
				<thead>
					<tr>
						<div class="row" id="insideTable">
						    <th data-field="grievanceCreatedOn" data-sortable="true">Received On</th>
							<th data-field="grievanceId" data-sortable="true">Grievance ID</th>
							<th data-field="grievanceNature">Nature</th>
							<th data-field="grievancelink">Created By</th>
							<th data-field="grievanceCreatedById" data-visible="false">Created By</th>
							<th data-field="grievanceEmailId">Email Id</th>
							<th data-field="yearOfCounselling" >Counselling Year</th>
							<th data-field="studentStream" >Stream</th>
							<th data-field="studentCollege" >College Name</th>
							<th data-field="grievanceAssignedTo">Assigned To</th>
							<th data-field="grievanceComments">Comments</th>
							<th data-field="grievanceCommentedOn">Commented On</th>
							<!--<th data-field="grievanceStatus" >Grievance Status</th>							
							<th data-field="grievanceSubject">Grievance Subject</th>
							
							<th data-field="grievanceDescription">Grievance Description</th>
							<th data-field="grievanceCreatedOn"> Grievance Created On</th>-->
							<th data-field="edit_delete" data-formatter="operateSave" data-events="operateEvents">Edit</th>										
						</div>
					</tr>
				</thead>
			</table>
	</div>