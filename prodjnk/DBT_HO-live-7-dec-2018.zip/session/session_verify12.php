<?php
	session_start();
	error_reporting(0);
	$cur_path = $_SERVER['PHP_SELF'];
	
	if($_SESSION["valid5"]) {
			$now = new DateTime();
			$now = $now->format('Y-m-d H:i:s');//current date/time
		
		if($_SESSION["timeout"] > $now) {
		$now = new DateTime();
			$now->add(new DateInterval("PT1H"));
			$now = $now->format('Y-m-d H:i:s');
			$_SESSION["timeout"] = $now;
			if($cur_path == "/DBT_HO/login.php") {
				header("Location: /DBT_HO/index.php");
			}
		} else {
			$_SESSION["valid5"] = false;
			if(!($cur_path == "/DBT_HO/login.php")) {
				$_SESSION["timeout_referer"] = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
				header("Location: /DBT_HO/login.php?r=session_timeout");
			}
		}
	} else {
		$_SESSION["valid5"] = false;
		if(!($cur_path == "/DBT_HO/login.php")) {
			header("Location: /DBT_HO/login.php?r=session_invalid");
		}
	}
?>