<?php
session_start();
include('../../db_connect.php');
include('../../../mailer.php');
$candidateID		=htmlspecialchars($_GET["candidateID"]);
$approvedTutionFees =htmlspecialchars($_GET["approvedTutionFees"]);
$approvedHostelFees =htmlspecialchars($_GET["approvedHostelFees"]);
$approvedBookNStationaryCharges =htmlspecialchars($_GET["approvedBookNStationaryCharges"]);
$approvedOtherCharges =htmlspecialchars($_GET["approvedOtherCharges"]);
$approvedTotalB =htmlspecialchars($_GET["approvedTotalB"]);
$approvedTotal =htmlspecialchars($_GET["approvedTotal"]);
$approvalOrRejectionComment = htmlspecialchars(mysqli_real_escape_string($con, $_GET["approvalOrRejectionComment"]));
$now = new DateTime();
$now = $now->format('Y-m-d H:i:s');

/*$studentQuery="SELECT * from students where studentUniqueId=".$candidateID;
//echo $studentQuery;
$studentResult = mysqli_query($con, $studentQuery)or die("Query Failed");*/

$studentQuery="SELECT * from students where studentUniqueId=?";
$stmt1 =mysqli_prepare($con, $studentQuery);
mysqli_stmt_bind_param($stmt1, 'i', $candidateID);
mysqli_stmt_execute($stmt1);
$studentResult = mysqli_stmt_get_result($stmt1);

$student_row = mysqli_fetch_array($studentResult, MYSQLI_ASSOC);

/*$studentQuery1="SELECT approvalOrRejectionComment from students where studentUniqueId=".$candidateID;
//echo $studentQuery;
$studentResult1 = mysqli_query($con, $studentQuery1)or die("Query Failed");*/

$studentQuery1="SELECT approvalOrRejectionComment from students where studentUniqueId=?";
$stmt1 =mysqli_prepare($con, $studentQuery1);
mysqli_stmt_bind_param($stmt1, 'i', $candidateID);
mysqli_stmt_execute($stmt1);
$studentResult1 = mysqli_stmt_get_result($stmt1);

$student_row1= mysqli_fetch_array($studentResult1, MYSQLI_ASSOC);

if($student_row['approvalFlag']=='Y'){
	$courseDuration	=	$student_row["courseDuration"];
}else{
	$courseDuration	=	$_GET["courseDuration"];
}
if($student_row['DBTApplicationStatus']=='Submitted'){
/*$query="UPDATE students 
				SET approvedTutionFees='".$approvedTutionFees."',
					approvedHostelFees='".$approvedHostelFees."',
					approvedBookNStationaryCharges='".$approvedBookNStationaryCharges."',
					approvedOtherCharges='".$approvedOtherCharges."',
					approvedTotalB='".$approvedTotalB."',
					approvedTotal='".$approvedTotal."',
					approvalOrRejectionComment='".$approvalOrRejectionComment."',
					courseDuration='".$courseDuration."',
					DBTApplicationStatus='Rejected',
					DBTApplicationFormSubmitted='N',
					approvalFlag='N',
					DBTStatusChangedBy='".$_SESSION['hoId']."',
					finalApprovedFlag='N',
					approvalDate='".$now."'
				WHERE
					studentUniqueId='".$candidateID."'";
	//echo $query;
	$result = mysqli_query($con, $query) or die("Query Failed");*/
	
	$query="UPDATE students 
				SET approvedTutionFees=?,
					approvedHostelFees=?,
					approvedBookNStationaryCharges=?,
					approvedOtherCharges=?,
					approvedTotalB=?,
					approvedTotal=?,
					approvalOrRejectionComment=?,
					DBTApplicationStatus='Rejected',
					DBTApplicationFormSubmitted='N',
					approvalFlag='N',
					DBTStatusChangedBy=?,
					finalApprovedFlag='N',
					approvalDate=?
				WHERE
					studentUniqueId=?";
		$stmt1 =mysqli_prepare($con, $query);
		mysqli_stmt_bind_param($stmt1, 'sssssssssi', $approvedTutionFees, $approvedHostelFees, $approvedBookNStationaryCharges, $approvedOtherCharges, $approvedTotalB, $approvedTotal, $approvalOrRejectionComment, $_SESSION['hoId'], $now, $candidateID);
		$result = mysqli_stmt_execute($stmt1);

	if($result)
	{	$recipients = $student_row['primaryEmailId'];
			
			$subject = "Application for DBT under PM's Special Scholarship Scheme for J & K Students";
			$body ="Hello ".$student_row['firstName']." ".$student_row['lastName'].", <br/> <br/>
			
			This has reference to your application wherein, documents were uploaded on AICTE Portal for release of scholarship under PM's Special Scholarship Scheme for the students of Jammu and Kashmir.
			<br/><br/>
			While processing your application, following deficiencies  are noted:
 <br/> 
			".$approvalOrRejectionComment."<br/><br/>
			You are advised to again login to http://www.aicte-jk-scholarship-gov.in/ with your user name and password and upload the correct document(s) in connection with deficiency/deficiencies as mentioned above.<br/><br/>
			<b>You application for release of scholarship will be processed only after receiving the correct document(s)</b>
<br/><br/>
			
			Regards,<br/>
			J&K Scholarship Support Team<br/>
			jkadmission2015@aicte-india.org
			<br/><br/>
			<hr/>
			This is an auto-generated email message, please do not reply directly as we will not be able to answer. If you need to contact us, please send us an e-mail to jkadmission2015@aicte-india.org.";
			$altBody= "";
	
			$s= sendMail($recipients, $subject, $body, $altBody,5);
			//$s=true;
			if($s)
			{	//echo $recipients;
				echo "success";
			}
		
	}
	else
	{
		echo "failure";
	}
	}
	else
	{
	 echo $student_row['DBTApplicationStatus'];
	}
?>