<div id="loadingDiv" class="loadingDiv hide">
	<img src="/bugdiary/site/images/loading.gif" />
</div>
