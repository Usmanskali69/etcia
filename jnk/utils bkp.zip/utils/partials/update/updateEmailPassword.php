<?php
	session_start();
	
	include('../../../db_connect.php');
	
	$primaryEmailId				=$_GET["changedLoginName"];
	$password				=$_GET["changedPassword"];
	$selectquery="select count(*) as count
					from students
				WHERE
					primaryEmailId like '".$primaryEmailId."' and studentUniqueId!='".$_SESSION['studentUniqueId']."'";
	//echo $selectquery;
	$selectresult = mysqli_query($con, $selectquery) or die("Query Failed");
	$select_row=mysqli_fetch_array($selectresult);
	if($select_row['count']==0)
	{
	$query="UPDATE students 
				SET primaryEmailId='".$primaryEmailId."',
					password='".$password."',
					isPasswordChanged='Yes'
					
				WHERE
					studentUniqueId='".$_SESSION['studentUniqueId']."'";
	//echo $query;
	$result = mysqli_query($con, $query) or die("Query Failed");
	
	if($result){
		echo 'Success';
	}
	}
	else
	{
		echo 'Failure';
	}
?>

