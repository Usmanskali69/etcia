<div class="page-header">
	<h3>Submitted Application List</h3>
</div>
<table id="table1" data-toggle="table" data-url="partials/data/SubmittedApplicationNonCCPList.php" data-cache="false" data-show-export="true" data-height="420" data-sort-name="Submission_Date" data-sort-order="asc" data-show-columns="true" data-show-refresh="true" data-search="true" data-select-item-name="toolbar1" data-striped="true" data-pagination="true" data-side-pagination="client" data-page-list="[5, 10, 20, 50, 100, 200]">
	<thead>
		<tr>
			<th data-field="Submission_Date" data-visible="true" data-sortable="true" >Submission Date/Time</th>
			<!--<th data-field="Candidate_Rank" data-visible="true" data-sortable="true" >Candidate Rank</th>-->
			<th data-field="Candidate_Id" data-visible="true" data-sortable="true" >Candidate ID</th>
			<th data-field="Candidate_Name" data-sortable="true" data-switchable="false">Candidate Name</th>
			<th data-field="Candidate_Status" data-visible="true">Current Status</th>
			<th data-field="Candidate_Category" data-visible="true">Category</th>
			<th data-field="College_Name" data-visible="true">College Name</th>
			<th data-field="edit_delete" data-formatter="operateFormatterVerified" data-events="operateEvents">Edit</th>
			
		</tr>
	</thead>
</table>

