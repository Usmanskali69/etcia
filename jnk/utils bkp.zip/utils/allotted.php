<!DOCTYPE html>
<html lang="en">

	<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="SUVOJIT AOWN/ VANASHREE PUROHIT/ LAKSHMI GOPAKUMAR">

		<title>J&K Scholarship</title>

		<!-- Bootstrap Core CSS -->
		<link href="../css/bootstrap.min.css" rel="stylesheet">

		<!-- Custom CSS -->
		<link href="../css/main.css" rel="stylesheet">

		<!-- Custom Fonts -->
		<link href="../font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
		
	</head>
	<style>
	body{
	font-size:12px;
	padding:2px;
	}
	</style>
	<body>
		<div class="container-fluid">
			<div>
				<h4>Allotted Professional Candidate List</h4>
			</div>
			<div id="engineeringAllottedList">
			</div>
		
		
			<div>
				<h4>Allotted General Candidate List</h4>
			</div>
			<div id="generalAllottedList">
			</div>
			
		</div>
		
		<script src="../js/jquery.js"></script>
		<script src="../js/bootstrap.min.js"></script>
		<script>
		
		$(document).ready(function() {
					$.ajax({
							type: 'GET', // define the type of HTTP verb we want to use (POST for our form)
							url: 'partials/ajax/getEngineeringAllotedStudent.php', // the url where we want to POST
							encode: true,
							success :function(data){
								var reply = data.replace(/\s+/, ""); 
								//$("#old").hide();
								$("#engineeringAllottedList").html(reply);
								//console.log(reply);
								}
						});
					
					$.ajax({
							type: 'GET', // define the type of HTTP verb we want to use (POST for our form)
							url: 'partials/ajax/getGeneralAllotedStudent.php', // the url where we want to POST
							encode: true,
							success :function(data){
								var reply = data.replace(/\s+/, ""); 
								//$("#old").hide();
								$("#generalAllottedList").html(reply);
								//console.log(reply);
								}
						});
			setInterval(function() {
				
					
					//console.log("if");
					$.ajax({
							type: 'GET', // define the type of HTTP verb we want to use (POST for our form)
							url: 'partials/ajax/getEngineeringAllotedStudent.php', // the url where we want to POST
							encode: true,
							success :function(data){
								var reply = data.replace(/\s+/, ""); 
								//$("#old").hide();
								$("#engineeringAllottedList").html(reply);
								//console.log(reply);
								}
						});
					
					$.ajax({
							type: 'GET', // define the type of HTTP verb we want to use (POST for our form)
							url: 'partials/ajax/getGeneralAllotedStudent.php', // the url where we want to POST
							encode: true,
							success :function(data){
								var reply = data.replace(/\s+/, ""); 
								//$("#old").hide();
								$("#generalAllottedList").html(reply);
								//console.log(reply);
								}
						});

					
				}, 10000);
		});	
		</script>
	</body>
</html>